<?php

//phpinfo();

function postgres_dataset($query) {
	$user_id = intval($_GET['user']); //no default

	// connect to the db
	$link = pg_connect('host=localhost;dbname=pcd;user=pcd;password=pcd') or die('Cannot connect to the DB');
	
	$result = pg_query($query, $link) or die('Errant query:  '.$query);

	// disconnect from the db
	pg_close($link);

    return $result;
}

function dataset($query) {
	$user_id = intval($_GET['user']); //no default

	// connect to the db
	$link = mysql_connect('localhost','root','root') or die('Cannot connect to the DB');
	mysql_select_db('pcd', $link) or die('Cannot select the DB');

	$result = mysql_query($query, $link) or die('Errant query:  '.$query);

	// disconnect from the db
	@mysql_close($link);

    return $result;
}

function to_json($array) {
    header('Content-type: application/json');
    echo json_encode($array);
}

?>

<?php
header('Content-Type: text/css');

/*
echo "body {";
echo "color: #00AC00";
echo "}";
*/

echo ".Musimundo {";
echo "color: #a94442;";
echo "background-color: #f2dede;";
echo "border-color: #a94442;";
echo "}";

/*
            backgroundColor: "rgba(255,0,0,0.2)",
            borderColor: "rgba(255,0,0,1)",
            pointBackgroundColor: "rgba(255,0,0,1)",
            pointBorderColor: "#fff",
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderColor: "rgba(255,0,0,1)",
            data: [24.01, 12.62, 21.04, 18.56, 13.12, 10.64]
        },
        {
echo "Fravega",
            backgroundColor: "rgba(0,51,204,0.2)",
            borderColor: "rgba(0,51,204,1)",
            pointBackgroundColor: "rgba(0,51,204,1)",
            pointBorderColor: "#fff",
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderColor: "rgba(0,51,204,1)",
            data: [16.25, 15.50, 23.25, 21.00, 15.50, 8.50]
        },
        {
echo "Garbarino",
            backgroundColor: "rgba(0,102,0,0.2)",
            borderColor: "rgba(0,102,0,1)",
            pointBackgroundColor: "rgba(0,102,0,1)",
            pointBorderColor: "#fff",
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderColor: "rgba(0,102,0,1)",
            data: [16.10, 10.73, 27.80, 21.46, 16.59, 7.32]
        },
        {
echo "Avenida",
            backgroundColor: "rgba(150,150,150,0.2)",
*/
            
?>
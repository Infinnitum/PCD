
function getJSON(url, success) {
    $.ajax({
        url: url,
        dataType: "json",
        success: success
    });
};

function setTable(url, table) {
    getJSON(url,
            function(result) {
                $(table).bootstrapTable({
                    data: result,
                    striped: true
                });
            });
};

function setGrafico(url, dom_grafico, grafico) {
    getJSON(url,
            function(result) {
                d3.select(dom_grafico)
                    .datum(result)
                    .call(grafico);
            });
};

var user = 1;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Audiencia

//// Intereses de la Audiencia b=100

////// Cuadro
function start_audiencia_interes_b100_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_interes_b100_tabla", '#audiencia_interes_b100_tabla');
};

////// Grafico
function start_audiencia_interes_b100_grafico(){

    nv.addGraph(function() {
        d3.select('#audiencia_interes_b100_grafico svg > *').remove();
        
        audiencia_interes_b100_grafico = nv.models.multiBarChart()
            .x(function(d) { return d.label })
            .rotateLabels(-45)
            .y(function(d) { return d.value })
            .yDomain([0, 50])
            .color(d3.scale.category20().range())
            .barColor(d3.scale.category20().range())
            .reduceXTicks(false)
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .showControls(false)
            .useInteractiveGuideline(true);
            
        setGrafico("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_interes_b100_grafico", '#audiencia_interes_b100_grafico svg', audiencia_interes_b100_grafico);

        audiencia_interes_b100_grafico.update;
        
        return audiencia_interes_b100_grafico;
    });
};


//// Intereses de la Audiencia

////// Cuadro
function start_audiencia_interes_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_interes_tabla", '#audiencia_interes_tabla');
};

////// Grafico
function start_audiencia_interes_grafico(){
    nv.addGraph(function() {
        d3.select('#audiencia_interes_grafico svg > *').remove();
        
        audiencia_interes_grafico = nv.models.multiBarChart()
            .x(function(d) { return d.label })
            .rotateLabels(-45)
            .y(function(d) { return d.value })
            .yDomain([0, 50])
            .color(d3.scale.category20().range())
            .barColor(d3.scale.category20().range())
            .reduceXTicks(false)
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .showControls(false)
            .useInteractiveGuideline(true);
            
        setGrafico("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_interes_grafico", '#audiencia_interes_grafico svg', audiencia_interes_grafico);
        
        audiencia_interes_grafico.update;
        
        return audiencia_interes_grafico;
    });
};


//// Intereses de la Audiencia por Industria

//// Arte_Entretenimiento

////// Sitios
function start_audiencia_Arte_Entretenimiento_sites(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Arte_Entretenimiento", '#audiencia_Arte_Entretenimiento_sites');
};

////// Tabla - Musimundo
function start_audiencia_Arte_Entretenimiento_musimundo_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=0", '#audiencia_Arte_Entretenimiento_musimundo_tabla');
};

////// Grafico - Musimundo
function start_audiencia_Arte_Entretenimiento_musimundo_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_musimundo_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Fravega
function start_audiencia_Arte_Entretenimiento_fravega_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=1", '#audiencia_Arte_Entretenimiento_fravega_tabla');
};

////// Grafico - Fravega
function start_audiencia_Arte_Entretenimiento_fravega_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_fravega_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Garbarino
function start_audiencia_Arte_Entretenimiento_garbarino_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=2", '#audiencia_Arte_Entretenimiento_garbarino_tabla');
};

////// Grafico - Garbarino
function start_audiencia_Arte_Entretenimiento_garbarino_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_garbarino_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Avenida
function start_audiencia_Arte_Entretenimiento_avenida_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=3", '#audiencia_Arte_Entretenimiento_avenida_tabla');
};

////// Grafico - Avenida
function start_audiencia_Arte_Entretenimiento_avenida_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_avenida_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Internet_Telcos

////// Sitios
function start_audiencia_Internet_Telcos_sites(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Internet_Telcos", '#audiencia_Internet_Telcos_sites');
};

////// Tabla - Musimundo
function start_audiencia_Internet_Telcos_musimundo_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=0", '#audiencia_Internet_Telcos_musimundo_tabla');
};

////// Grafico - Musimundo
function start_audiencia_Internet_Telcos_musimundo_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_musimundo_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Fravega
function start_audiencia_Internet_Telcos_fravega_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=1", '#audiencia_Internet_Telcos_fravega_tabla');
};

////// Grafico - Fravega
function start_audiencia_Internet_Telcos_fravega_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_fravega_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Garbarino
function start_audiencia_Internet_Telcos_garbarino_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=2", '#audiencia_Internet_Telcos_garbarino_tabla');
};

////// Grafico - Garbarino
function start_audiencia_Internet_Telcos_garbarino_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_garbarino_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Avenida
function start_audiencia_Internet_Telcos_avenida_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=3", '#audiencia_Internet_Telcos_avenida_tabla');
};

////// Grafico - Avenida
function start_audiencia_Internet_Telcos_avenida_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_avenida_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Shoppings

////// Sitios
function start_audiencia_Shoppings_sites(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Shoppings", '#audiencia_Shoppings_sites');
};

////// Tabla - Musimundo
function start_audiencia_Shoppings_musimundo_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=0", '#audiencia_Shoppings_musimundo_tabla');
};

////// Grafico - Musimundo
function start_audiencia_Shoppings_musimundo_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_musimundo_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Fravega
function start_audiencia_Shoppings_fravega_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=1", '#audiencia_Shoppings_fravega_tabla');
};

////// Grafico - Fravega
function start_audiencia_Shoppings_fravega_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_fravega_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Garbarino
function start_audiencia_Shoppings_garbarino_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=2", '#audiencia_Shoppings_garbarino_tabla');
};

////// Grafico - Garbarino
function start_audiencia_Shoppings_garbarino_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_garbarino_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Avenida
function start_audiencia_Shoppings_avenida_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=3", '#audiencia_Shoppings_avenida_tabla');
};

////// Grafico - Avenida
function start_audiencia_Shoppings_avenida_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_avenida_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Noticias_Medios

////// Sitios
function start_audiencia_Noticias_Medios_sites(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Noticias_Medios", '#audiencia_Noticias_Medios_sites');
};

////// Tabla - Musimundo
function start_audiencia_Noticias_Medios_musimundo_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=0", '#audiencia_Noticias_Medios_musimundo_tabla');
};

////// Grafico - Musimundo
function start_audiencia_Noticias_Medios_musimundo_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_musimundo_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Fravega
function start_audiencia_Noticias_Medios_fravega_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=1", '#audiencia_Noticias_Medios_fravega_tabla');
};

////// Grafico - Fravega
function start_audiencia_Noticias_Medios_fravega_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_fravega_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Garbarino
function start_audiencia_Noticias_Medios_garbarino_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=2", '#audiencia_Noticias_Medios_garbarino_tabla');
};

////// Grafico - Garbarino
function start_audiencia_Noticias_Medios_garbarino_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_garbarino_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Avenida
function start_audiencia_Noticias_Medios_avenida_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=3", '#audiencia_Noticias_Medios_avenida_tabla');
};

////// Grafico - Avenida
function start_audiencia_Noticias_Medios_avenida_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_avenida_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};


//// Audiencia Sitios

////// Cuadro
function start_audiencia_sitios_ranking_tabla(){
    setTable("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_sitios_ranking_tabla", '#audiencia_sitios_ranking_tabla');
};


////// Grafico Línea
function start_audiencia_industrias_line_grafico(){
    var tickvalues = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1)];
    //var tickvalues = ['May 2015', 'Jul 2015', 'Sep 2015', 'Nov 2015', 'Ene 2016'];
    
    nv.addGraph(function() {
        d3.select('#audiencia_industrias_line_grafico svg > *').remove();
        audiencia_industrias_line_grafico = nv.models.lineChart()
            .x(function(d) { return new Date(d.label.split("-")[0], (d.label.split("-")[1]-1), d.label.split("-")[2]) })
            .xScale(d3.time.scale())
            .y(function(d) { return d.value })
            .yDomain([0, 30])
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .color(d3.scale.category20().range())
            .useInteractiveGuideline(true)
            ;
        
        audiencia_industrias_line_grafico.xAxis
            .tickValues(tickvalues)
            .tickFormat(function(d) { return d3.time.format("%b %Y")(d) })
            ;
        
        setGrafico("../PCD/backend/audiencia.php?user="+user+"&action=audiencia_industrias_line_grafico", '#audiencia_industrias_line_grafico svg', audiencia_industrias_line_grafico);

        audiencia_industrias_line_grafico.update;
        return audiencia_industrias_line_grafico;
    });
};


////// Grafico radar
function start_audiencia_industrias_radar_grafico(){
        
    var ctx = $("#audiencia_industrias_radar_grafico");

    var data = {
        labels: ["Arte y Entretenimiento", "Internet & Telcos", "Shoppings", "Noticias & Medios", "Negocios e industrias", "Computer & Electronic"],

        datasets: [
            {
                label: "Musimundo",
                backgroundColor: "rgba(255,0,0,0.2)",
                borderColor: "rgba(255,0,0,1)",
                pointBackgroundColor: "rgba(255,0,0,1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(255,0,0,1)",
                data: [24.01, 12.62, 21.04, 18.56, 13.12, 10.64]
            },
            {
                label: "Fravega",
                backgroundColor: "rgba(0,51,204,0.2)",
                borderColor: "rgba(0,51,204,1)",
                pointBackgroundColor: "rgba(0,51,204,1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(0,51,204,1)",
                data: [16.25, 15.50, 23.25, 21.00, 15.50, 8.50]
            },
            {
                label: "Garbarino",
                backgroundColor: "rgba(0,102,0,0.2)",
                borderColor: "rgba(0,102,0,1)",
                pointBackgroundColor: "rgba(0,102,0,1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(0,102,0,1)",
                data: [16.10, 10.73, 27.80, 21.46, 16.59, 7.32]
            },
            {
                label: "Avenida",
                backgroundColor: "rgba(150,150,150,0.2)",
                borderColor: "rgba(150,150,150,1)",
                pointBackgroundColor: "rgba(150,150,150,1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(150,150,150,1)",
                data: [13.36, 11.64, 33.19, 18.10, 16.81, 6.90]
            },
        ]
    };

    var myRadarChart = new Chart(ctx, {
        type: 'radar',
        data: data
    });
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var refresh_function = [];

$(document).ready(function() {
    init_sidebar();
    
    start_audiencia_interes_b100_tabla();
    start_audiencia_interes_b100_grafico();
    start_audiencia_interes_tabla();
    
    start_audiencia_Arte_Entretenimiento_sites();
    start_audiencia_Arte_Entretenimiento_musimundo_tabla();
    start_audiencia_Arte_Entretenimiento_musimundo_wordcloud();
    start_audiencia_Arte_Entretenimiento_garbarino_tabla();
    start_audiencia_Arte_Entretenimiento_garbarino_wordcloud();
    start_audiencia_Arte_Entretenimiento_fravega_tabla();
    start_audiencia_Arte_Entretenimiento_fravega_wordcloud();
    start_audiencia_Arte_Entretenimiento_avenida_tabla();
    start_audiencia_Arte_Entretenimiento_avenida_wordcloud();
    start_audiencia_Internet_Telcos_sites();
    start_audiencia_Internet_Telcos_musimundo_tabla();
    start_audiencia_Internet_Telcos_musimundo_wordcloud();
    start_audiencia_Internet_Telcos_garbarino_tabla();
    start_audiencia_Internet_Telcos_garbarino_wordcloud();
    start_audiencia_Internet_Telcos_fravega_tabla();
    start_audiencia_Internet_Telcos_fravega_wordcloud();
    start_audiencia_Internet_Telcos_avenida_tabla();
    start_audiencia_Internet_Telcos_avenida_wordcloud();
    start_audiencia_Shoppings_sites();
    start_audiencia_Shoppings_musimundo_tabla();
    start_audiencia_Shoppings_musimundo_wordcloud();
    start_audiencia_Shoppings_garbarino_tabla();
    start_audiencia_Shoppings_garbarino_wordcloud();
    start_audiencia_Shoppings_fravega_tabla();
    start_audiencia_Shoppings_fravega_wordcloud();
    start_audiencia_Shoppings_avenida_tabla();
    start_audiencia_Shoppings_avenida_wordcloud();
    start_audiencia_Noticias_Medios_sites();
    start_audiencia_Noticias_Medios_musimundo_tabla();
    start_audiencia_Noticias_Medios_musimundo_wordcloud();
    start_audiencia_Noticias_Medios_garbarino_tabla();
    start_audiencia_Noticias_Medios_garbarino_wordcloud();
    start_audiencia_Noticias_Medios_fravega_tabla();
    start_audiencia_Noticias_Medios_fravega_wordcloud();
    start_audiencia_Noticias_Medios_avenida_tabla();
    start_audiencia_Noticias_Medios_avenida_wordcloud();
    
    start_audiencia_sitios_ranking_tabla();
    
    start_audiencia_industrias_line_grafico();
    

    
    $('body').scrollspy({ target: '#sidebar-menu' });
    
    $("#link_tab_audiencia_interes_b100").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_interes_b100_grafico");
    });
    $("#link_tab_audiencia_interes").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_interes_grafico");
    });
    $("#link_tab_audiencia_Arte_Entretenimiento").on("click", function() {
        refresh_function = [];
    });
    $("#link_tab_audiencia_Internet_Telcos").on("click", function() {
        refresh_function = [];
    });
    $("#link_tab_audiencia_Shoppings").on("click", function() {
        refresh_function = [];
    });
    $("#link_tab_audiencia_Noticias_Medios").on("click", function() {
        refresh_function = [];
    });
    
    $("#link_tab_audiencia_industrias_line_grafico").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_industrias_line_grafico");
    });
    $("#link_tab_audiencia_industrias_radar_grafico").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_industrias_radar_grafico");
    });
        
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        //alert(e.target); // newly activated tab
        //e.relatedTarget // previous active tab
        var i;
        for (i = 0; i < refresh_function.length; i++) {
            window[refresh_function[i]]();
        };
    });
});


var user = 1;
var fechas = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1), new Date(2016, 2,1), new Date(2016, 4,1)];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Trafico

//// Panorama Mensual

////// Trafico total por mes

////// Cuadro
function start_trafico_panorama_mensual_Trafico_Total_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Trafico_Total", '#trafico_panorama_mensual_Trafico_Total_tabla');
};
////// Semaforo
function start_trafico_panorama_mensual_Trafico_Total_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Trafico_Total", "#trafico_panorama_mensual_Trafico_Total_indicador");
};
////// Anual
function start_trafico_panorama_mensual_Trafico_Total_anual() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_anual&tipo=Trafico_Total", '#trafico_panorama_mensual_Trafico_Total_anual');
};
////// Acumulado
function start_trafico_panorama_mensual_Trafico_Total_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Trafico_Total", "#trafico_panorama_mensual_Trafico_Total_acumulado svg");
};
////// Tendencia
function start_trafico_panorama_mensual_Trafico_Total_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Trafico_Total", "#trafico_panorama_mensual_Trafico_Total_tendencia svg", fechas);
};

////// Tiempo Promedio de Visita

////// Cuadro
function start_trafico_panorama_mensual_Tiempo_Promedio_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Tiempo_Promedio", '#trafico_panorama_mensual_Tiempo_Promedio_tabla');
};
////// Semaforo
function start_trafico_panorama_mensual_Tiempo_Promedio_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Tiempo_Promedio", '#trafico_panorama_mensual_Tiempo_Promedio_indicador');
};
////// Anual
function start_trafico_panorama_mensual_Tiempo_Promedio_anual() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_anual&tipo=Tiempo_Promedio", '#trafico_panorama_mensual_Tiempo_Promedio_anual');
};
////// Acumulado
function start_trafico_panorama_mensual_Tiempo_Promedio_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Tiempo_Promedio", "#trafico_panorama_mensual_Tiempo_Promedio_acumulado svg");
};
////// Tendencia
function start_trafico_panorama_mensual_Tiempo_Promedio_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Tiempo_Promedio", "#trafico_panorama_mensual_Tiempo_Promedio_tendencia svg", fechas);
};

////// Visitas

////// Cuadro
function start_trafico_panorama_mensual_Visitas_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Visitas", '#trafico_panorama_mensual_Visitas_tabla');
};
////// Semaforo
function start_trafico_panorama_mensual_Visitas_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Visitas", '#trafico_panorama_mensual_Visitas_indicador');
};
////// Anual
function start_trafico_panorama_mensual_Visitas_anual() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_anual&tipo=Visitas", '#trafico_panorama_mensual_Visitas_anual');
};
////// Acumulado
function start_trafico_panorama_mensual_Visitas_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Visitas", "#trafico_panorama_mensual_Visitas_acumulado svg");
};
////// Tendencia
function start_trafico_panorama_mensual_Visitas_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Visitas", "#trafico_panorama_mensual_Visitas_tendencia svg", fechas);
};

////// Abandono

////// Cuadro
function start_trafico_panorama_mensual_Abandono_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Abandono", '#trafico_panorama_mensual_Abandono_tabla');
};
////// Semaforo
function start_trafico_panorama_mensual_Abandono_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Abandono", '#trafico_panorama_mensual_Abandono_indicador');
};
////// Anual
function start_trafico_panorama_mensual_Abandono_anual() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_anual&tipo=Abandono", '#trafico_panorama_mensual_Abandono_anual');
};
////// Acumulado
function start_trafico_panorama_mensual_Abandono_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Abandono", "#trafico_panorama_mensual_Abandono_acumulado svg");
};
////// Tendencia
function start_trafico_panorama_mensual_Abandono_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Abandono", "#trafico_panorama_mensual_Abandono_tendencia svg", fechas);
};

////// Trafico_Neto

////// Cuadro
function start_trafico_panorama_mensual_Trafico_Neto_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Trafico_Neto", '#trafico_panorama_mensual_Trafico_Neto_tabla');
};
////// Semaforo
function start_trafico_panorama_mensual_Trafico_Neto_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Trafico_Neto", '#trafico_panorama_mensual_Trafico_Neto_indicador');
};
////// Anual
function start_trafico_panorama_mensual_Trafico_Neto_anual() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_anual&tipo=Trafico_Neto", '#trafico_panorama_mensual_Trafico_Neto_anual');
};
////// Acumulado
function start_trafico_panorama_mensual_Trafico_Neto_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Trafico_Neto", "#trafico_panorama_mensual_Trafico_Neto_acumulado svg");
};
////// Tendencia
function start_trafico_panorama_mensual_Trafico_Neto_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Trafico_Neto", "#trafico_panorama_mensual_Trafico_Neto_tendencia svg", fechas);
};


//// Trafico Acumulado

////// Generacion

////// Cuadro
function start_trafico_acumulado_Generacion_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_acumulado_Generacion_tabla", '#trafico_acumulado_Generacion_tabla');
};
////// Semaforo
function start_trafico_acumulado_Generacion_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_acumulado_Generacion_indicador", '#trafico_acumulado_Generacion_indicador');
};
////// Tendencia
function start_trafico_acumulado_Generacion_tendencia() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Generacion_tendencia", "#trafico_acumulado_Generacion_tendencia svg");
};

////// Busquedas

////// Cuadro
function start_trafico_acumulado_Busquedas_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_acumulado_Busquedas_tabla", '#trafico_acumulado_Busquedas_tabla');
};
////// Acumulado
function start_trafico_acumulado_Busquedas_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Busquedas_acumulado&tipo=Inorganico", "#trafico_acumulado_Busquedas_Inorganico_acumulado svg", "percent");
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Busquedas_acumulado&tipo=Organico", "#trafico_acumulado_Busquedas_Organico_acumulado svg", "percent");
};
////// Tendencia
function start_trafico_acumulado_Busquedas_tendencia() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Busquedas_tendencia", "#trafico_acumulado_Busquedas_tendencia svg", "percent");
};

////// Share por Canal

////// Acumulado
function start_trafico_acumulado_Share_Canal_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_acumulado&tipo=Directo", "#trafico_acumulado_Share_Canal_Directo_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_acumulado&tipo=Mail", "#trafico_acumulado_Share_Canal_Mail_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_acumulado&tipo=Referidos", "#trafico_acumulado_Share_Canal_Referidos_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_acumulado&tipo=Busquedas", "#trafico_acumulado_Share_Canal_Busquedas_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_acumulado&tipo=Social", "#trafico_acumulado_Share_Canal_Social_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_acumulado&tipo=Displays", "#trafico_acumulado_Share_Canal_Displays_acumulado svg");
};

////// Share por Canal b100

////// Acumulado
function start_trafico_acumulado_Share_Canal_b100_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_b100_acumulado&tipo=Directo", "#trafico_acumulado_Share_Canal_b100_Directo_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_b100_acumulado&tipo=Mail", "#trafico_acumulado_Share_Canal_b100_Mail_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_b100_acumulado&tipo=Referidos", "#trafico_acumulado_Share_Canal_b100_Referidos_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_b100_acumulado&tipo=Busquedas", "#trafico_acumulado_Share_Canal_b100_Busquedas_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_b100_acumulado&tipo=Social", "#trafico_acumulado_Share_Canal_b100_Social_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_acumulado_Share_Canal_b100_acumulado&tipo=Displays", "#trafico_acumulado_Share_Canal_b100_Displays_acumulado svg");
};


//// Trafico Ultimo Mes

////// Generacion

////// Cuadro
function start_trafico_mes_Generacion_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_mes_Generacion_tabla", '#trafico_mes_Generacion_tabla');
};
////// Semaforo
function start_trafico_mes_Generacion_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_mes_Generacion_indicador", '#trafico_mes_Generacion_indicador');
};
////// Tendencia
function start_trafico_mes_Generacion_tendencia() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=trafico_mes_Generacion_tendencia", "#trafico_mes_Generacion_tendencia svg");
};

////// Busquedas

////// Cuadro
function start_trafico_mes_Busquedas_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_mes_Busquedas_tabla", '#trafico_mes_Busquedas_tabla');
};
////// Acumulado
function start_trafico_mes_Busquedas_acumulado() {
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_mes_Busquedas_acumulado&tipo=Inorganico", "#trafico_mes_Busquedas_Inorganico_acumulado svg");    
    addPieChart("backend/trafico.php?user="+user+"&action=trafico_mes_Busquedas_acumulado&tipo=Organico", "#trafico_mes_Busquedas_Organico_acumulado svg");
};
////// Tendencia
function start_trafico_mes_Busquedas_tendencia() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=trafico_mes_Busquedas_tendencia", "#trafico_mes_Busquedas_tendencia svg", "percent");
};


//// Trafico por Tipo

////// Referidos

////// Share
function start_trafico_tipo_Referidos_share() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_share&tipo=Referidos", '#trafico_tipo_Referidos_share');
};
////// Indicadores
function start_trafico_tipo_Referidos_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_indicador&tipo=Referidos", "#trafico_tipo_Referidos_indicador");
};
////// Variaciones
function start_trafico_tipo_Referidos_variacion() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_variacion&tipo=Referidos", '#trafico_tipo_Referidos_variacion');
};
////// Tendencia
function start_trafico_tipo_Referidos_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_tipo_tendencia&tipo=Referidos", "#trafico_tipo_Referidos_tendencia svg", fechas);
};

////// Busquedas_Totales

////// Share
function start_trafico_tipo_Busquedas_Totales_share() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_share&tipo=Busquedas_Totales", '#trafico_tipo_Busquedas_Totales_share');
};
////// Indicadores
function start_trafico_tipo_Busquedas_Totales_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_indicador&tipo=Busquedas_Totales", "#trafico_tipo_Busquedas_Totales_indicador");
};
////// Variaciones
function start_trafico_tipo_Busquedas_Totales_variacion() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_variacion&tipo=Busquedas_Totales", '#trafico_tipo_Busquedas_Totales_variacion');
};
////// Tendencia
function start_trafico_tipo_Busquedas_Totales_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_tipo_tendencia&tipo=Busquedas_Totales", "#trafico_tipo_Busquedas_Totales_tendencia svg", fechas);
};

////// Busquedas_Organicas

////// Share
function start_trafico_tipo_Busquedas_Organicas_share() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_share&tipo=Busquedas_Organicas", '#trafico_tipo_Busquedas_Organicas_share');
};
////// Indicadores
function start_trafico_tipo_Busquedas_Organicas_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_indicador&tipo=Busquedas_Organicas", "#trafico_tipo_Busquedas_Organicas_indicador");
};
////// Variaciones
function start_trafico_tipo_Busquedas_Organicas_variacion() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_variacion&tipo=Busquedas_Organicas", '#trafico_tipo_Busquedas_Organicas_variacion');
};
////// Tendencia
function start_trafico_tipo_Busquedas_Organicas_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_tipo_tendencia&tipo=Busquedas_Organicas", "#trafico_tipo_Busquedas_Organicas_tendencia svg", fechas);
};

////// Busquedas_Inorganicas

////// Share
function start_trafico_tipo_Busquedas_Inorganicas_share() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_share&tipo=Busquedas_Inorganicas", '#trafico_tipo_Busquedas_Inorganicas_share');
};
////// Indicadores
function start_trafico_tipo_Busquedas_Inorganicas_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_indicador&tipo=Busquedas_Inorganicas", "#trafico_tipo_Busquedas_Inorganicas_indicador");
};
////// Variaciones
function start_trafico_tipo_Busquedas_Inorganicas_variacion() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_variacion&tipo=Busquedas_Inorganicas", '#trafico_tipo_Busquedas_Inorganicas_variacion');
};
////// Tendencia
function start_trafico_tipo_Busquedas_Inorganicas_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_tipo_tendencia&tipo=Busquedas_Inorganicas", "#trafico_tipo_Busquedas_Inorganicas_tendencia svg", fechas);
};

////// Redes_Sociales

////// Share
function start_trafico_tipo_Redes_Sociales_share() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_share&tipo=Redes_Sociales", '#trafico_tipo_Redes_Sociales_share');
};
////// Indicadores
function start_trafico_tipo_Redes_Sociales_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_indicador&tipo=Redes_Sociales", "#trafico_tipo_Redes_Sociales_indicador");
};
////// Variaciones
function start_trafico_tipo_Redes_Sociales_variacion() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_variacion&tipo=Redes_Sociales", '#trafico_tipo_Redes_Sociales_variacion');
};
////// Tendencia
function start_trafico_tipo_Redes_Sociales_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_tipo_tendencia&tipo=Redes_Sociales", "#trafico_tipo_Redes_Sociales_tendencia svg", fechas);
};

////// Displays

////// Share
function start_trafico_tipo_Displays_share() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_share&tipo=Displays", '#trafico_tipo_Displays_share');
};
////// Indicadores
function start_trafico_tipo_Displays_indicador() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_indicador&tipo=Displays", "#trafico_tipo_Displays_indicador");
};
////// Variaciones
function start_trafico_tipo_Displays_variacion() {
    setTable("backend/trafico.php?user="+user+"&action=trafico_tipo_variacion&tipo=Displays", '#trafico_tipo_Displays_variacion');
};
////// Tendencia
function start_trafico_tipo_Displays_tendencia() {
    addLineChartDates("backend/trafico.php?user="+user+"&action=trafico_tipo_tendencia&tipo=Displays", "#trafico_tipo_Displays_tendencia svg", fechas);
};


//// Share Trafico por Tipo

////// Referidos

////// Share por Mes Tabla
function start_share_trafico_tipo_Referidos_share_mes_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_tabla&tipo=Referidos", "#share_trafico_tipo_Referidos_share_mes_tabla");
};
////// Share por Mes Grafico
function start_share_trafico_tipo_Referidos_share_mes_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_grafico&tipo=Referidos", "#share_trafico_tipo_Referidos_share_mes_grafico svg", "percent");
};
////// Share por Trafico Tabla
function start_share_trafico_tipo_Referidos_share_trafico_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_tabla&tipo=Referidos", "#share_trafico_tipo_Referidos_share_trafico_tabla");
};
////// Share por Trafico Grafico
function start_share_trafico_tipo_Referidos_share_trafico_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_grafico&tipo=Referidos", "#share_trafico_tipo_Referidos_share_trafico_grafico svg", "percent");
};

////// Busquedas_Totales

////// Share por Mes Tabla
function start_share_trafico_tipo_Busquedas_Totales_share_mes_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_tabla&tipo=Busquedas_Totales", "#share_trafico_tipo_Busquedas_Totales_share_mes_tabla");
};
////// Share por Mes Grafico
function start_share_trafico_tipo_Busquedas_Totales_share_mes_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_grafico&tipo=Busquedas_Totales", "#share_trafico_tipo_Busquedas_Totales_share_mes_grafico svg", "percent");
};
////// Share por Trafico Tabla
function start_share_trafico_tipo_Busquedas_Totales_share_trafico_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_tabla&tipo=Busquedas_Totales", "#share_trafico_tipo_Busquedas_Totales_share_trafico_tabla");
};
////// Share por Trafico Grafico
function start_share_trafico_tipo_Busquedas_Totales_share_trafico_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_grafico&tipo=Busquedas_Totales", "#share_trafico_tipo_Busquedas_Totales_share_trafico_grafico svg", "percent");
};

////// Busquedas_Organicas

////// Share por Mes Tabla
function start_share_trafico_tipo_Busquedas_Organicas_share_mes_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_tabla&tipo=Busquedas_Organicas", "#share_trafico_tipo_Busquedas_Organicas_share_mes_tabla");
};
////// Share por Mes Grafico
function start_share_trafico_tipo_Busquedas_Organicas_share_mes_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_grafico&tipo=Busquedas_Organicas", "#share_trafico_tipo_Busquedas_Organicas_share_mes_grafico svg", "percent");
};
////// Share por Trafico Tabla
function start_share_trafico_tipo_Busquedas_Organicas_share_trafico_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_tabla&tipo=Busquedas_Organicas", "#share_trafico_tipo_Busquedas_Organicas_share_trafico_tabla");
};
////// Share por Trafico Grafico
function start_share_trafico_tipo_Busquedas_Organicas_share_trafico_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_grafico&tipo=Busquedas_Organicas", "#share_trafico_tipo_Busquedas_Organicas_share_trafico_grafico svg", "percent");
};

////// Busquedas_Inorganicas

////// Share por Mes Tabla
function start_share_trafico_tipo_Busquedas_Inorganicas_share_mes_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_tabla&tipo=Busquedas_Inorganicas", "#share_trafico_tipo_Busquedas_Inorganicas_share_mes_tabla");
};
////// Share por Mes Grafico
function start_share_trafico_tipo_Busquedas_Inorganicas_share_mes_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_grafico&tipo=Busquedas_Inorganicas", "#share_trafico_tipo_Busquedas_Inorganicas_share_mes_grafico svg", "percent");
};
////// Share por Trafico Tabla
function start_share_trafico_tipo_Busquedas_Inorganicas_share_trafico_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_tabla&tipo=Busquedas_Inorganicas", "#share_trafico_tipo_Busquedas_Inorganicas_share_trafico_tabla");
};
////// Share por Trafico Grafico
function start_share_trafico_tipo_Busquedas_Inorganicas_share_trafico_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_grafico&tipo=Busquedas_Inorganicas", "#share_trafico_tipo_Busquedas_Inorganicas_share_trafico_grafico svg", "percent");
};

////// Redes_Sociales

////// Share por Mes Tabla
function start_share_trafico_tipo_Redes_Sociales_share_mes_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_tabla&tipo=Redes_Sociales", "#share_trafico_tipo_Redes_Sociales_share_mes_tabla");
};
////// Share por Mes Grafico
function start_share_trafico_tipo_Redes_Sociales_share_mes_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_grafico&tipo=Redes_Sociales", "#share_trafico_tipo_Redes_Sociales_share_mes_grafico svg", "percent");
};
////// Share por Trafico Tabla
function start_share_trafico_tipo_Redes_Sociales_share_trafico_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_tabla&tipo=Redes_Sociales", "#share_trafico_tipo_Redes_Sociales_share_trafico_tabla");
};
////// Share por Trafico Grafico
function start_share_trafico_tipo_Redes_Sociales_share_trafico_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_grafico&tipo=Redes_Sociales", "#share_trafico_tipo_Redes_Sociales_share_trafico_grafico svg", "percent");
};

////// Displays

////// Share por Mes Tabla
function start_share_trafico_tipo_Displays_share_mes_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_tabla&tipo=Displays", "#share_trafico_tipo_Displays_share_mes_tabla");
};
////// Share por Mes Grafico
function start_share_trafico_tipo_Displays_share_mes_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_mes_grafico&tipo=Displays", "#share_trafico_tipo_Displays_share_mes_grafico svg", "percent");
};
////// Share por Trafico Tabla
function start_share_trafico_tipo_Displays_share_trafico_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_tabla&tipo=Displays", "#share_trafico_tipo_Displays_share_trafico_tabla");
};
////// Share por Trafico Grafico
function start_share_trafico_tipo_Displays_share_trafico_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=share_trafico_tipo_share_trafico_grafico&tipo=Displays", "#share_trafico_tipo_Displays_share_trafico_grafico svg", "percent");
};


//// Redes Sociales

////// Tabla
function start_redes_sociales_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=redes_sociales_tabla", "#redes_sociales_tabla");
};
////// b100
function start_redes_sociales_b100_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=redes_sociales_b100_grafico", "#redes_sociales_b100_grafico svg", "percent");
};
////// Grafico
function start_redes_sociales_grafico() {
    addMultiBarChart("backend/trafico.php?user="+user+"&action=redes_sociales_grafico", "#redes_sociales_grafico svg");
};


//// Dominios

////// Tabla
function start_dominios_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=dominios_tabla&tipo=Referidos", "#dominios_Referidos_tabla");
    setTable("backend/trafico.php?user="+user+"&action=dominios_tabla&tipo=Organicas", "#dominios_Organicas_tabla");
    setTable("backend/trafico.php?user="+user+"&action=dominios_tabla&tipo=Inorganicas", "#dominios_Inorganicas_tabla");
    setTable("backend/trafico.php?user="+user+"&action=dominios_tabla&tipo=Social", "#dominios_Social_tabla");
    setTable("backend/trafico.php?user="+user+"&action=dominios_tabla&tipo=Ad_Net", "#dominios_Ad_Net_tabla");
    setTable("backend/trafico.php?user="+user+"&action=dominios_tabla&tipo=Publisher", "#dominios_Publisher_tabla");
};


//// Outlinks

////// Tabla
function start_outlinks_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=outlinks_tabla", "#outlinks_tabla");
};


//// Subdominios

////// Tabla
function start_subdominios_tabla() {
    setTable("backend/trafico.php?user="+user+"&action=subdominios_tabla&tipo=Subdominios", "#subdominios_Subdominios_tabla");
    setTable("backend/trafico.php?user="+user+"&action=subdominios_tabla&tipo=Organico", "#subdominios_Organico_tabla");
    setTable("backend/trafico.php?user="+user+"&action=subdominios_tabla&tipo=Inorganico", "#subdominios_Inorganico_tabla");
};



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var refresh_function = [];

$(document).ready(function() {
    NProgress.start();

    init_sidebar();
    $('body').scrollspy({ target: '#sidebar-menu' });
    NProgress.inc();

    
    
    start_trafico_panorama_mensual_Trafico_Total_tabla();
    start_trafico_panorama_mensual_Trafico_Total_indicador();
    start_trafico_panorama_mensual_Trafico_Total_anual();
    start_trafico_panorama_mensual_Trafico_Total_acumulado();
    start_trafico_panorama_mensual_Trafico_Total_tendencia();
    $("#link_tab_trafico_panorama_mensual_Trafico_Total").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Total_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Total_tendencia");
    });
    NProgress.inc();
    
    start_trafico_panorama_mensual_Tiempo_Promedio_tabla();
    start_trafico_panorama_mensual_Tiempo_Promedio_indicador();
    start_trafico_panorama_mensual_Tiempo_Promedio_anual();
    $("#link_tab_trafico_panorama_mensual_Tiempo_Promedio").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Tiempo_Promedio_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Tiempo_Promedio_tendencia");
    });
    NProgress.inc();
    
    start_trafico_panorama_mensual_Visitas_tabla();
    start_trafico_panorama_mensual_Visitas_indicador();
    start_trafico_panorama_mensual_Visitas_anual();
    $("#link_tab_trafico_panorama_mensual_Visitas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Visitas_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Visitas_tendencia");
    });
    NProgress.inc();
    
    start_trafico_panorama_mensual_Abandono_tabla();
    start_trafico_panorama_mensual_Abandono_indicador();
    start_trafico_panorama_mensual_Abandono_anual();
    $("#link_tab_trafico_panorama_mensual_Abandono").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Abandono_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Abandono_tendencia");
    });
    NProgress.inc();
    
    start_trafico_panorama_mensual_Trafico_Neto_tabla();
    start_trafico_panorama_mensual_Trafico_Neto_indicador();  
    start_trafico_panorama_mensual_Trafico_Neto_anual();  
    $("#link_tab_trafico_panorama_mensual_Trafico_Neto").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Neto_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Neto_tendencia");
    });
    NProgress.inc();

    
    
    start_trafico_acumulado_Generacion_tabla();
    start_trafico_acumulado_Generacion_indicador();
    start_trafico_acumulado_Generacion_tendencia();
    $("#link_tab_trafico_acumulado_Generacion").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_acumulado_Generacion_tendencia");
    });
    NProgress.inc();

    start_trafico_acumulado_Busquedas_tabla();
    $("#link_tab_trafico_acumulado_Busquedas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_acumulado_Busquedas_acumulado");
        refresh_function.push("start_trafico_acumulado_Busquedas_tendencia");
    });
    NProgress.inc();
    
    $("#link_tab_trafico_acumulado_Share_Canal").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_acumulado_Share_Canal_acumulado");
    });
    NProgress.inc();
    
    $("#link_tab_trafico_acumulado_Share_Canal_b100").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_acumulado_Share_Canal_b100_acumulado");
    });
    NProgress.inc();
    
    
    
    start_trafico_mes_Generacion_tabla();
    start_trafico_mes_Generacion_indicador();
    start_trafico_mes_Generacion_tendencia();
    $("#link_tab_trafico_mes_Generacion").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_mes_Generacion_tendencia");
    });
    NProgress.inc();
    
    start_trafico_mes_Busquedas_tabla();
    $("#link_tab_trafico_mes_Busquedas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_mes_Busquedas_acumulado");
        refresh_function.push("start_trafico_mes_Busquedas_tendencia");
    });
    NProgress.inc();

    
    
    start_trafico_tipo_Referidos_share();
    start_trafico_tipo_Referidos_indicador();
    start_trafico_tipo_Referidos_variacion();
    start_trafico_tipo_Referidos_tendencia();
    $("#link_tab_trafico_tipo_Referidos").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_tipo_Referidos_tendencia");
    });
    NProgress.inc();
    
    start_trafico_tipo_Busquedas_Totales_share();
    start_trafico_tipo_Busquedas_Totales_indicador();
    start_trafico_tipo_Busquedas_Totales_variacion();
    $("#link_tab_trafico_tipo_Busquedas_Totales").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_tipo_Busquedas_Totales_tendencia");
    });
    NProgress.inc();
    
    start_trafico_tipo_Busquedas_Organicas_share();
    start_trafico_tipo_Busquedas_Organicas_indicador();
    start_trafico_tipo_Busquedas_Organicas_variacion();
    $("#link_tab_trafico_tipo_Busquedas_Organicas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_tipo_Busquedas_Organicas_tendencia");
    });
    NProgress.inc();

    start_trafico_tipo_Busquedas_Inorganicas_share();
    start_trafico_tipo_Busquedas_Inorganicas_indicador();
    start_trafico_tipo_Busquedas_Inorganicas_variacion();
    $("#link_tab_trafico_tipo_Busquedas_Inorganicas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_tipo_Busquedas_Inorganicas_tendencia");
    });
    NProgress.inc();

    start_trafico_tipo_Redes_Sociales_share();
    start_trafico_tipo_Redes_Sociales_indicador();
    start_trafico_tipo_Redes_Sociales_variacion();
    $("#link_tab_trafico_tipo_Redes_Sociales").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_tipo_Redes_Sociales_tendencia");
    });
    NProgress.inc();

    start_trafico_tipo_Displays_share();
    start_trafico_tipo_Displays_indicador();
    start_trafico_tipo_Displays_variacion();
    $("#link_tab_trafico_tipo_Displays").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_tipo_Displays_tendencia");
    });
    NProgress.inc();
    
    
    
    start_share_trafico_tipo_Referidos_share_mes_tabla();
    start_share_trafico_tipo_Referidos_share_mes_grafico();
    start_share_trafico_tipo_Referidos_share_trafico_tabla();
    start_share_trafico_tipo_Referidos_share_trafico_grafico();
    $("#link_tab_share_trafico_tipo_Referidos").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_share_trafico_tipo_Referidos_share_mes_grafico");
        refresh_function.push("start_share_trafico_tipo_Referidos_share_trafico_grafico");
    });
    NProgress.inc();
    
    start_share_trafico_tipo_Busquedas_Totales_share_mes_tabla();
    start_share_trafico_tipo_Busquedas_Totales_share_trafico_tabla();
    $("#link_tab_share_trafico_tipo_Busquedas_Totales").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_share_trafico_tipo_Busquedas_Totales_share_mes_grafico");
        refresh_function.push("start_share_trafico_tipo_Busquedas_Totales_share_trafico_grafico");
    });
    NProgress.inc();
    
    start_share_trafico_tipo_Busquedas_Organicas_share_mes_tabla();
    start_share_trafico_tipo_Busquedas_Organicas_share_trafico_tabla();
    $("#link_tab_share_trafico_tipo_Busquedas_Organicas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_share_trafico_tipo_Busquedas_Organicas_share_mes_grafico");
        refresh_function.push("start_share_trafico_tipo_Busquedas_Organicas_share_trafico_grafico");
    });
    NProgress.inc();

    start_share_trafico_tipo_Busquedas_Inorganicas_share_mes_tabla();
    start_share_trafico_tipo_Busquedas_Inorganicas_share_trafico_tabla();
    $("#link_tab_share_trafico_tipo_Busquedas_Inorganicas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_share_trafico_tipo_Busquedas_Inorganicas_share_mes_grafico");
        refresh_function.push("start_share_trafico_tipo_Busquedas_Inorganicas_share_trafico_grafico");
    });
    NProgress.inc();

    start_share_trafico_tipo_Redes_Sociales_share_mes_tabla();
    start_share_trafico_tipo_Redes_Sociales_share_trafico_tabla();
    $("#link_tab_share_trafico_tipo_Redes_Sociales").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_share_trafico_tipo_Redes_Sociales_share_mes_grafico");
        refresh_function.push("start_share_trafico_tipo_Redes_Sociales_share_trafico_grafico");
    });
    NProgress.inc();

    start_share_trafico_tipo_Displays_share_mes_tabla();
    start_share_trafico_tipo_Displays_share_trafico_tabla();
    $("#link_tab_share_trafico_tipo_Displays").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_share_trafico_tipo_Displays_share_mes_grafico");
        refresh_function.push("start_share_trafico_tipo_Displays_share_trafico_grafico");
    });
    NProgress.inc();
    
    
    
    start_redes_sociales_tabla();
    start_redes_sociales_b100_grafico();
    start_redes_sociales_grafico();
    NProgress.inc();
    
    
    
    start_dominios_tabla();
    NProgress.inc();
    
    
    
    start_outlinks_tabla();
    NProgress.inc();
    
    
    
    start_subdominios_tabla();
    NProgress.inc();
    
    
    
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        NProgress.start();
        //alert(e.target); // newly activated tab
        //e.relatedTarget // previous active tab
        var i;
        for (i = 0; i < refresh_function.length; i++) {
            window[refresh_function[i]]();
        };
        refresh_function = [];
        NProgress.done();
    });
    
    NProgress.done();
});

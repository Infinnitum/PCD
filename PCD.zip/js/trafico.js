
function getJSON(url, success) {
    $.ajax({
        url: url,
        dataType: "json",
        success: success
    });
};

function setTableSemaforo(url, table) {
    getJSON(url,
            function(result) {                
                var tabla = $(table).find('tbody');
                
                for (var i = 0; i < result.length; i++){
                    var obj = result[i];
                    var row = "";
                    
                    for (var key in obj){
                        var attrName = key;
                        var attrValue = obj[key];
                        
                        if (attrName == "Competidor"){
                            row = row + "<td>"+attrValue+"</td>";
                        }
                        else {
                            if (attrValue == "RED") row = row + "<td><i class=\"red\"><i class=\"fa fa-2x fa-times-circle\"></i></i></td>";
                            else if (attrValue == "GREEN") row = row + "<td><i class=\"green\"><i class=\"fa fa-2x fa-check-circle\"></i></i></td>";
                        }
                    }
                    
                    tabla.append($('<tr>').append(row));
                }                
            });
};

function setGrafico_d3(url, dom_grafico, grafico) {
    getJSON(url,
            function(result) {
                d3.select(dom_grafico)
                    .datum(result)
                    .call(grafico);
            });
};



function setTable(url, table) {
    getJSON(url,
            function(result) {
                $(table).bootstrapTable({
                    data: result,
                    striped: true
                });
            });
};

function setGrafico_chart(url, dom_grafico, grafico) {
//    console.log();
    getJSON(url,
            function(result) {
                new Chart($(dom_grafico), {
                    type: grafico,
                    data: result
                });
            });
};

var user = 1;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Trafico

//// Panorama Mensual

////// Trafico total por mes

////// Cuadro
function start_trafico_panorama_mensual_Trafico_Total_tabla(){
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Trafico_Total", '#trafico_panorama_mensual_Trafico_Total_tabla');
};

////// Semaforo
function start_trafico_panorama_mensual_Trafico_Total_indicador(){
    setTableSemaforo("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Trafico_Total", '#trafico_panorama_mensual_Trafico_Total_indicador');
};

////// Acumulado
function start_trafico_panorama_mensual_Trafico_Total_acumulado(){
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Trafico_Total_acumulado svg > *').remove();
        trafico_panorama_mensual_Trafico_Total_acumulado = nv.models.pieChart()
            .x(function(d) { return d.label })
            .y(function(d) { return d.value })
            .showLabels(true)
            .labelThreshold(.05)  //Configure the minimum slice size for labels to show up
            .labelType("percent")   //Configure what type of data to show in the label. Can be "key", "value" or "percent"
            .donut(true)          //Turn on Donut mode. Makes pie chart look tasty!
            .donutRatio(0.35)     //Configure how big you want the donut hole size to be.
            .color(d3.scale.category20().range())
            /*.useInteractiveGuideline(true)*/
            ;

        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Trafico_Total", '#trafico_panorama_mensual_Trafico_Total_acumulado svg', trafico_panorama_mensual_Trafico_Total_acumulado);

        trafico_panorama_mensual_Trafico_Total_acumulado.update;
        return trafico_panorama_mensual_Trafico_Total_acumulado;
    });
};

////// Tendencia
function start_trafico_panorama_mensual_Trafico_Total_tendencia(){
    var tickvalues = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1), new Date(2016, 2,1), new Date(2016, 4,1)];
    //var tickvalues = ['May 2015', 'Jul 2015', 'Sep 2015', 'Nov 2015', 'Ene 2016'];
    
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Trafico_Total_tendencia svg > *').remove();
        trafico_panorama_mensual_Trafico_Total_tendencia = nv.models.lineChart()
            .x(function(d) { return new Date(d.label.split("-")[0], (d.label.split("-")[1]-1), d.label.split("-")[2]) })
            .xScale(d3.time.scale())
            .y(function(d) { return d.value })
            .yDomain([0, 10000000])
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .color(d3.scale.category20().range())
            .useInteractiveGuideline(true)
            ;
        
        trafico_panorama_mensual_Trafico_Total_tendencia.xAxis
            .tickValues(tickvalues)
            .tickFormat(function(d) { return d3.time.format("%b %Y")(d) })
            ;
        
        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Trafico_Total", '#trafico_panorama_mensual_Trafico_Total_tendencia svg', trafico_panorama_mensual_Trafico_Total_tendencia);

        trafico_panorama_mensual_Trafico_Total_tendencia.update;
        return trafico_panorama_mensual_Trafico_Total_tendencia;
    });
};

////// Tiempo Promedio de Visita

////// Cuadro
function start_trafico_panorama_mensual_Tiempo_Promedio_tabla(){
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Tiempo_Promedio", '#trafico_panorama_mensual_Tiempo_Promedio_tabla');
};

////// Semaforo
function start_trafico_panorama_mensual_Tiempo_Promedio_indicador(){
    setTableSemaforo("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Tiempo_Promedio", '#trafico_panorama_mensual_Tiempo_Promedio_indicador');
};

////// Acumulado
function start_trafico_panorama_mensual_Tiempo_Promedio_acumulado(){
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Tiempo_Promedio_acumulado svg > *').remove();
        trafico_panorama_mensual_Tiempo_Promedio_acumulado = nv.models.pieChart()
            .x(function(d) { return d.label })
            .y(function(d) { return d.value })
            .showLabels(true)
            .labelThreshold(.05)  //Configure the minimum slice size for labels to show up
            .labelType("percent")   //Configure what type of data to show in the label. Can be "key", "value" or "percent"
            .donut(true)          //Turn on Donut mode. Makes pie chart look tasty!
            .donutRatio(0.35)     //Configure how big you want the donut hole size to be.
            .color(d3.scale.category20().range())
            /*.useInteractiveGuideline(true)*/
            ;

        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Tiempo_Promedio", '#trafico_panorama_mensual_Tiempo_Promedio_acumulado svg', trafico_panorama_mensual_Tiempo_Promedio_acumulado);

        trafico_panorama_mensual_Tiempo_Promedio_acumulado.update;
        return trafico_panorama_mensual_Tiempo_Promedio_acumulado;
    });
};

////// Tendencia
function start_trafico_panorama_mensual_Tiempo_Promedio_tendencia(){
    var tickvalues = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1), new Date(2016, 2,1), new Date(2016, 4,1)];
    //var tickvalues = ['May 2015', 'Jul 2015', 'Sep 2015', 'Nov 2015', 'Ene 2016'];
    
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Tiempo_Promedio_tendencia svg > *').remove();
        trafico_panorama_mensual_Tiempo_Promedio_tendencia = nv.models.lineChart()
            .x(function(d) { return new Date(d.label.split("-")[0], (d.label.split("-")[1]-1), d.label.split("-")[2]) })
            .xScale(d3.time.scale())
            .y(function(d) { return d.value })
            .yDomain([0, 10000000])
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .color(d3.scale.category20().range())
            .useInteractiveGuideline(true)
            ;
        
        trafico_panorama_mensual_Tiempo_Promedio_tendencia.xAxis
            .tickValues(tickvalues)
            .tickFormat(function(d) { return d3.time.format("%b %Y")(d) })
            ;
        
        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Tiempo_Promedio", '#trafico_panorama_mensual_Tiempo_Promedio_tendencia svg', trafico_panorama_mensual_Tiempo_Promedio_tendencia);

        trafico_panorama_mensual_Tiempo_Promedio_tendencia.update;
        return trafico_panorama_mensual_Tiempo_Promedio_tendencia;
    });
};

////// Visitas

////// Cuadro
function start_trafico_panorama_mensual_Visitas_tabla(){
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Visitas", '#trafico_panorama_mensual_Visitas_tabla');
};

////// Semaforo
function start_trafico_panorama_mensual_Visitas_indicador(){
    setTableSemaforo("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Visitas", '#trafico_panorama_mensual_Visitas_indicador');
};

////// Acumulado
function start_trafico_panorama_mensual_Visitas_acumulado(){
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Visitas_acumulado svg > *').remove();
        trafico_panorama_mensual_Visitas_acumulado = nv.models.pieChart()
            .x(function(d) { return d.label })
            .y(function(d) { return d.value })
            .showLabels(true)
            .labelThreshold(.05)  //Configure the minimum slice size for labels to show up
            .labelType("percent")   //Configure what type of data to show in the label. Can be "key", "value" or "percent"
            .donut(true)          //Turn on Donut mode. Makes pie chart look tasty!
            .donutRatio(0.35)     //Configure how big you want the donut hole size to be.
            .color(d3.scale.category20().range())
            /*.useInteractiveGuideline(true)*/
            ;

        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Visitas", '#trafico_panorama_mensual_Visitas_acumulado svg', trafico_panorama_mensual_Visitas_acumulado);

        trafico_panorama_mensual_Visitas_acumulado.update;
        return trafico_panorama_mensual_Visitas_acumulado;
    });
};

////// Tendencia
function start_trafico_panorama_mensual_Visitas_tendencia(){
    var tickvalues = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1), new Date(2016, 2,1), new Date(2016, 4,1)];
    //var tickvalues = ['May 2015', 'Jul 2015', 'Sep 2015', 'Nov 2015', 'Ene 2016'];
    
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Visitas_tendencia svg > *').remove();
        trafico_panorama_mensual_Visitas_tendencia = nv.models.lineChart()
            .x(function(d) { return new Date(d.label.split("-")[0], (d.label.split("-")[1]-1), d.label.split("-")[2]) })
            .xScale(d3.time.scale())
            .y(function(d) { return d.value })
            .yDomain([0, 10000000])
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .color(d3.scale.category20().range())
            .useInteractiveGuideline(true)
            ;
        
        trafico_panorama_mensual_Visitas_tendencia.xAxis
            .tickValues(tickvalues)
            .tickFormat(function(d) { return d3.time.format("%b %Y")(d) })
            ;
        
        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Visitas", '#trafico_panorama_mensual_Visitas_tendencia svg', trafico_panorama_mensual_Visitas_tendencia);

        trafico_panorama_mensual_Visitas_tendencia.update;
        return trafico_panorama_mensual_Visitas_tendencia;
    });
};

////// Abandono

////// Cuadro
function start_trafico_panorama_mensual_Abandono_tabla(){
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Abandono", '#trafico_panorama_mensual_Abandono_tabla');
};

////// Semaforo
function start_trafico_panorama_mensual_Abandono_indicador(){
    setTableSemaforo("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Abandono", '#trafico_panorama_mensual_Abandono_indicador');
};

////// Acumulado
function start_trafico_panorama_mensual_Abandono_acumulado(){
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Abandono_acumulado svg > *').remove();
        trafico_panorama_mensual_Abandono_acumulado = nv.models.pieChart()
            .x(function(d) { return d.label })
            .y(function(d) { return d.value })
            .showLabels(true)
            .labelThreshold(.05)  //Configure the minimum slice size for labels to show up
            .labelType("percent")   //Configure what type of data to show in the label. Can be "key", "value" or "percent"
            .donut(true)          //Turn on Donut mode. Makes pie chart look tasty!
            .donutRatio(0.35)     //Configure how big you want the donut hole size to be.
            .color(d3.scale.category20().range())
            /*.useInteractiveGuideline(true)*/
            ;

        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Abandono", '#trafico_panorama_mensual_Abandono_acumulado svg', trafico_panorama_mensual_Abandono_acumulado);

        trafico_panorama_mensual_Abandono_acumulado.update;
        return trafico_panorama_mensual_Abandono_acumulado;
    });
};

////// Tendencia
function start_trafico_panorama_mensual_Abandono_tendencia(){
    var tickvalues = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1), new Date(2016, 2,1), new Date(2016, 4,1)];
    //var tickvalues = ['May 2015', 'Jul 2015', 'Sep 2015', 'Nov 2015', 'Ene 2016'];
    
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Abandono_tendencia svg > *').remove();
        trafico_panorama_mensual_Abandono_tendencia = nv.models.lineChart()
            .x(function(d) { return new Date(d.label.split("-")[0], (d.label.split("-")[1]-1), d.label.split("-")[2]) })
            .xScale(d3.time.scale())
            .y(function(d) { return d.value })
            .yDomain([0, 10000000])
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .color(d3.scale.category20().range())
            .useInteractiveGuideline(true)
            ;
        
        trafico_panorama_mensual_Abandono_tendencia.xAxis
            .tickValues(tickvalues)
            .tickFormat(function(d) { return d3.time.format("%b %Y")(d) })
            ;
        
        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Abandono", '#trafico_panorama_mensual_Abandono_tendencia svg', trafico_panorama_mensual_Abandono_tendencia);

        trafico_panorama_mensual_Abandono_tendencia.update;
        return trafico_panorama_mensual_Abandono_tendencia;
    });
};

////// Trafico_Neto

////// Cuadro
function start_trafico_panorama_mensual_Trafico_Neto_tabla(){
    setTable("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tabla&tipo=Trafico_Neto", '#trafico_panorama_mensual_Trafico_Neto_tabla');
};

////// Semaforo
function start_trafico_panorama_mensual_Trafico_Neto_indicador(){
    setTableSemaforo("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_indicador&tipo=Trafico_Neto", '#trafico_panorama_mensual_Trafico_Neto_indicador');
};

////// Acumulado
function start_trafico_panorama_mensual_Trafico_Neto_acumulado(){
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Trafico_Neto_acumulado svg > *').remove();
        trafico_panorama_mensual_Trafico_Neto_acumulado = nv.models.pieChart()
            .x(function(d) { return d.label })
            .y(function(d) { return d.value })
            .showLabels(true)
            .labelThreshold(.05)  //Configure the minimum slice size for labels to show up
            .labelType("percent")   //Configure what type of data to show in the label. Can be "key", "value" or "percent"
            .donut(true)          //Turn on Donut mode. Makes pie chart look tasty!
            .donutRatio(0.35)     //Configure how big you want the donut hole size to be.
            .color(d3.scale.category20().range())
            /*.useInteractiveGuideline(true)*/
            ;

        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_acumulado&tipo=Trafico_Neto", '#trafico_panorama_mensual_Trafico_Neto_acumulado svg', trafico_panorama_mensual_Trafico_Neto_acumulado);

        trafico_panorama_mensual_Trafico_Neto_acumulado.update;
        return trafico_panorama_mensual_Trafico_Neto_acumulado;
    });
};

////// Tendencia
function start_trafico_panorama_mensual_Trafico_Neto_tendencia(){
    var tickvalues = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1), new Date(2016, 2,1), new Date(2016, 4,1)];
    //var tickvalues = ['May 2015', 'Jul 2015', 'Sep 2015', 'Nov 2015', 'Ene 2016'];
    
    nv.addGraph(function() {
        d3.select('#trafico_panorama_mensual_Trafico_Neto_tendencia svg > *').remove();
        trafico_panorama_mensual_Trafico_Neto_tendencia = nv.models.lineChart()
            .x(function(d) { return new Date(d.label.split("-")[0], (d.label.split("-")[1]-1), d.label.split("-")[2]) })
            .xScale(d3.time.scale())
            .y(function(d) { return d.value })
            .yDomain([0, 10000000])
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .color(d3.scale.category20().range())
            .useInteractiveGuideline(true)
            ;
        
        trafico_panorama_mensual_Trafico_Neto_tendencia.xAxis
            .tickValues(tickvalues)
            .tickFormat(function(d) { return d3.time.format("%b %Y")(d) })
            ;
        
        setGrafico_d3("backend/trafico.php?user="+user+"&action=trafico_panorama_mensual_tendencia&tipo=Trafico_Neto", '#trafico_panorama_mensual_Trafico_Neto_tendencia svg', trafico_panorama_mensual_Trafico_Neto_tendencia);

        trafico_panorama_mensual_Trafico_Neto_tendencia.update;
        return trafico_panorama_mensual_Trafico_Neto_tendencia;
    });
};





////// Grafico
function start_audiencia_interes_b100_grafico(){

    nv.addGraph(function() {
        d3.select('#audiencia_interes_b100_grafico svg > *').remove();
        
        audiencia_interes_b100_grafico = nv.models.multiBarChart()
            .x(function(d) { return d.label })
            .rotateLabels(-45)
            .y(function(d) { return d.value })
            .yDomain([0, 50])
            .color(d3.scale.category20().range())
            .barColor(d3.scale.category20().range())
            .reduceXTicks(false)
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .showControls(false)
            .useInteractiveGuideline(true);
            
        setGrafico_d3("backend/audiencia.php?user="+user+"&action=audiencia_interes_b100_grafico", '#audiencia_interes_b100_grafico svg', audiencia_interes_b100_grafico);

        audiencia_interes_b100_grafico.update;
        
        return audiencia_interes_b100_grafico;
    });
};


//// Intereses de la Audiencia

////// Cuadro
function start_audiencia_interes_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_interes_tabla", '#audiencia_interes_tabla');
};

////// Grafico
function start_audiencia_interes_grafico(){
    nv.addGraph(function() {
        d3.select('#audiencia_interes_grafico svg > *').remove();
        
        audiencia_interes_grafico = nv.models.multiBarChart()
            .x(function(d) { return d.label })
            .rotateLabels(-45)
            .y(function(d) { return d.value })
            .yDomain([0, 50])
            .color(d3.scale.category20().range())
            .barColor(d3.scale.category20().range())
            .reduceXTicks(false)
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .showControls(false)
            .useInteractiveGuideline(true);
            
        setGrafico_d3("backend/audiencia.php?user="+user+"&action=audiencia_interes_grafico", '#audiencia_interes_grafico svg', audiencia_interes_grafico);
        
        audiencia_interes_grafico.update;
        
        return audiencia_interes_grafico;
    });
};


//// Intereses de la Audiencia por Industria

//// Arte_Entretenimiento

////// Sitios
function start_audiencia_Arte_Entretenimiento_sites(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Arte_Entretenimiento", '#audiencia_Arte_Entretenimiento_sites');
};

////// Tabla - Musimundo
function start_audiencia_Arte_Entretenimiento_musimundo_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=0", '#audiencia_Arte_Entretenimiento_musimundo_tabla');
};

////// Grafico - Musimundo
function start_audiencia_Arte_Entretenimiento_musimundo_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_musimundo_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Fravega
function start_audiencia_Arte_Entretenimiento_fravega_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=1", '#audiencia_Arte_Entretenimiento_fravega_tabla');
};

////// Grafico - Fravega
function start_audiencia_Arte_Entretenimiento_fravega_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_fravega_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Garbarino
function start_audiencia_Arte_Entretenimiento_garbarino_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=2", '#audiencia_Arte_Entretenimiento_garbarino_tabla');
};

////// Grafico - Garbarino
function start_audiencia_Arte_Entretenimiento_garbarino_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_garbarino_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Avenida
function start_audiencia_Arte_Entretenimiento_avenida_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=3", '#audiencia_Arte_Entretenimiento_avenida_tabla');
};

////// Grafico - Avenida
function start_audiencia_Arte_Entretenimiento_avenida_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_avenida_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Internet_Telcos

////// Sitios
function start_audiencia_Internet_Telcos_sites(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Internet_Telcos", '#audiencia_Internet_Telcos_sites');
};

////// Tabla - Musimundo
function start_audiencia_Internet_Telcos_musimundo_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=0", '#audiencia_Internet_Telcos_musimundo_tabla');
};

////// Grafico - Musimundo
function start_audiencia_Internet_Telcos_musimundo_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_musimundo_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Fravega
function start_audiencia_Internet_Telcos_fravega_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=1", '#audiencia_Internet_Telcos_fravega_tabla');
};

////// Grafico - Fravega
function start_audiencia_Internet_Telcos_fravega_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_fravega_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Garbarino
function start_audiencia_Internet_Telcos_garbarino_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=2", '#audiencia_Internet_Telcos_garbarino_tabla');
};

////// Grafico - Garbarino
function start_audiencia_Internet_Telcos_garbarino_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_garbarino_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Avenida
function start_audiencia_Internet_Telcos_avenida_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=3", '#audiencia_Internet_Telcos_avenida_tabla');
};

////// Grafico - Avenida
function start_audiencia_Internet_Telcos_avenida_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_avenida_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Shoppings

////// Sitios
function start_audiencia_Shoppings_sites(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Shoppings", '#audiencia_Shoppings_sites');
};

////// Tabla - Musimundo
function start_audiencia_Shoppings_musimundo_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=0", '#audiencia_Shoppings_musimundo_tabla');
};

////// Grafico - Musimundo
function start_audiencia_Shoppings_musimundo_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_musimundo_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Fravega
function start_audiencia_Shoppings_fravega_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=1", '#audiencia_Shoppings_fravega_tabla');
};

////// Grafico - Fravega
function start_audiencia_Shoppings_fravega_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_fravega_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Garbarino
function start_audiencia_Shoppings_garbarino_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=2", '#audiencia_Shoppings_garbarino_tabla');
};

////// Grafico - Garbarino
function start_audiencia_Shoppings_garbarino_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_garbarino_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Avenida
function start_audiencia_Shoppings_avenida_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=3", '#audiencia_Shoppings_avenida_tabla');
};

////// Grafico - Avenida
function start_audiencia_Shoppings_avenida_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_avenida_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Noticias_Medios

////// Sitios
function start_audiencia_Noticias_Medios_sites(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Noticias_Medios", '#audiencia_Noticias_Medios_sites');
};

////// Tabla - Musimundo
function start_audiencia_Noticias_Medios_musimundo_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=0", '#audiencia_Noticias_Medios_musimundo_tabla');
};

////// Grafico - Musimundo
function start_audiencia_Noticias_Medios_musimundo_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_musimundo_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Fravega
function start_audiencia_Noticias_Medios_fravega_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=1", '#audiencia_Noticias_Medios_fravega_tabla');
};

////// Grafico - Fravega
function start_audiencia_Noticias_Medios_fravega_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_fravega_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Garbarino
function start_audiencia_Noticias_Medios_garbarino_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=2", '#audiencia_Noticias_Medios_garbarino_tabla');
};

////// Grafico - Garbarino
function start_audiencia_Noticias_Medios_garbarino_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_garbarino_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

////// Tabla - Avenida
function start_audiencia_Noticias_Medios_avenida_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=3", '#audiencia_Noticias_Medios_avenida_tabla');
};

////// Grafico - Avenida
function start_audiencia_Noticias_Medios_avenida_wordcloud(){
    var words = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_avenida_wordcloud'), { list: words, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};


//// Audiencia Sitios

////// Cuadro
function start_audiencia_sitios_ranking_tabla(){
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_sitios_ranking_tabla", '#audiencia_sitios_ranking_tabla');
};


////// Grafico Línea
function start_audiencia_industrias_line_grafico(){
    var tickvalues = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1)];
    //var tickvalues = ['May 2015', 'Jul 2015', 'Sep 2015', 'Nov 2015', 'Ene 2016'];
    
    nv.addGraph(function() {
        d3.select('#audiencia_industrias_line_grafico svg > *').remove();
        audiencia_industrias_line_grafico = nv.models.lineChart()
            .x(function(d) { return new Date(d.label.split("-")[0], (d.label.split("-")[1]-1), d.label.split("-")[2]) })
            .xScale(d3.time.scale())
            .y(function(d) { return d.value })
            .yDomain([0, 30])
            .duration(250)
            .margin({left: 75, right: 50, bottom: 100})
            .color(d3.scale.category20().range())
            .useInteractiveGuideline(true)
            ;
        
        audiencia_industrias_line_grafico.xAxis
            .tickValues(tickvalues)
            .tickFormat(function(d) { return d3.time.format("%b %Y")(d) })
            ;
        
        setGrafico_d3("backend/audiencia.php?user="+user+"&action=audiencia_industrias_line_grafico", '#audiencia_industrias_line_grafico svg', audiencia_industrias_line_grafico);

        audiencia_industrias_line_grafico.update;
        return audiencia_industrias_line_grafico;
    });
};


////// Grafico radar
function start_audiencia_industrias_radar_grafico(){
    setGrafico_chart("backend/audiencia.php?user="+user+"&action=audiencia_industrias_radar_grafico", "#audiencia_industrias_radar_grafico", "radar");
/*
    var ctx = $("#audiencia_industrias_radar_grafico");

    var data = {
        labels: ["Arte y Entretenimiento", "Internet & Telcos", "Shoppings", "Noticias & Medios", "Negocios e industrias", "Computer & Electronic"],

        datasets: [
            {
                label: "Musimundo",
                backgroundColor: "rgba(255,0,0,0.2)",
                borderColor: "rgba(255,0,0,1)",
                pointBackgroundColor: "rgba(255,0,0,1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(255,0,0,1)",
                data: [24.01, 12.62, 21.04, 18.56, 13.12, 10.64]
            },
            {
                label: "Fravega",
                backgroundColor: "rgba(0,51,204,0.2)",
                borderColor: "rgba(0,51,204,1)",
                pointBackgroundColor: "rgba(0,51,204,1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(0,51,204,1)",
                data: [16.25, 15.50, 23.25, 21.00, 15.50, 8.50]
            },
            {
                label: "Garbarino",
                backgroundColor: "rgba(0,102,0,0.2)",
                borderColor: "rgba(0,102,0,1)",
                pointBackgroundColor: "rgba(0,102,0,1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(0,102,0,1)",
                data: [16.10, 10.73, 27.80, 21.46, 16.59, 7.32]
            },
            {
                label: "Avenida",
                backgroundColor: "rgba(150,150,150,0.2)",
                borderColor: "rgba(150,150,150,1)",
                pointBackgroundColor: "rgba(150,150,150,1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(150,150,150,1)",
                data: [13.36, 11.64, 33.19, 18.10, 16.81, 6.90]
            },
        ]
    };

    var myRadarChart = new Chart(ctx, {
        type: 'radar',
        data: data
    });
    */
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var refresh_function = [];

$(document).ready(function() {
    NProgress.start();

    init_sidebar();
    NProgress.inc();
        
    start_trafico_panorama_mensual_Trafico_Total_tabla();
    start_trafico_panorama_mensual_Trafico_Total_indicador();
    start_trafico_panorama_mensual_Trafico_Total_acumulado();
    start_trafico_panorama_mensual_Trafico_Total_tendencia();
    NProgress.inc();
        
    start_trafico_panorama_mensual_Tiempo_Promedio_tabla();
    start_trafico_panorama_mensual_Tiempo_Promedio_indicador();
    NProgress.inc();
        
    start_trafico_panorama_mensual_Visitas_tabla();
    start_trafico_panorama_mensual_Visitas_indicador();
    NProgress.inc();
        
    start_trafico_panorama_mensual_Abandono_tabla();
    start_trafico_panorama_mensual_Abandono_indicador();
    NProgress.inc();
        
    start_trafico_panorama_mensual_Trafico_Neto_tabla();
    start_trafico_panorama_mensual_Trafico_Neto_indicador();
    NProgress.inc();

    
    
    /*
    NProgress.inc();
    
    start_audiencia_Arte_Entretenimiento_sites();
    start_audiencia_Arte_Entretenimiento_musimundo_tabla();
    start_audiencia_Arte_Entretenimiento_musimundo_wordcloud();
    start_audiencia_Arte_Entretenimiento_garbarino_tabla();
    start_audiencia_Arte_Entretenimiento_garbarino_wordcloud();
    start_audiencia_Arte_Entretenimiento_fravega_tabla();
    start_audiencia_Arte_Entretenimiento_fravega_wordcloud();
    start_audiencia_Arte_Entretenimiento_avenida_tabla();
    start_audiencia_Arte_Entretenimiento_avenida_wordcloud();
    NProgress.inc();
    start_audiencia_Internet_Telcos_sites();
    start_audiencia_Internet_Telcos_musimundo_tabla();
    start_audiencia_Internet_Telcos_musimundo_wordcloud();
    start_audiencia_Internet_Telcos_garbarino_tabla();
    start_audiencia_Internet_Telcos_garbarino_wordcloud();
    start_audiencia_Internet_Telcos_fravega_tabla();
    start_audiencia_Internet_Telcos_fravega_wordcloud();
    start_audiencia_Internet_Telcos_avenida_tabla();
    start_audiencia_Internet_Telcos_avenida_wordcloud();
    NProgress.inc();
    start_audiencia_Shoppings_sites();
    start_audiencia_Shoppings_musimundo_tabla();
    start_audiencia_Shoppings_musimundo_wordcloud();
    start_audiencia_Shoppings_garbarino_tabla();
    start_audiencia_Shoppings_garbarino_wordcloud();
    start_audiencia_Shoppings_fravega_tabla();
    start_audiencia_Shoppings_fravega_wordcloud();
    start_audiencia_Shoppings_avenida_tabla();
    start_audiencia_Shoppings_avenida_wordcloud();
    NProgress.inc();
    start_audiencia_Noticias_Medios_sites();
    start_audiencia_Noticias_Medios_musimundo_tabla();
    start_audiencia_Noticias_Medios_musimundo_wordcloud();
    start_audiencia_Noticias_Medios_garbarino_tabla();
    start_audiencia_Noticias_Medios_garbarino_wordcloud();
    start_audiencia_Noticias_Medios_fravega_tabla();
    start_audiencia_Noticias_Medios_fravega_wordcloud();
    start_audiencia_Noticias_Medios_avenida_tabla();
    start_audiencia_Noticias_Medios_avenida_wordcloud();
    NProgress.inc();
    
    start_audiencia_sitios_ranking_tabla();
    NProgress.inc();
    
    start_audiencia_industrias_line_grafico();
    */
    
    
    NProgress.done();
    
    $('body').scrollspy({ target: '#sidebar-menu' });
    
    $("#link_tab_trafico_panorama_mensual_Trafico_Total").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Total_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Total_tendencia");
    });
    $("#link_tab_trafico_panorama_mensual_Tiempo_Promedio").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Tiempo_Promedio_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Tiempo_Promedio_tendencia");
    });
    $("#link_tab_trafico_panorama_mensual_Visitas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Visitas_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Visitas_tendencia");
    });
    $("#link_tab_trafico_panorama_mensual_Abandono").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Abandono_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Abandono_tendencia");
    });
    $("#link_tab_trafico_panorama_mensual_Trafico_Neto").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Neto_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Neto_tendencia");
    });

    
    /*    
    $("#link_tab_audiencia_Arte_Entretenimiento").on("click", function() {
        refresh_function = [];
    });
    $("#link_tab_audiencia_Internet_Telcos").on("click", function() {
        refresh_function = [];
    });
    $("#link_tab_audiencia_Shoppings").on("click", function() {
        refresh_function = [];
    });
    $("#link_tab_audiencia_Noticias_Medios").on("click", function() {
        refresh_function = [];
    });
    
    $("#link_tab_audiencia_industrias_line_grafico").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_industrias_line_grafico");
    });
    $("#link_tab_audiencia_industrias_radar_grafico").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_industrias_radar_grafico");
    });
    */

    
    
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        NProgress.start();
        //alert(e.target); // newly activated tab
        //e.relatedTarget // previous active tab
        var i;
        for (i = 0; i < refresh_function.length; i++) {
            window[refresh_function[i]]();
        };
        NProgress.done();
    });
});

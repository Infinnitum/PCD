
var user = 1;
var fechas = [new Date(2015, 4,1), new Date(2015, 6,1), new Date(2015, 8,1), new Date(2015,10,1), new Date(2016, 0,1)];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Audiencia

//// Intereses de la Audiencia b=100

////// Cuadro
function start_audiencia_interes_b100_tabla() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_interes_b100_tabla", '#audiencia_interes_b100_tabla');
};
////// Grafico
function start_audiencia_interes_b100_grafico() {
    addMultiBarChart("backend/audiencia.php?user="+user+"&action=audiencia_interes_b100_grafico", "#audiencia_interes_b100_grafico svg");
};


//// Intereses de la Audiencia

////// Cuadro
function start_audiencia_interes_tabla() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_interes_tabla", '#audiencia_interes_tabla');
};
////// Grafico
function start_audiencia_interes_grafico() {
    addMultiBarChart("backend/audiencia.php?user="+user+"&action=audiencia_interes_grafico", "#audiencia_interes_grafico svg");
};


//// Intereses de la Audiencia por Industria

//// Arte_Entretenimiento

////// Sitios
function start_audiencia_Arte_Entretenimiento_sites() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Arte_Entretenimiento", '#audiencia_Arte_Entretenimiento_sites');
};
////// Tablas
function start_audiencia_Arte_Entretenimiento_tablas() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=1", '#audiencia_Arte_Entretenimiento_1_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=2", '#audiencia_Arte_Entretenimiento_2_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=3", '#audiencia_Arte_Entretenimiento_3_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=4", '#audiencia_Arte_Entretenimiento_4_tabla');
};
////// Graficos
function start_audiencia_Arte_Entretenimiento_wordcloud() {
    var words1 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_1_wordcloud'), { list: words1, rotateRatio: 0, minRotation: 0, maxRotation: 0 });

    var words2 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_2_wordcloud'), { list: words2, rotateRatio: 0, minRotation: 0, maxRotation: 0 });

    var words3 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_3_wordcloud'), { list: words3, rotateRatio: 0, minRotation: 0, maxRotation: 0 });

    var words4 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Arte_Entretenimiento_4_wordcloud'), { list: words4, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Internet_Telcos

////// Sitios
function start_audiencia_Internet_Telcos_sites() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Internet_Telcos", '#audiencia_Internet_Telcos_sites');
};
////// Tablas
function start_audiencia_Internet_Telcos_tablas() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=1", '#audiencia_Internet_Telcos_1_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=2", '#audiencia_Internet_Telcos_2_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=3", '#audiencia_Internet_Telcos_3_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=4", '#audiencia_Internet_Telcos_4_tabla');
};
////// Graficos
function start_audiencia_Internet_Telcos_wordcloud() {
    var words1 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_1_wordcloud'), { list: words1, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words2 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_2_wordcloud'), { list: words2, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words3 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_3_wordcloud'), { list: words3, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words4 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Internet_Telcos_4_wordcloud'), { list: words4, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Shoppings

////// Sitios
function start_audiencia_Shoppings_sites() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Shoppings", '#audiencia_Shoppings_sites');
};
////// Tablas
function start_audiencia_Shoppings_tablas() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=1", '#audiencia_Shoppings_1_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=2", '#audiencia_Shoppings_2_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=3", '#audiencia_Shoppings_3_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=4", '#audiencia_Shoppings_4_tabla');
};
////// Graficos
function start_audiencia_Shoppings_wordcloud() {
    var words1 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_1_wordcloud'), { list: words1, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words2 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_2_wordcloud'), { list: words2, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words3 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_3_wordcloud'), { list: words3, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words4 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Shoppings_4_wordcloud'), { list: words4, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
};

//// Noticias_Medios

////// Sitios
function start_audiencia_Noticias_Medios_sites() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_sites&industria=Noticias_Medios", '#audiencia_Noticias_Medios_sites');
};
////// Tablas
function start_audiencia_Noticias_Medios_tablas() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=1", '#audiencia_Noticias_Medios_1_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=2", '#audiencia_Noticias_Medios_2_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=3", '#audiencia_Noticias_Medios_3_tabla');
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=4", '#audiencia_Noticias_Medios_4_tabla');
};
////// Grafico
function start_audiencia_Noticias_Medios_wordcloud() {
    var words1 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_1_wordcloud'), { list: words1, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words2 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_2_wordcloud'), { list: words2, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words3 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_3_wordcloud'), { list: words3, rotateRatio: 0, minRotation: 0, maxRotation: 0 });
    
    var words4 = [["Hello", 150], ["world", 40], ["normally", 30], ["you", 120], ["want", 15], ["more", 12], ["words", 8], ["than", 5], ["this", 3]];
    WordCloud(document.getElementById('audiencia_Noticias_Medios_4_wordcloud'), { list: words4, rotateRatio: 0, minRotation: 0, maxRotation: 0 });    
};

//// Audiencia Sitios

////// Cuadro
function start_audiencia_sitios_ranking_tabla() {
    setTable("backend/audiencia.php?user="+user+"&action=audiencia_sitios_ranking_tabla", '#audiencia_sitios_ranking_tabla');
};
////// Grafico Línea
function start_audiencia_industrias_line_grafico() {
    addLineChartDates("backend/audiencia.php?user="+user+"&action=audiencia_industrias_line_grafico", "#audiencia_industrias_line_grafico svg", fechas);
};
////// Grafico radar
function start_audiencia_industrias_radar_grafico() {
    setGrafico_chart("backend/audiencia.php?user="+user+"&action=audiencia_industrias_radar_grafico", "#audiencia_industrias_radar_grafico", "radar");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var refresh_function = [];

$(document).ready(function() {
    NProgress.start();
    
    $('body').scrollspy({ target: '#sidebar-menu' });
    init_sidebar();
    NProgress.inc();
    
    
    
    start_audiencia_interes_tabla();
    start_audiencia_interes_grafico();
    $("#link_tab_audiencia_interes").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_interes_grafico");
    });
    NProgress.inc();
    
    start_audiencia_interes_b100_tabla();
    $("#link_tab_audiencia_interes_b100").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_interes_b100_grafico");
    });
    NProgress.inc();
    
    
    
    start_audiencia_Arte_Entretenimiento_sites();
    start_audiencia_Arte_Entretenimiento_tablas();
    start_audiencia_Arte_Entretenimiento_wordcloud();
    $("#link_tab_audiencia_Arte_Entretenimiento").on("click", function() {
        refresh_function = [];
    });
    NProgress.inc();
    
    start_audiencia_Internet_Telcos_sites();
    start_audiencia_Internet_Telcos_tablas();
    start_audiencia_Internet_Telcos_wordcloud();
    $("#link_tab_audiencia_Internet_Telcos").on("click", function() {
        refresh_function = [];
    });
    NProgress.inc();
    
    start_audiencia_Shoppings_sites();
    start_audiencia_Shoppings_tablas();
    start_audiencia_Shoppings_wordcloud();
    $("#link_tab_audiencia_Shoppings").on("click", function() {
        refresh_function = [];
    });
    NProgress.inc();
    
    start_audiencia_Noticias_Medios_sites();
    start_audiencia_Noticias_Medios_tablas();
    start_audiencia_Noticias_Medios_wordcloud();
    $("#link_tab_audiencia_Noticias_Medios").on("click", function() {
        refresh_function = [];
    });
    NProgress.inc();
    
    
    
    start_audiencia_sitios_ranking_tabla();
    NProgress.inc();
    
    
    
    start_audiencia_industrias_line_grafico();
    $("#link_tab_audiencia_industrias_line_grafico").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_industrias_line_grafico");
    });
    NProgress.inc();

    $("#link_tab_audiencia_industrias_radar_grafico").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_industrias_radar_grafico");
    });
    NProgress.inc();
    
    
    
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        NProgress.start();
        //alert(e.target); // newly activated tab
        //e.relatedTarget // previous active tab
        var i;
        for (i = 0; i < refresh_function.length; i++) {
            window[refresh_function[i]]();
        };
        refresh_function = [];
        NProgress.done();
    });
    
    NProgress.done();
});

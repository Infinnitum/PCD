
function getJSON(url, success) {
    $.ajax({
        url: url,
        dataType: "json",
        success: success
    });
};

var user = 1;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function login_check(){
    var url = "backend/login.php?user=pepe&pass=pepe";
    
    getJSON(url,
            function(result) {
                alert(result);
            });
};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


$(document).ready(function() {
    NProgress.start();
    NProgress.done();
        
    $("#login").on("click", function() {
        login_check();
    });
});

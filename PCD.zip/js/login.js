
function getJSON(url, success) {
    $.ajax({
        url: url,
        dataType: "json",
        success: success
    });
};

var user = 1;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function login_check(){
    $("#error_msg").text('');
    var user = $(document).find('#user').val();
    
    if (user != "") {
        var pass = $(document).find('#pass').val();
        var url = "backend/login.php?user="+user+"&pass="+pass;
        
        getJSON(url,
                function(result) {
                    if (result.STATUS == "SUCCESS") {
                        saveCookie(result.USER_ID);
                        window.location.href = 'index.html';
                    }
                    else {
                        $("#error_msg").text("Usuario o contraseña incorrectas");
                    }
                });
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function saveCookie(value) {
    var today = new Date(); // Actual date
    var expire = new Date(); // Expiration of the cookie

    var cookie_name = "PCD"; // Name for the cookie to be recognized
    var number_of_days = 10; // Number of days for the cookie to be valid (10 in this case)

    expire.setTime( today.getTime() + 60 * 60 * 1000 * 24 * number_of_days ); // Current time + (60 sec * 60 min * 1000 milisecs * 24 hours * number_of_days)

    document.cookie = cookie_name + "=" + escape(value) + "; expires=" + expire.toGMTString();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    NProgress.start();
    NProgress.done();
        
    $("#login").on("click", function() {
        login_check();
    });
});

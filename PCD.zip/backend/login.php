<?php

include_once("lib.php");

// Ejemplo
function get_posts($user_id) {
	$query = "SELECT post_title, guid FROM (SELECT 'pepe1' as post_title, 1 as guid union SELECT 'pepe2' as post_title, 2 as guid union SELECT 'pepe3' as post_title, 3 as guid) tmp ORDER BY guid DESC";

    $result = dataset($query);

	$posts = array();
	if(mysql_num_rows($result)) {
		while($post = mysql_fetch_assoc($result)) {
			$posts[] = array('post'=>$post);
		}
	}

    to_json(array('posts'=>$posts));
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Prototipo de datos

function table_simple($query) {
    $result = dataset($query);

	$rows = array();
	if(mysql_num_rows($result)) {
		while($row = mysql_fetch_assoc($result)) {
			$rows[] = $row;
		}
	}

    return $rows;
}


function array_simple($query, $claves) {
    $table = table_simple($query);
    $a = array();
    
    foreach ($table as $row) {
        foreach ($row as $key => $value) {
            foreach ($claves as $clave) {
                if ($key == $clave) {
                    array_push($a, $value);
                }
            }
        }
    }
    
    return $a;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_check_login($user, $pass) {
    $query = "SELECT USER_ID, 'SUCCESS' AS STATUS
              FROM (SELECT 1 AS USER_ID) TMP";
/*
    $query = "SELECT USER_ID, 'SUCCESS' AS STATUS
              FROM TB_USERS
              WHERE USER='".$user."' AND PASS='".$pass."'";
*/              
    to_json(table_simple($query));
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$user = intval($_GET['user']);
$pass = intval($_GET['pass']);

get_check_login($user, $pass);

?>

<?php

include_once("lib.php");

// Ejemplo
function get_posts($user_id) {
	$query = "SELECT post_title, guid FROM (SELECT 'pepe1' as post_title, 1 as guid union SELECT 'pepe2' as post_title, 2 as guid union SELECT 'pepe3' as post_title, 3 as guid) tmp ORDER BY guid DESC";

    $result = dataset($query);

	$posts = array();
	if(mysql_num_rows($result)) {
		while($post = mysql_fetch_assoc($result)) {
			$posts[] = array('post'=>$post);
		}
	}

    to_json(array('posts'=>$posts));
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Prototipo de datos

function table_simple($query) {
    $result = dataset($query);

	$rows = array();
	if(mysql_num_rows($result)) {
		while($row = mysql_fetch_assoc($result)) {
			$rows[] = $row;
		}
	}

    return $rows;
}


function array_simple($query, $claves) {
    $table = table_simple($query);
    $a = array();
    
    foreach ($table as $row) {
        foreach ($row as $key => $value) {
            foreach ($claves as $clave) {
                if ($key == $clave) {
                    array_push($a, $value);
                }
            }
        }
    }
    
    return $a;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function competidores($user_id, $pos, $labels) {
    //return ['Musimundo', 'Fravega', 'Garbarino', 'Avenida'];
    
	$query = "SELECT label, backgroundColor, borderColor, pointBackgroundColor, pointBorderColor, pointHoverBackgroundColor, pointHoverBorderColor
              FROM (SELECT 1 AS ORD,
                           'Musimundo' AS label,
                           'rgba(255,0,0,0.2)' AS backgroundColor,
                           'rgba(255,0,0,1)' AS borderColor,
                           'rgba(255,0,0,1)' AS pointBackgroundColor,
                           '#fff' AS pointBorderColor,
                           '#fff' AS pointHoverBackgroundColor,
                           'rgba(255,0,0,1)' AS pointHoverBorderColor
                    UNION
                    SELECT 2 AS ORD,
                           'Fravega' AS label,
                           'rgba(0,51,204,0.2)' AS backgroundColor,
                           'rgba(0,51,204,1)' AS borderColor,
                           'rgba(0,51,204,1)' AS pointBackgroundColor,
                           '#fff' AS pointBorderColor,
                           '#fff' AS pointHoverBackgroundColor,
                           'rgba(0,51,204,1)' AS pointHoverBorderColor
                    UNION
                    SELECT 3 AS ORD,
                           'Garbarino' AS label,
                           'rgba(0,102,0,0.2)' AS backgroundColor,
                           'rgba(0,102,0,1)' AS borderColor,
                           'rgba(0,102,0,1)' AS pointBackgroundColor,
                           '#fff' AS pointBorderColor,
                           '#fff' AS pointHoverBackgroundColor,
                           'rgba(0,102,0,1)' AS pointHoverBorderColor
                    UNION
                    SELECT 4 AS ORD,
                           'Avenida' AS label,
                           'rgba(150,150,150,0.2)' AS backgroundColor,
                           'rgba(150,150,150,1)' AS borderColor,
                           'rgba(150,150,150,1)' AS pointBackgroundColor,
                           '#fff' AS pointBorderColor,
                           '#fff' AS pointHoverBackgroundColor,
                           'rgba(150,150,150,1)' AS pointHoverBorderColor) TMP
              WHERE (ORD = ".$pos." OR ".$pos." = -1)
              ORDER BY ORD";
  
    return array_simple($query, $labels);
}

function competidor_label($user_id, $pos) {
    return competidores($user_id, $pos, ["label"])[0];
}


function get_trafico_panorama_mensual_tabla($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $query = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461 AS M201511, 2222914 AS M201601, 1512917 AS M201603, 2460873 AS M201605 UNION
                        SELECT 1 AS ORD, 'Share' AS VARIABLE, 22.10 AS M201505, 20.21 AS M201507, 20.24 AS M201509, 21.18 AS M201511, 22.24 AS M201601, 15.03 AS M201603, 15.84 AS M201605 UNION
                        SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -37.34 AS M201507, 16.35 AS M201509, 76.36 AS M201511, -1.18 AS M201601, -31.94 AS M201603, 62.66 AS M201605 UNION
                        SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667 AS M201511, 3204757 AS M201601, 2607042 AS M201603, 4163589 AS M201605 UNION
                        SELECT 4 AS ORD, 'Share' AS VARIABLE, 31.19 AS M201505, 31.06 AS M201507, 28.87 AS M201509, 30.74 AS M201511, 32.06 AS M201601, 25.90 AS M201603, 26.80 AS M201605 UNION
                        SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -31.77 AS M201507, 7.96 AS M201509, 79.41 AS M201511, -1.81 AS M201601, -18.65 AS M201603, 59.71 AS M201605 UNION
                        SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                        SELECT 7 AS ORD, 'Share' AS VARIABLE, 32.17 AS M201505, 36.35 AS M201507, 33.37 AS M201509, 36.97 AS M201511, 37.29 AS M201601, 47.09 AS M201603, 47.17 AS M201605 UNION
                        SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -22.57 AS M201507, 6.64 AS M201509, 86.64 AS M201511, -5.06 AS M201601, 27.18 AS M201603, 54.59 AS M201605 UNION
                        SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572 AS M201511, 840917 AS M201601, 1206563 AS M201603, 1582283 AS M201605 UNION
                        SELECT 10 AS ORD, 'Share' AS VARIABLE, 14.54 AS M201505, 12.38 AS M201507, 17.52 AS M201509, 11.11 AS M201511, 8.41 AS M201601, 11.99 AS M201603, 10.19 AS M201605 UNION
                        SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -41.66 AS M201507, 64.35 AS M201509, 6.84 AS M201511, -28.71 AS M201601, 43.48 AS M201603, 31.14 AS M201605) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Tiempo_Promedio") {
        $query = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461 AS M201511, 2222914 AS M201601, 1512917 AS M201603, 2460873 AS M201605 UNION
                        SELECT 1 AS ORD, 'Share' AS VARIABLE, 22.10 AS M201505, 20.21 AS M201507, 20.24 AS M201509, 21.18 AS M201511, 22.24 AS M201601, 15.03 AS M201603, 15.84 AS M201605 UNION
                        SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -37.34 AS M201507, 16.35 AS M201509, 76.36 AS M201511, -1.18 AS M201601, -31.94 AS M201603, 62.66 AS M201605 UNION
                        SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667 AS M201511, 3204757 AS M201601, 2607042 AS M201603, 4163589 AS M201605 UNION
                        SELECT 4 AS ORD, 'Share' AS VARIABLE, 31.19 AS M201505, 31.06 AS M201507, 28.87 AS M201509, 30.74 AS M201511, 32.06 AS M201601, 25.90 AS M201603, 26.80 AS M201605 UNION
                        SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -31.77 AS M201507, 7.96 AS M201509, 79.41 AS M201511, -1.81 AS M201601, -18.65 AS M201603, 59.71 AS M201605 UNION
                        SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                        SELECT 7 AS ORD, 'Share' AS VARIABLE, 32.17 AS M201505, 36.35 AS M201507, 33.37 AS M201509, 36.97 AS M201511, 37.29 AS M201601, 47.09 AS M201603, 47.17 AS M201605 UNION
                        SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -22.57 AS M201507, 6.64 AS M201509, 86.64 AS M201511, -5.06 AS M201601, 27.18 AS M201603, 54.59 AS M201605 UNION
                        SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572 AS M201511, 840917 AS M201601, 1206563 AS M201603, 1582283 AS M201605 UNION
                        SELECT 10 AS ORD, 'Share' AS VARIABLE, 14.54 AS M201505, 12.38 AS M201507, 17.52 AS M201509, 11.11 AS M201511, 8.41 AS M201601, 11.99 AS M201603, 10.19 AS M201605 UNION
                        SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -41.66 AS M201507, 64.35 AS M201509, 6.84 AS M201511, -28.71 AS M201601, 43.48 AS M201603, 31.14 AS M201605) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Visitas") {
        $query = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461 AS M201511, 2222914 AS M201601, 1512917 AS M201603, 2460873 AS M201605 UNION
                        SELECT 1 AS ORD, 'Share' AS VARIABLE, 22.10 AS M201505, 20.21 AS M201507, 20.24 AS M201509, 21.18 AS M201511, 22.24 AS M201601, 15.03 AS M201603, 15.84 AS M201605 UNION
                        SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -37.34 AS M201507, 16.35 AS M201509, 76.36 AS M201511, -1.18 AS M201601, -31.94 AS M201603, 62.66 AS M201605 UNION
                        SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667 AS M201511, 3204757 AS M201601, 2607042 AS M201603, 4163589 AS M201605 UNION
                        SELECT 4 AS ORD, 'Share' AS VARIABLE, 31.19 AS M201505, 31.06 AS M201507, 28.87 AS M201509, 30.74 AS M201511, 32.06 AS M201601, 25.90 AS M201603, 26.80 AS M201605 UNION
                        SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -31.77 AS M201507, 7.96 AS M201509, 79.41 AS M201511, -1.81 AS M201601, -18.65 AS M201603, 59.71 AS M201605 UNION
                        SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                        SELECT 7 AS ORD, 'Share' AS VARIABLE, 32.17 AS M201505, 36.35 AS M201507, 33.37 AS M201509, 36.97 AS M201511, 37.29 AS M201601, 47.09 AS M201603, 47.17 AS M201605 UNION
                        SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -22.57 AS M201507, 6.64 AS M201509, 86.64 AS M201511, -5.06 AS M201601, 27.18 AS M201603, 54.59 AS M201605 UNION
                        SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572 AS M201511, 840917 AS M201601, 1206563 AS M201603, 1582283 AS M201605 UNION
                        SELECT 10 AS ORD, 'Share' AS VARIABLE, 14.54 AS M201505, 12.38 AS M201507, 17.52 AS M201509, 11.11 AS M201511, 8.41 AS M201601, 11.99 AS M201603, 10.19 AS M201605 UNION
                        SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -41.66 AS M201507, 64.35 AS M201509, 6.84 AS M201511, -28.71 AS M201601, 43.48 AS M201603, 31.14 AS M201605) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Abandono") {
        $query = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461 AS M201511, 2222914 AS M201601, 1512917 AS M201603, 2460873 AS M201605 UNION
                        SELECT 1 AS ORD, 'Share' AS VARIABLE, 22.10 AS M201505, 20.21 AS M201507, 20.24 AS M201509, 21.18 AS M201511, 22.24 AS M201601, 15.03 AS M201603, 15.84 AS M201605 UNION
                        SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -37.34 AS M201507, 16.35 AS M201509, 76.36 AS M201511, -1.18 AS M201601, -31.94 AS M201603, 62.66 AS M201605 UNION
                        SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667 AS M201511, 3204757 AS M201601, 2607042 AS M201603, 4163589 AS M201605 UNION
                        SELECT 4 AS ORD, 'Share' AS VARIABLE, 31.19 AS M201505, 31.06 AS M201507, 28.87 AS M201509, 30.74 AS M201511, 32.06 AS M201601, 25.90 AS M201603, 26.80 AS M201605 UNION
                        SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -31.77 AS M201507, 7.96 AS M201509, 79.41 AS M201511, -1.81 AS M201601, -18.65 AS M201603, 59.71 AS M201605 UNION
                        SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                        SELECT 7 AS ORD, 'Share' AS VARIABLE, 32.17 AS M201505, 36.35 AS M201507, 33.37 AS M201509, 36.97 AS M201511, 37.29 AS M201601, 47.09 AS M201603, 47.17 AS M201605 UNION
                        SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -22.57 AS M201507, 6.64 AS M201509, 86.64 AS M201511, -5.06 AS M201601, 27.18 AS M201603, 54.59 AS M201605 UNION
                        SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572 AS M201511, 840917 AS M201601, 1206563 AS M201603, 1582283 AS M201605 UNION
                        SELECT 10 AS ORD, 'Share' AS VARIABLE, 14.54 AS M201505, 12.38 AS M201507, 17.52 AS M201509, 11.11 AS M201511, 8.41 AS M201601, 11.99 AS M201603, 10.19 AS M201605 UNION
                        SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -41.66 AS M201507, 64.35 AS M201509, 6.84 AS M201511, -28.71 AS M201601, 43.48 AS M201603, 31.14 AS M201605) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Trafico_Neto") {
        $query = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461 AS M201511, 2222914 AS M201601, 1512917 AS M201603, 2460873 AS M201605 UNION
                        SELECT 1 AS ORD, 'Share' AS VARIABLE, 22.10 AS M201505, 20.21 AS M201507, 20.24 AS M201509, 21.18 AS M201511, 22.24 AS M201601, 15.03 AS M201603, 15.84 AS M201605 UNION
                        SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -37.34 AS M201507, 16.35 AS M201509, 76.36 AS M201511, -1.18 AS M201601, -31.94 AS M201603, 62.66 AS M201605 UNION
                        SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667 AS M201511, 3204757 AS M201601, 2607042 AS M201603, 4163589 AS M201605 UNION
                        SELECT 4 AS ORD, 'Share' AS VARIABLE, 31.19 AS M201505, 31.06 AS M201507, 28.87 AS M201509, 30.74 AS M201511, 32.06 AS M201601, 25.90 AS M201603, 26.80 AS M201605 UNION
                        SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -31.77 AS M201507, 7.96 AS M201509, 79.41 AS M201511, -1.81 AS M201601, -18.65 AS M201603, 59.71 AS M201605 UNION
                        SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                        SELECT 7 AS ORD, 'Share' AS VARIABLE, 32.17 AS M201505, 36.35 AS M201507, 33.37 AS M201509, 36.97 AS M201511, 37.29 AS M201601, 47.09 AS M201603, 47.17 AS M201605 UNION
                        SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -22.57 AS M201507, 6.64 AS M201509, 86.64 AS M201511, -5.06 AS M201601, 27.18 AS M201603, 54.59 AS M201605 UNION
                        SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572 AS M201511, 840917 AS M201601, 1206563 AS M201603, 1582283 AS M201605 UNION
                        SELECT 10 AS ORD, 'Share' AS VARIABLE, 14.54 AS M201505, 12.38 AS M201507, 17.52 AS M201509, 11.11 AS M201511, 8.41 AS M201601, 11.99 AS M201603, 10.19 AS M201605 UNION
                        SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -41.66 AS M201507, 64.35 AS M201509, 6.84 AS M201511, -28.71 AS M201601, 43.48 AS M201603, 31.14 AS M201605) TMP
                  ORDER BY ORD";
    }

    to_json(table_simple($query));
}

function get_trafico_panorama_mensual_indicador($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $query = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Tiempo_Promedio") {
        $query = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Visitas") {
        $query = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Abandono") {
        $query = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Trafico_Neto") {
        $query = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                        SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR) TMP
                  ORDER BY ORD";
    }

    to_json(table_simple($query));
}

function get_trafico_panorama_mensual_acumulado($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 12567510.29 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 19212721.86 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 26343565.53 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 7736608.06 AS value) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Tiempo_Promedio") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 12567510.29 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 19212721.86 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 26343565.53 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 7736608.06 AS value) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Visitas") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 12567510.29 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 19212721.86 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 26343565.53 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 7736608.06 AS value) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Abandono") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 12567510.29 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 19212721.86 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 26343565.53 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 7736608.06 AS value) TMP
                  ORDER BY ORD";
    }
    else if ($tipo == "Trafico_Neto") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 12567510.29 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 19212721.86 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 26343565.53 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 7736608.06 AS value) TMP
                  ORDER BY ORD";
    }

    to_json(table_simple($query));
}

function get_trafico_panorama_mensual_tendencia($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1749516 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1096317 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1275512 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 2249461 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 2222914 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1512917 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 2460873 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2469657 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1684924 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1819085 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3263667 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3204757 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 2607043 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4163589 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2547203 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1972198 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 2103236 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3925579 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3727073 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4740255 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 7328022 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1151503 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 671737 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1104032 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1179573 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 840917 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1206563 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1582283 AS value) TMP
                   ORDER BY ORD";

    }
    else if ($tipo == "Tiempo_Promedio") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1749516 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1096317 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1275512 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 2249461 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 2222914 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1512917 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 2460873 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2469657 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1684924 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1819085 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3263667 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3204757 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 2607043 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4163589 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2547203 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1972198 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 2103236 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3925579 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3727073 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4740255 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 7328022 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1151503 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 671737 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1104032 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1179573 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 840917 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1206563 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1582283 AS value) TMP
                   ORDER BY ORD";

    }
    else if ($tipo == "Visitas") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1749516 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1096317 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1275512 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 2249461 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 2222914 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1512917 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 2460873 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2469657 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1684924 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1819085 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3263667 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3204757 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 2607043 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4163589 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2547203 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1972198 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 2103236 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3925579 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3727073 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4740255 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 7328022 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1151503 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 671737 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1104032 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1179573 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 840917 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1206563 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1582283 AS value) TMP
                   ORDER BY ORD";

    }
    else if ($tipo == "Abandono") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1749516 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1096317 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1275512 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 2249461 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 2222914 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1512917 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 2460873 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2469657 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1684924 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1819085 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3263667 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3204757 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 2607043 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4163589 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2547203 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1972198 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 2103236 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3925579 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3727073 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4740255 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 7328022 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1151503 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 671737 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1104032 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1179573 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 840917 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1206563 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1582283 AS value) TMP
                   ORDER BY ORD";

    }
    else if ($tipo == "Trafico_Neto") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1749516 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1096317 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1275512 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 2249461 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 2222914 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1512917 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 2460873 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2469657 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1684924 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1819085 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3263667 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3204757 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 2607043 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4163589 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2547203 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1972198 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 2103236 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3925579 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3727073 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4740255 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 7328022 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1151503 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 671737 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1104032 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1179573 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 840917 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1206563 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1582283 AS value) TMP
                   ORDER BY ORD";

    }

    to_json(array(
                array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
            ));
}



/*
function get_audiencia_interes_b100_tabla($user_id) {
	$query = "SELECT Variables, Competidor0 as Musimundo, Competidor1 as Fravega, Competidor2 as Garbarino, Competidor3 as Avenida
              FROM (SELECT 1 AS ORD, 'Trafico Total' AS Variables, '12,567,510' AS Competidor0, '19,212,722' AS Competidor1, '26,343,566' AS Competidor2, '7,736,608' AS Competidor3 UNION
                    SELECT 2 AS ORD, 'Arte y Entretenimiento' AS Variables, '37.5%' AS Competidor0, '25.1%' AS Competidor1, '25.5%' AS Competidor2, '12.0%' AS Competidor3 UNION
                    SELECT 3 AS ORD, 'Internet & Telcos' AS Variables, '27.7%' AS Competidor0, '33.7%' AS Competidor1, '23.9%' AS Competidor2, '14.7%' AS Competidor3 UNION
                    SELECT 4 AS ORD, 'Shoppings' AS Variables, '23.0%' AS Competidor0, '25.2%' AS Competidor1, '30.9%' AS Competidor2, '20.9%' AS Competidor3 UNION
                    SELECT 5 AS ORD, 'Noticias & Medios' AS Variables, '26.0%' AS Competidor0, '29.1%' AS Competidor1, '30.4%' AS Competidor2, '14.5%' AS Competidor3 UNION
                    SELECT 6 AS ORD, 'Negocios e industrias' AS Variables, '23.9%' AS Competidor0, '27.9%' AS Competidor1, '30.6%' AS Competidor2, '17.6%' AS Competidor3 UNION
                    SELECT 7 AS ORD, 'Computer & Electronic' AS Variables, '35.0%' AS Competidor0, '27.6%' AS Competidor1, '24.4%' AS Competidor2, '13.0%' AS Competidor3) TMP
              ORDER BY ORD";

    to_json(table_simple($query));
}

function get_audiencia_interes_b100_grafico($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Arte y Entretenimiento' AS label, '37.5' AS value UNION
                     SELECT 2 AS ORD, 'Internet & Telcos' AS label, '27.7' AS value UNION
                     SELECT 3 AS ORD, 'Shoppings' AS label, '23.0' AS value UNION
                     SELECT 4 AS ORD, 'Noticias & Medios' AS label, '26.0' AS value UNION
                     SELECT 5 AS ORD, 'Negocios e industrias' AS label, '23.9' AS value UNION
                     SELECT 6 AS ORD, 'Computer & Electronic' AS label, '35.0' AS value) TMP
               ORDER BY ORD";

	$query2 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Arte y Entretenimiento' AS label, '25.1' AS value UNION
                     SELECT 2 AS ORD, 'Internet & Telcos' AS label, '33.7' AS value UNION
                     SELECT 3 AS ORD, 'Shoppings' AS label, '25.2' AS value UNION
                     SELECT 4 AS ORD, 'Noticias & Medios' AS label, '29.1' AS value UNION
                     SELECT 5 AS ORD, 'Negocios e industrias' AS label, '27.9' AS value UNION
                     SELECT 6 AS ORD, 'Computer & Electronic' AS label, '27.6' AS value) TMP
               ORDER BY ORD";

	$query3 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Arte y Entretenimiento' AS label, '25.5' AS value UNION
                     SELECT 2 AS ORD, 'Internet & Telcos' AS label, '23.9' AS value UNION
                     SELECT 3 AS ORD, 'Shoppings' AS label, '30.9' AS value UNION
                     SELECT 4 AS ORD, 'Noticias & Medios' AS label, '30.4' AS value UNION
                     SELECT 5 AS ORD, 'Negocios e industrias' AS label, '30.6' AS value UNION
                     SELECT 6 AS ORD, 'Computer & Electronic' AS label, '24.4' AS value) TMP
               ORDER BY ORD";

	$query4 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Arte y Entretenimiento' AS label, '12.0' AS value UNION
                     SELECT 2 AS ORD, 'Internet & Telcos' AS label, '14.7' AS value UNION
                     SELECT 3 AS ORD, 'Shoppings' AS label, '20.9' AS value UNION
                     SELECT 4 AS ORD, 'Noticias & Medios' AS label, '14.5' AS value UNION
                     SELECT 5 AS ORD, 'Negocios e industrias' AS label, '17.6' AS value UNION
                     SELECT 6 AS ORD, 'Computer & Electronic' AS label, '13.0' AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
            ));
}


function get_audiencia_interes_tabla($user_id) {
	$query = "SELECT Variables, Competidor0, Competidor1, Competidor2, Competidor3
              FROM (SELECT 1 AS ORD, 'Trafico Total' AS Variables, '12,567,510' AS Competidor0, '19,212,722' AS Competidor1, '26,343,566' AS Competidor2, '7,736,608' AS Competidor3 UNION
                    SELECT 2 AS ORD, 'Arte y Entretenimiento' AS Variables, '24.0%' AS Competidor0, '16.3%' AS Competidor1, '16.1%' AS Competidor2, '13.4%' AS Competidor3 UNION
                    SELECT 3 AS ORD, 'Internet & Telcos' AS Variables, '12.6%' AS Competidor0, '15.5%' AS Competidor1, '10.7%' AS Competidor2, '11.6%' AS Competidor3 UNION
                    SELECT 4 AS ORD, 'Shoppings' AS Variables, '21.0%' AS Competidor0, '23.3%' AS Competidor1, '27.8%' AS Competidor2, '33.2%' AS Competidor3 UNION
                    SELECT 5 AS ORD, 'Noticias & Medios' AS Variables, '18.6%' AS Competidor0, '21.0%' AS Competidor1, '21.5%' AS Competidor2, '18.1%' AS Competidor3 UNION
                    SELECT 6 AS ORD, 'Negocios e industrias' AS Variables, '13.1%' AS Competidor0, '15.5%' AS Competidor1, '16.6%' AS Competidor2, '16.8%' AS Competidor3 UNION
                    SELECT 7 AS ORD, 'Computer & Electronic' AS Variables, '10.6%' AS Competidor0, '8.5%' AS Competidor1, '7.3%' AS Competidor2, '6.9%' AS Competidor3) TMP
              ORDER BY ORD";

    to_json(table_simple($query));
}

function get_audiencia_interes_grafico($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Arte y Entretenimiento' AS label, '24.0' AS value UNION
                     SELECT 2 AS ORD, 'Internet & Telcos' AS label, '12.6' AS value UNION
                     SELECT 3 AS ORD, 'Shoppings' AS label, '21.0' AS value UNION
                     SELECT 4 AS ORD, 'Noticias & Medios' AS label, '18.6' AS value UNION
                     SELECT 5 AS ORD, 'Negocios e industrias' AS label, '13.1' AS value UNION
                     SELECT 6 AS ORD, 'Computer & Electronic' AS label, '10.6' AS value) TMP
               ORDER BY ORD";

	$query2 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Arte y Entretenimiento' AS label, '16.3' AS value UNION
                     SELECT 2 AS ORD, 'Internet & Telcos' AS label, '15.5' AS value UNION
                     SELECT 3 AS ORD, 'Shoppings' AS label, '23.3' AS value UNION
                     SELECT 4 AS ORD, 'Noticias & Medios' AS label, '21.0' AS value UNION
                     SELECT 5 AS ORD, 'Negocios e industrias' AS label, '15.5' AS value UNION
                     SELECT 6 AS ORD, 'Computer & Electronic' AS label, '8.5' AS value) TMP
               ORDER BY ORD";
               
	$query3 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Arte y Entretenimiento' AS label, '16.1' AS value UNION
                     SELECT 2 AS ORD, 'Internet & Telcos' AS label, '10.7' AS value UNION
                     SELECT 3 AS ORD, 'Shoppings' AS label, '27.8' AS value UNION
                     SELECT 4 AS ORD, 'Noticias & Medios' AS label, '21.5' AS value UNION
                     SELECT 5 AS ORD, 'Negocios e industrias' AS label, '16.6' AS value UNION
                     SELECT 6 AS ORD, 'Computer & Electronic' AS label, '7.3' AS value) TMP
               ORDER BY ORD";

	$query4 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Arte y Entretenimiento' AS label, '13.4' AS value UNION
                     SELECT 2 AS ORD, 'Internet & Telcos' AS label, '11.6' AS value UNION
                     SELECT 3 AS ORD, 'Shoppings' AS label, '33.2' AS value UNION
                     SELECT 4 AS ORD, 'Noticias & Medios' AS label, '18.1' AS value UNION
                     SELECT 5 AS ORD, 'Negocios e industrias' AS label, '16.8' AS value UNION
                     SELECT 6 AS ORD, 'Computer & Electronic' AS label, '6.9' AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
            ));
}


function get_audiencia_industria_sites($user_id, $industria) {
    if ($industria == "Arte_Entretenimiento") {
        $query = "SELECT Pos, Sitio
                  FROM (SELECT 'yahoo.com' AS Sitio, 1 AS Pos UNION
                        SELECT 'msn.com' AS Sitio, 2 AS Pos UNION
                        SELECT 'clarin.com' AS Sitio, 3 AS Pos UNION
                        SELECT 'lanacion.com.ar' AS Sitio, 4 AS Pos UNION
                        SELECT 'infobae.com' AS Sitio, 5 AS Pos UNION
                        SELECT 'ole.com.ar' AS Sitio, 6 AS Pos UNION
                        SELECT 'tn.com.ar' AS Sitio, 7 AS Pos UNION
                        SELECT 'minutouno.com' AS Sitio, 8 AS Pos UNION
                        SELECT 'perfil.com' AS Sitio, 9 AS Pos UNION
                        SELECT 'lavoz.com.ar' AS Sitio, 10 AS Pos UNION
                        SELECT 'diarioregistrado.com' AS Sitio, 11 AS Pos UNION
                        SELECT 'diariouno.com.ar' AS Sitio, 12 AS Pos UNION
                        SELECT 'lacapital.com.ar' AS Sitio, 13 AS Pos UNION
                        SELECT 'losandes.com.ar' AS Sitio, 14 AS Pos UNION
                        SELECT 'ambito.com' AS Sitio, 15 AS Pos UNION
                        SELECT 'pagina12.com.ar' AS Sitio, 16 AS Pos UNION
                        SELECT 'mdzol.com' AS Sitio, 17 AS Pos UNION
                        SELECT 'lagaceta.com.ar' AS Sitio, 18 AS Pos UNION
                        SELECT 'infonews.com' AS Sitio, 19 AS Pos UNION
                        SELECT 'elintransigente.com' AS Sitio, 20 AS Pos UNION
                        SELECT 'bp.blogspot.com' AS Sitio, 21 AS Pos UNION
                        SELECT 'cronista.com' AS Sitio, 22 AS Pos UNION
                        SELECT 'rionegro.com.ar' AS Sitio, 23 AS Pos UNION
                        SELECT 'eldia.com' AS Sitio, 24 AS Pos UNION
                        SELECT 'diariodecuyo.com.ar' AS Sitio, 25 AS Pos UNION
                        SELECT 'bamzum.com' AS Sitio, 26 AS Pos UNION
                        SELECT 'telam.com.ar' AS Sitio, 27 AS Pos UNION
                        SELECT 'eltribuno.info' AS Sitio, 28 AS Pos UNION
                        SELECT 'cnet.com' AS Sitio, 29 AS Pos UNION
                        SELECT 'elpais.com' AS Sitio, 30 AS Pos) TMP
                  ORDER BY Pos";
    }
    else if ($industria == "Internet_Telcos") {
        $query = "SELECT Pos, Sitio
                  FROM (SELECT 'facebook.com' AS Sitio, 1 AS Pos UNION
                        SELECT 'google.com.ar' AS Sitio, 2 AS Pos UNION
                        SELECT 'google.com' AS Sitio, 3 AS Pos UNION
                        SELECT 'live.com' AS Sitio, 4 AS Pos UNION
                        SELECT 'twitter.com' AS Sitio, 5 AS Pos UNION
                        SELECT 'instagram.com' AS Sitio, 6 AS Pos UNION
                        SELECT 'youradexchange.com' AS Sitio, 7 AS Pos UNION
                        SELECT 'ask.com' AS Sitio, 8 AS Pos UNION
                        SELECT 'iminent.com' AS Sitio, 9 AS Pos UNION
                        SELECT 'taringa.net' AS Sitio, 10 AS Pos UNION
                        SELECT 'adcash.com' AS Sitio, 11 AS Pos UNION
                        SELECT 'onclickads.net' AS Sitio, 12 AS Pos UNION
                        SELECT 'google.es' AS Sitio, 13 AS Pos UNION
                        SELECT 'bing.com' AS Sitio, 14 AS Pos UNION
                        SELECT 'pinterest.com' AS Sitio, 15 AS Pos UNION
                        SELECT 'delta-homes.com' AS Sitio, 16 AS Pos UNION
                        SELECT 'wordpress.com' AS Sitio, 17 AS Pos UNION
                        SELECT 'adf.ly' AS Sitio, 18 AS Pos UNION
                        SELECT 't.co' AS Sitio, 19 AS Pos UNION
                        SELECT 'ampclicks.com' AS Sitio, 20 AS Pos UNION
                        SELECT 'claro.com.ar' AS Sitio, 21 AS Pos UNION
                        SELECT 'ad4game.com' AS Sitio, 22 AS Pos UNION
                        SELECT 'tumblr.com' AS Sitio, 23 AS Pos UNION
                        SELECT 'personal.com.ar' AS Sitio, 24 AS Pos UNION
                        SELECT 'linkedin.com' AS Sitio, 25 AS Pos UNION
                        SELECT 'gmail.com' AS Sitio, 26 AS Pos UNION
                        SELECT 'adplxmd.com' AS Sitio, 27 AS Pos UNION
                        SELECT 'webssearches.com' AS Sitio, 28 AS Pos UNION
                        SELECT 'v9.com' AS Sitio, 29 AS Pos UNION
                        SELECT 'mediafire.com' AS Sitio, 30 AS Pos) TMP
                  ORDER BY Pos";
    }
    else if ($industria == "Shoppings") {
        $query = "SELECT Pos, Sitio
                  FROM (SELECT 'mercadolibre.com.ar' AS Sitio, 1 AS Pos UNION
                        SELECT 'alamaula.com' AS Sitio, 2 AS Pos UNION
                        SELECT 'linio.com.ar' AS Sitio, 3 AS Pos UNION
                        SELECT 'aliexpress.com' AS Sitio, 4 AS Pos UNION
                        SELECT 'olx.com.ar' AS Sitio, 5 AS Pos UNION
                        SELECT 'auto.mercadolibre.com.ar' AS Sitio, 6 AS Pos UNION
                        SELECT 'alibaba.com' AS Sitio, 7 AS Pos UNION
                        SELECT 'amazon.com' AS Sitio, 8 AS Pos UNION
                        SELECT 'mercadolibre.com' AS Sitio, 9 AS Pos UNION
                        SELECT 'netshoes.com.ar' AS Sitio, 10 AS Pos UNION
                        SELECT 'ebay.com' AS Sitio, 11 AS Pos UNION
                        SELECT 'garbarino.com' AS Sitio, 12 AS Pos UNION
                        SELECT 'fravega.com' AS Sitio, 13 AS Pos UNION
                        SELECT 'groupon.com.ar' AS Sitio, 14 AS Pos UNION
                        SELECT 'dafiti.com.ar' AS Sitio, 15 AS Pos UNION
                        SELECT 'musimundo.com' AS Sitio, 16 AS Pos UNION
                        SELECT 'falabella.com.ar' AS Sitio, 17 AS Pos UNION
                        SELECT 'easy.com.ar' AS Sitio, 18 AS Pos UNION
                        SELECT 'imgga.com' AS Sitio, 19 AS Pos UNION
                        SELECT 'moto.mercadolibre.com.ar' AS Sitio, 20 AS Pos UNION
                        SELECT 'vivavisos.com.ar' AS Sitio, 21 AS Pos UNION
                        SELECT 'smartshopping.com' AS Sitio, 22 AS Pos UNION
                        SELECT 'solarinstructions.com' AS Sitio, 23 AS Pos UNION
                        SELECT 'carrefour.com.ar' AS Sitio, 24 AS Pos UNION
                        SELECT 'cordobavende.com' AS Sitio, 25 AS Pos UNION
                        SELECT 'trovitargentina.com.ar' AS Sitio, 26 AS Pos UNION
                        SELECT 'futbolparatodos.com.ar' AS Sitio, 27 AS Pos UNION
                        SELECT 'clasificadoslavoz.com.ar' AS Sitio, 28 AS Pos UNION
                        SELECT 'tiendamovistar.com.ar' AS Sitio, 29 AS Pos UNION
                        SELECT 'navegaki.com' AS Sitio, 30 AS Pos) TMP
                  ORDER BY Pos";
    }
    else if ($industria == "Noticias_Medios") {
        $query = "SELECT Pos, Sitio
                  FROM (SELECT 'yahoo.com' AS Sitio, 1 AS Pos UNION
                        SELECT 'msn.com' AS Sitio, 2 AS Pos UNION
                        SELECT 'clarin.com' AS Sitio, 3 AS Pos UNION
                        SELECT 'lanacion.com.ar' AS Sitio, 4 AS Pos UNION
                        SELECT 'infobae.com' AS Sitio, 5 AS Pos UNION
                        SELECT 'ole.com.ar' AS Sitio, 6 AS Pos UNION
                        SELECT 'tn.com.ar' AS Sitio, 7 AS Pos UNION
                        SELECT 'minutouno.com' AS Sitio, 8 AS Pos UNION
                        SELECT 'perfil.com' AS Sitio, 9 AS Pos UNION
                        SELECT 'lavoz.com.ar' AS Sitio, 10 AS Pos UNION
                        SELECT 'diarioregistrado.com' AS Sitio, 11 AS Pos UNION
                        SELECT 'diariouno.com.ar' AS Sitio, 12 AS Pos UNION
                        SELECT 'lacapital.com.ar' AS Sitio, 13 AS Pos UNION
                        SELECT 'losandes.com.ar' AS Sitio, 14 AS Pos UNION
                        SELECT 'ambito.com' AS Sitio, 15 AS Pos UNION
                        SELECT 'pagina12.com.ar' AS Sitio, 16 AS Pos UNION
                        SELECT 'mdzol.com' AS Sitio, 17 AS Pos UNION
                        SELECT 'lagaceta.com.ar' AS Sitio, 18 AS Pos UNION
                        SELECT 'infonews.com' AS Sitio, 19 AS Pos UNION
                        SELECT 'elintransigente.com' AS Sitio, 20 AS Pos UNION
                        SELECT 'bp.blogspot.com' AS Sitio, 21 AS Pos UNION
                        SELECT 'cronista.com' AS Sitio, 22 AS Pos UNION
                        SELECT 'rionegro.com.ar' AS Sitio, 23 AS Pos UNION
                        SELECT 'eldia.com' AS Sitio, 24 AS Pos UNION
                        SELECT 'diariodecuyo.com.ar' AS Sitio, 25 AS Pos UNION
                        SELECT 'bamzum.com' AS Sitio, 26 AS Pos UNION
                        SELECT 'telam.com.ar' AS Sitio, 27 AS Pos UNION
                        SELECT 'eltribuno.info' AS Sitio, 28 AS Pos UNION
                        SELECT 'cnet.com' AS Sitio, 29 AS Pos UNION
                        SELECT 'elpais.com' AS Sitio, 30 AS Pos) TMP
                  ORDER BY Pos";
    }

    to_json(table_simple($query));
}


function get_audiencia_industria_competidor_tabla($user_id, $industria, $competidor) {
    if ($industria == "Arte_Entretenimiento") {
        if ($competidor == 1) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '24.0%' AS ShareAudiencia, '37.5%' AS Shareb100) TMP";
        }
        else if ($competidor == 2) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '16.3%' AS ShareAudiencia, '25.1%' AS Shareb100) TMP";
        }
        else if ($competidor == 3) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '16.1%' AS ShareAudiencia, '25.5%' AS Shareb100) TMP";
        }
        else if ($competidor == 4) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '13.4%' AS ShareAudiencia, '12.0%' AS Shareb100) TMP";
        }
    }
    else if ($industria == "Internet_Telcos") {
        if ($competidor == 1) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '12.6%' AS ShareAudiencia, '27.7%' AS Shareb100) TMP";
        }
        else if ($competidor == 2) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '15.5%' AS ShareAudiencia, '33.7%' AS Shareb100) TMP";
        }
        else if ($competidor == 3) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '10.7%' AS ShareAudiencia, '23.9%' AS Shareb100) TMP";
        }
        else if ($competidor == 4) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '11.6%' AS ShareAudiencia, '14.7%' AS Shareb100) TMP";
        }
    }
    else if ($industria == "Shoppings") {
        if ($competidor == 1) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '21.0%' AS ShareAudiencia, '23.0%' AS Shareb100) TMP";
        }
        else if ($competidor == 2) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '23.3%' AS ShareAudiencia, '25.2%' AS Shareb100) TMP";
        }
        else if ($competidor == 3) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '27.8%' AS ShareAudiencia, '30.9%' AS Shareb100) TMP";
        }
        else if ($competidor == 4) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '33.2%' AS ShareAudiencia, '20.9%' AS Shareb100) TMP";
        }
    }
    else if ($industria == "Noticias_Medios") {
        if ($competidor == 1) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '18.6%' AS ShareAudiencia, '26.0%' AS Shareb100) TMP";
        }
        else if ($competidor == 2) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '21.0%' AS ShareAudiencia, '29.1%' AS Shareb100) TMP";
        }
        else if ($competidor == 3) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '21.5%' AS ShareAudiencia, '30.4%' AS Shareb100) TMP";
        }
        else if ($competidor == 4) {
            $query = "SELECT Empresa, ShareAudiencia, Shareb100
                      FROM (SELECT '".competidor_label($user_id, $competidor)."' AS Empresa, '18.1%' AS ShareAudiencia, '14.5%' AS Shareb100) TMP";
        }
    }

    to_json(table_simple($query));
}


function get_audiencia_sitios_ranking_tabla($user_id) {
	$query = "SELECT Pos, Competidor0 as Musimundo, Competidor1 as Fravega, Competidor2 as Garbarino, Competidor3 as Avenida
              FROM (SELECT 1 AS Pos, 'fravega.com' AS Competidor0, 'musimundo.com' AS Competidor1, 'fravega.com' AS Competidor2, 'avalancha.com.ar' AS Competidor3 UNION
                    SELECT 2 AS Pos, 'garbarino.com' AS Competidor0, 'garbarino.com' AS Competidor1, 'musimundo.com' AS Competidor2, 'musimundo.com' AS Competidor3 UNION
                    SELECT 3 AS Pos, 'compumundo.com.ar' AS Competidor0, 'tiendeo.com.ar' AS Competidor1, 'compumundo.com.ar' AS Competidor2, 'ar.ask.com' AS Competidor3 UNION
                    SELECT 4 AS Pos, 'marcaderadio.com' AS Competidor0, 'compumundo.com.ar' AS Competidor1, 'ribeiro.com.ar' AS Competidor2, 'electropuntonet.com' AS Competidor3 UNION
                    SELECT 5 AS Pos, 'tiendeo.com.ar' AS Competidor0, 'falabella.com.ar' AS Competidor1, 'rodo.com.ar' AS Competidor2, 'groupon.com.ar' AS Competidor3 UNION
                    SELECT 6 AS Pos, 'cetrogar.com.ar' AS Competidor0, 'ribeiro.com.ar' AS Competidor1, 'falabella.com.ar' AS Competidor2, 'monetizadesdecasa.xyz' AS Competidor3 UNION
                    SELECT 7 AS Pos, 'megatone.net' AS Competidor0, 'appnew.embluejet.com' AS Competidor1, 'ads01.groovinads.com' AS Competidor2, 'garbarino.com' AS Competidor3 UNION
                    SELECT 8 AS Pos, 'falabella.com.ar' AS Competidor0, 'rodo.com.ar' AS Competidor1, 'tiomusa.com.ar' AS Competidor2, 'muebleriamam.com.ar' AS Competidor3 UNION
                    SELECT 9 AS Pos, 'ribeiro.com.ar' AS Competidor0, 'naldo.com.ar' AS Competidor1, 'siam.com.ar' AS Competidor2, 'hoyts.com.ar' AS Competidor3 UNION
                    SELECT 10 AS Pos, 'easy.com.ar' AS Competidor0, 'cetrogar.com.ar' AS Competidor1, 'tiendeo.com.ar' AS Competidor2, 'ar.zapmeta.com' AS Competidor3 UNION
                    SELECT 11 AS Pos, 'sf.grupocarsa.com' AS Competidor0, 'ads01.groovinads.com' AS Competidor1, 'carrefour.com.ar' AS Competidor2, 'infoplanett.com' AS Competidor3 UNION
                    SELECT 12 AS Pos, 'tusjuegosonline.info' AS Competidor0, 'store.sony.com.ar' AS Competidor1, 'lt.mydplr.com' AS Competidor2, 'tiendeo.com.ar' AS Competidor3 UNION
                    SELECT 13 AS Pos, 'wal-mart.com.ar' AS Competidor0, 'ofertas.mercadolibre.com.ar' AS Competidor1, 'naldo.com.ar' AS Competidor2, 'proyectocartele.com' AS Competidor3 UNION
                    SELECT 14 AS Pos, 'conlasdeforex.co' AS Competidor0, 'tienda.personal.com.ar' AS Competidor1, 'gosquared.com' AS Competidor2, 'ventas-privadas.com' AS Competidor3 UNION
                    SELECT 15 AS Pos, 'casadelaudio.com' AS Competidor0, 'televisores.mercadolibre.com.ar' AS Competidor1, 'cetrogar.com.ar' AS Competidor2, 'buenosaireshockey.org.ar' AS Competidor3 UNION
                    SELECT 16 AS Pos, 'crackle.com' AS Competidor0, 'fravegacatalogo.com' AS Competidor1, 'castilloweb.com.ar' AS Competidor2, 'gurudeofertas.com' AS Competidor3 UNION
                    SELECT 17 AS Pos, 'electronica.mercadolibre.com.ar' AS Competidor0, 'casadelaudio.com' AS Competidor1, 'hb.hipotecario.com.ar' AS Competidor2, 'rtbhousesalatam.pipedrive.com' AS Competidor3 UNION
                    SELECT 18 AS Pos, 'docs.opendns.com' AS Competidor0, 'garbarinocatalogo.com' AS Competidor1, 'appsec.claro.com.ar' AS Competidor2, 'oldpicsarchive.com' AS Competidor3 UNION
                    SELECT 19 AS Pos, 'carrefour.com.ar' AS Competidor0, 'whirlpool.com.ar' AS Competidor1, 'lucaioli.com.ar' AS Competidor2, 'buildingco.slack.com' AS Competidor3 UNION
                    SELECT 20 AS Pos, 'webmasterworkers.com' AS Competidor0, 'infantiladas.info' AS Competidor1, 'store.sony.com.ar' AS Competidor2, 'rosarioalcosto.com' AS Competidor3 UNION
                    SELECT 21 AS Pos, 'ar.ask.com' AS Competidor0, 'red.videoschistososs.com' AS Competidor1, 'apps.tekgenesis.com' AS Competidor2, 'todobd25.com' AS Competidor3 UNION
                    SELECT 22 AS Pos, 'compu-santafe.com.ar' AS Competidor0, 'ar-mg5.mail.yahoo.com' AS Competidor1, 'electropuntonet.com' AS Competidor2, 'mardelplata.olx.com.ar' AS Competidor3 UNION
                    SELECT 23 AS Pos, 'sanyo.com..ar' AS Competidor0, 'ecomer-divisa.info' AS Competidor1, 'mega-descarga.com' AS Competidor2, 'capitalfederal-gba.olx.com.ar' AS Competidor3 UNION
                    SELECT 24 AS Pos, 'tienda.personal.com.ar' AS Competidor0, 'sear4m.xyz' AS Competidor1, 'electronica.mercadolibre.com.ar' AS Competidor2, 'falabella.com.ar' AS Competidor3 UNION
                    SELECT 25 AS Pos, 'pequenaempresas.info' AS Competidor0, 'segundoenfoque.com' AS Competidor1, 'gamaitaly.com' AS Competidor2, 'ar-mg5.mail.yahoo.com' AS Competidor3 UNION
                    SELECT 26 AS Pos, 'bazarelentrerriano.com.ar' AS Competidor0, 'forexmbanotici.com' AS Competidor1, 'ar.ask.com' AS Competidor2, 'acool.com' AS Competidor3 UNION
                    SELECT 27 AS Pos, 'gsmversus.com' AS Competidor0, 'telefonia.mercadolibre.com.ar' AS Competidor1, 'alamaula.com' AS Competidor2, 'aveda.com' AS Competidor3 UNION
                    SELECT 28 AS Pos, 'coppel.com.ar' AS Competidor0, 'tododvdfull.com' AS Competidor1, 'walmartonline.com.ar' AS Competidor2, 'fravega.com' AS Competidor3 UNION
                    SELECT 29 AS Pos, 'novogar.com.ar' AS Competidor0, 'jumbo.com.ar' AS Competidor1, 'ar.zapmeta.com' AS Competidor2, 'consejo.org.ar' AS Competidor3 UNION
                    SELECT 30 AS Pos, 'rosariofinanzas.com.ar' AS Competidor0, 'personal.com.ar' AS Competidor1, 'consejo.org.ar' AS Competidor2, 'webmail.ciudad.com.ar' AS Competidor3) TMP
              ORDER BY Pos";

    to_json(table_simple($query));
}


function get_audiencia_industrias_line_grafico($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 1 AS ORD, '2015-05-01' AS label, '20.0' AS value UNION
                     SELECT 2 AS ORD, '2015-07-01' AS label, '22.2' AS value UNION
                     SELECT 3 AS ORD, '2015-09-01' AS label, '21.7' AS value UNION
                     SELECT 4 AS ORD, '2015-11-01' AS label, '19.7' AS value UNION
                     SELECT 5 AS ORD, '2016-01-01' AS label, '17.4' AS value) TMP
               ORDER BY ORD";
               
	$query2 = "SELECT label, value
               FROM (SELECT 1 AS ORD, '2015-05-01' AS label, '12.3' AS value UNION
                     SELECT 2 AS ORD, '2015-07-01' AS label, '14.4' AS value UNION
                     SELECT 3 AS ORD, '2015-09-01' AS label, '13.6' AS value UNION
                     SELECT 4 AS ORD, '2015-11-01' AS label, '12.3' AS value UNION
                     SELECT 5 AS ORD, '2016-01-01' AS label, '12.6' AS value) TMP
               ORDER BY ORD";
               
	$query3 = "SELECT label, value
               FROM (SELECT 1 AS ORD, '2015-05-01' AS label, '18.0' AS value UNION
                     SELECT 2 AS ORD, '2015-07-01' AS label, '23.1' AS value UNION
                     SELECT 3 AS ORD, '2015-09-01' AS label, '22.9' AS value UNION
                     SELECT 4 AS ORD, '2015-11-01' AS label, '25.6' AS value UNION
                     SELECT 5 AS ORD, '2016-01-01' AS label, '26.3' AS value) TMP
               ORDER BY ORD";
               
	$query4 = "SELECT label, value
               FROM (SELECT 1 AS ORD, '2015-05-01' AS label, '16.0' AS value UNION
                     SELECT 2 AS ORD, '2015-07-01' AS label, '19.2' AS value UNION
                     SELECT 3 AS ORD, '2015-09-01' AS label, '19.3' AS value UNION
                     SELECT 4 AS ORD, '2015-11-01' AS label, '19.3' AS value UNION
                     SELECT 5 AS ORD, '2016-01-01' AS label, '19.8' AS value) TMP
               ORDER BY ORD";
               
	$query5 = "SELECT label, value
               FROM (SELECT 1 AS ORD, '2015-05-01' AS label, '14.3' AS value UNION
                     SELECT 2 AS ORD, '2015-07-01' AS label, '13.6' AS value UNION
                     SELECT 3 AS ORD, '2015-09-01' AS label, '14.4' AS value UNION
                     SELECT 4 AS ORD, '2015-11-01' AS label, '15.1' AS value UNION
                     SELECT 5 AS ORD, '2016-01-01' AS label, '15.5' AS value) TMP
               ORDER BY ORD";
               
	$query6 = "SELECT label, value
               FROM (SELECT 1 AS ORD, '2015-05-01' AS label, '9.0' AS value UNION
                     SELECT 2 AS ORD, '2015-07-01' AS label, '7.8' AS value UNION
                     SELECT 3 AS ORD, '2015-09-01' AS label, '8.5' AS value UNION
                     SELECT 4 AS ORD, '2015-11-01' AS label, '8.2' AS value UNION
                     SELECT 5 AS ORD, '2016-01-01' AS label, '8.3' AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array('key'=>industria($user_id, 0), 'values'=>table_simple($query1)),
                array('key'=>industria($user_id, 1), 'values'=>table_simple($query2)),
                array('key'=>industria($user_id, 2), 'values'=>table_simple($query3)),
                array('key'=>industria($user_id, 3), 'values'=>table_simple($query4)),
                array('key'=>industria($user_id, 4), 'values'=>table_simple($query5)),
                array('key'=>industria($user_id, 5), 'values'=>table_simple($query6))
            ));
}


function get_audiencia_industrias_radar_grafico($user_id) {

	$query0 = "SELECT label
               FROM (SELECT 0 AS ORD, 'Arte y Entretenimiento' AS label UNION
                     SELECT 1 AS ORD, 'Internet & Telcos' AS label UNION
                     SELECT 2 AS ORD, 'Shoppings' AS label UNION
                     SELECT 3 AS ORD, 'Noticias & Medios' AS label UNION
                     SELECT 4 AS ORD, 'Negocios e industrias' AS label UNION
                     SELECT 5 AS ORD, 'Computer & Electronic' AS label) TMP
               ORDER BY ORD";
               
	$query1 = "SELECT value
               FROM (SELECT 0 AS ORD, 'Arte y Entretenimiento' AS label, 24.01 AS value UNION
                     SELECT 1 AS ORD, 'Internet & Telcos' AS label, 12.62 AS value UNION
                     SELECT 2 AS ORD, 'Shoppings' AS label, 21.04 AS value UNION
                     SELECT 3 AS ORD, 'Noticias & Medios' AS label, 18.56 AS value UNION
                     SELECT 4 AS ORD, 'Negocios e industrias' AS label, 13.12 AS value UNION
                     SELECT 5 AS ORD, 'Computer & Electronic' AS label, 10.64 AS value) TMP
               ORDER BY ORD";
    
	$query2 = "SELECT value
               FROM (SELECT 0 AS ORD, 'Arte y Entretenimiento' AS label, 16.25 AS value UNION
                     SELECT 1 AS ORD, 'Internet & Telcos' AS label, 15.50 AS value UNION
                     SELECT 2 AS ORD, 'Shoppings' AS label, 23.25 AS value UNION
                     SELECT 3 AS ORD, 'Noticias & Medios' AS label, 21.00 AS value UNION
                     SELECT 4 AS ORD, 'Negocios e industrias' AS label, 15.50 AS value UNION
                     SELECT 5 AS ORD, 'Computer & Electronic' AS label, 8.50 AS value) TMP
               ORDER BY ORD";
    
	$query3 = "SELECT value
               FROM (SELECT 0 AS ORD, 'Arte y Entretenimiento' AS label, 16.10 AS value UNION
                     SELECT 1 AS ORD, 'Internet & Telcos' AS label, 10.73 AS value UNION
                     SELECT 2 AS ORD, 'Shoppings' AS label, 27.80 AS value UNION
                     SELECT 3 AS ORD, 'Noticias & Medios' AS label, 21.46 AS value UNION
                     SELECT 4 AS ORD, 'Negocios e industrias' AS label, 16.59 AS value UNION
                     SELECT 5 AS ORD, 'Computer & Electronic' AS label, 7.32 AS value) TMP
               ORDER BY ORD";
    
	$query4 = "SELECT value
               FROM (SELECT 0 AS ORD, 'Arte y Entretenimiento' AS label, 13.36 AS value UNION
                     SELECT 1 AS ORD, 'Internet & Telcos' AS label, 11.64 AS value UNION
                     SELECT 2 AS ORD, 'Shoppings' AS label, 33.19 AS value UNION
                     SELECT 3 AS ORD, 'Noticias & Medios' AS label, 18.10 AS value UNION
                     SELECT 4 AS ORD, 'Negocios e industrias' AS label, 16.81 AS value UNION
                     SELECT 5 AS ORD, 'Computer & Electronic' AS label, 6.90 AS value) TMP
               ORDER BY ORD";
  
    to_json(array("labels" => array_simple($query0, ["label"]),
                  "datasets" => array(array("label" => competidores($user_id, 1, ["label"]),
                                            "backgroundColor" => competidores($user_id, 1, ["backgroundColor"]),
                                            "borderColor" => competidores($user_id, 1, ["borderColor"]),
                                            "pointBackgroundColor" => competidores($user_id, 1, ["pointBackgroundColor"]),
                                            "pointBorderColor" => competidores($user_id, 1, ["pointBorderColor"]),
                                            "pointHoverBackgroundColor" => competidores($user_id, 1, ["pointHoverBackgroundColor"]),
                                            "pointHoverBorderColor" => competidores($user_id, 1, ["pointHoverBorderColor"]),
                                            "data" => array_simple($query1, ["value"])),
                                     array("label" => competidores($user_id, 2, ["label"]),
                                            "backgroundColor" => competidores($user_id, 2, ["backgroundColor"]),
                                            "borderColor" => competidores($user_id, 2, ["borderColor"]),
                                            "pointBackgroundColor" => competidores($user_id, 2, ["pointBackgroundColor"]),
                                            "pointBorderColor" => competidores($user_id, 2, ["pointBorderColor"]),
                                            "pointHoverBackgroundColor" => competidores($user_id, 2, ["pointHoverBackgroundColor"]),
                                            "pointHoverBorderColor" => competidores($user_id, 2, ["pointHoverBorderColor"]),
                                            "data" => array_simple($query2, ["value"])),
                                     array("label" => competidores($user_id, 3, ["label"]),
                                            "backgroundColor" => competidores($user_id, 3, ["backgroundColor"]),
                                            "borderColor" => competidores($user_id, 3, ["borderColor"]),
                                            "pointBackgroundColor" => competidores($user_id, 3, ["pointBackgroundColor"]),
                                            "pointBorderColor" => competidores($user_id, 3, ["pointBorderColor"]),
                                            "pointHoverBackgroundColor" => competidores($user_id, 3, ["pointHoverBackgroundColor"]),
                                            "pointHoverBorderColor" => competidores($user_id, 3, ["pointHoverBorderColor"]),
                                            "data" => array_simple($query3, ["value"])),
                                     array("label" => competidores($user_id, 4, ["label"]),
                                            "backgroundColor" => competidores($user_id, 4, ["backgroundColor"]),
                                            "borderColor" => competidores($user_id, 4, ["borderColor"]),
                                            "pointBackgroundColor" => competidores($user_id, 4, ["pointBackgroundColor"]),
                                            "pointBorderColor" => competidores($user_id, 4, ["pointBorderColor"]),
                                            "pointHoverBackgroundColor" => competidores($user_id, 4, ["pointHoverBackgroundColor"]),
                                            "pointHoverBorderColor" => competidores($user_id, 4, ["pointHoverBorderColor"]),
                                            "data" => array_simple($query4, ["value"]))
                                     )
                 ));
}
*/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$user_id = intval($_GET['user']); //no default
$competidor = isset($_GET['competidor']) ? intval($_GET['competidor']) : -1;
$tipo = isset($_GET['tipo']) ? intval($_GET['tipo']) : "";

if ($_GET['action'] == "posts") get_posts($user_id);
else if ($_GET['action'] == "test") test();
else if ($_GET['action'] == "trafico_panorama_mensual_tabla") get_trafico_panorama_mensual_tabla($user_id, $tipo);
else if ($_GET['action'] == "trafico_panorama_mensual_indicador") get_trafico_panorama_mensual_indicador($user_id, $tipo);
else if ($_GET['action'] == "trafico_panorama_mensual_acumulado") get_trafico_panorama_mensual_acumulado($user_id, $tipo);
else if ($_GET['action'] == "trafico_panorama_mensual_tendencia") get_trafico_panorama_mensual_tendencia($user_id, $tipo);
/*
else if ($_GET['action'] == "audiencia_interes_b100_tabla") get_audiencia_interes_b100_tabla($user_id);
else if ($_GET['action'] == "audiencia_interes_b100_grafico") get_audiencia_interes_b100_grafico($user_id);
else if ($_GET['action'] == "audiencia_interes_tabla") get_audiencia_interes_tabla($user_id);
else if ($_GET['action'] == "audiencia_interes_grafico") get_audiencia_interes_grafico($user_id);
else if ($_GET['action'] == "audiencia_industria_sites") get_audiencia_industria_sites($user_id, $industria);
else if ($_GET['action'] == "audiencia_industria_competidor_tabla") get_audiencia_industria_competidor_tabla($user_id, $industria, $competidor);
else if ($_GET['action'] == "audiencia_sitios_ranking_tabla") get_audiencia_sitios_ranking_tabla($user_id);
else if ($_GET['action'] == "audiencia_industrias_line_grafico") get_audiencia_industrias_line_grafico($user_id);
else if ($_GET['action'] == "audiencia_industrias_radar_grafico") get_audiencia_industrias_radar_grafico($user_id);
*/
?>

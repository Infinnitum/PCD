<?php

include_once("lib.php");

// Ejemplo
function get_posts($user_id) {
	$query = "SELECT post_title, guid FROM (SELECT 'pepe1' as post_title, 1 as guid union SELECT 'pepe2' as post_title, 2 as guid union SELECT 'pepe3' as post_title, 3 as guid) tmp ORDER BY guid DESC";

    $result = dataset($query);

	$posts = array();
	if(mysql_num_rows($result)) {
		while($post = mysql_fetch_assoc($result)) {
			$posts[] = array('post'=>$post);
		}
	}

    to_json(array('posts'=>$posts));
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function competidores($user_id, $pos, $labels) {
    //return ['Musimundo', 'Fravega', 'Garbarino', 'Avenida'];
    
	$query = "SELECT label, backgroundColor, borderColor, pointBackgroundColor, pointBorderColor, pointHoverBackgroundColor, pointHoverBorderColor
              FROM (SELECT 1 AS ORD,
                           'Musimundo' AS label,
                           'rgba(255,0,0,0.2)' AS backgroundColor,
                           'rgba(255,0,0,1)' AS borderColor,
                           'rgba(255,0,0,1)' AS pointBackgroundColor,
                           '#fff' AS pointBorderColor,
                           '#fff' AS pointHoverBackgroundColor,
                           'rgba(255,0,0,1)' AS pointHoverBorderColor
                    UNION
                    SELECT 2 AS ORD,
                           'Fravega' AS label,
                           'rgba(0,51,204,0.2)' AS backgroundColor,
                           'rgba(0,51,204,1)' AS borderColor,
                           'rgba(0,51,204,1)' AS pointBackgroundColor,
                           '#fff' AS pointBorderColor,
                           '#fff' AS pointHoverBackgroundColor,
                           'rgba(0,51,204,1)' AS pointHoverBorderColor
                    UNION
                    SELECT 3 AS ORD,
                           'Garbarino' AS label,
                           'rgba(0,102,0,0.2)' AS backgroundColor,
                           'rgba(0,102,0,1)' AS borderColor,
                           'rgba(0,102,0,1)' AS pointBackgroundColor,
                           '#fff' AS pointBorderColor,
                           '#fff' AS pointHoverBackgroundColor,
                           'rgba(0,102,0,1)' AS pointHoverBorderColor
                    UNION
                    SELECT 4 AS ORD,
                           'Avenida' AS label,
                           'rgba(150,150,150,0.2)' AS backgroundColor,
                           'rgba(150,150,150,1)' AS borderColor,
                           'rgba(150,150,150,1)' AS pointBackgroundColor,
                           '#fff' AS pointBorderColor,
                           '#fff' AS pointHoverBackgroundColor,
                           'rgba(150,150,150,1)' AS pointHoverBorderColor) TMP
              WHERE (ORD = ".$pos." OR ".$pos." = -1)
              ORDER BY ORD";
  
    return array_simple($query, $labels);
}

function competidor_label($user_id, $pos) {
    return competidores($user_id, $pos, ["label"])[0];
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_trafico_panorama_mensual_tabla($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461 AS M201511, 2222914 AS M201601, 1512917 AS M201603, 2460873 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.2210 AS M201505, 0.2021 AS M201507, 0.2024 AS M201509, 0.2118 AS M201511, 0.2224 AS M201601, 0.1503 AS M201603, 0.1584 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -0.3734 AS M201507, 0.1635 AS M201509, 0.7636 AS M201511, -0.0118 AS M201601, -0.3194 AS M201603, 0.6266 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667 AS M201511, 3204757 AS M201601, 2607042 AS M201603, 4163589 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.3119 AS M201505, 0.3106 AS M201507, 0.2887 AS M201509, 0.3074 AS M201511, 0.3206 AS M201601, 0.2590 AS M201603, 0.2680 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -0.3177 AS M201507, 0.0796 AS M201509, 0.7941 AS M201511, -0.0181 AS M201601, -0.1865 AS M201603, 0.5971 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.3217 AS M201505, 0.3635 AS M201507, 0.3337 AS M201509, 0.3697 AS M201511, 0.3729 AS M201601, 0.4709 AS M201603, 0.4717 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -0.2257 AS M201507, 0.0664 AS M201509, 0.8664 AS M201511, -0.0506 AS M201601, 0.2718 AS M201603, 0.5459 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572 AS M201511, 840917 AS M201601, 1206563 AS M201603, 1582283 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.1454 AS M201505, 0.1238 AS M201507, 0.1752 AS M201509, 0.1111 AS M201511, 0.0841 AS M201601, 0.1199 AS M201603, 0.1019 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -0.4166 AS M201507, 0.6435 AS M201509, 0.0684 AS M201511, -0.2871 AS M201601, 0.4348 AS M201603, 0.3114 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );
                  
        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 7917879 AS M201505, 5425176 AS M201507, 6301865 AS M201509, 10618280 AS M201511, 9995661 AS M201601, 10066777 AS M201603, 15534767 AS M201605 UNION
                        SELECT 13 AS ORD, 'Var. M' AS VARIABLE, 0 AS M201505, -0.3148 AS M201507, 0.1616 AS M201509, 0.6849 AS M201511, -0.0586 AS M201601, 0.0071 AS M201603, 0.5432 AS M201605 UNION
                        SELECT 14 AS ORD, 'Average' AS VARIABLE, 1979469 AS M201505, 1356294 AS M201507, 1575466 AS M201509, 2654570 AS M201511, 2498915 AS M201601, 2516694 AS M201603, 3883691 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Tiempo_Promedio") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, '00:06:14' AS M201505, '00:06:43' AS M201507, '00:06:30' AS M201509, '00:06:03' AS M201511, '00:05:16' AS M201601, '00:05:01' AS M201603, '00:04:49' AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.29565 AS M201505, 0.33087 AS M201507, 0.32636 AS M201509, 0.26969 AS M201511, 0.27719 AS M201601, 0.31224 AS M201603, 0.27682 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.07754 AS M201507, -0.03226 AS M201509, -0.06923 AS M201511, -0.12948 AS M201601, -0.04747 AS M201603, -0.03987 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, '00:04:51' AS M201505, '00:04:37' AS M201507, '00:04:34' AS M201509, '00:05:09' AS M201511, '00:04:25' AS M201601, '00:04:14' AS M201603, '00:04:39' AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.23004 AS M201505, 0.22742 AS M201507, 0.22929 AS M201509, 0.22957 AS M201511, 0.23246 AS M201601, 0.26349 AS M201603, 0.26724 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.04811 AS M201507, -0.01083 AS M201509, 0.12774 AS M201511, -0.14239 AS M201601, -0.04151 AS M201603, 0.09843 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, '00:04:52' AS M201505, '00:04:34' AS M201507, '00:04:36' AS M201509, '00:06:02' AS M201511, '00:04:33' AS M201601, '00:03:18' AS M201603, '00:04:10' AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.23083 AS M201505, 0.22496 AS M201507, 0.23096 AS M201509, 0.26895 AS M201511, 0.23947 AS M201601, 0.20539 AS M201603, 0.23946 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.06164 AS M201507, 0.00730 AS M201509, 0.31159 AS M201511, -0.24586 AS M201601, -0.27473 AS M201603, 0.26263 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, '00:05:08' AS M201505, '00:04:24' AS M201507, '00:04:15' AS M201509, '00:05:12' AS M201511, '00:04:46' AS M201601, '00:03:31' AS M201603, '00:03:46' AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.24348 AS M201505, 0.21675 AS M201507, 0.21339 AS M201509, 0.23180 AS M201511, 0.25088 AS M201601, 0.21888 AS M201603, 0.21648 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.14286 AS M201507, -0.03409 AS M201509, 0.22353 AS M201511, -0.08333 AS M201601, -0.26224 AS M201603, 0.07109 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold", "time+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );
                  
        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, '00:21:05' AS M201505, '00:20:18' AS M201507, '00:19:55' AS M201509, '00:22:26' AS M201511, '00:19:00' AS M201601, '00:16:04' AS M201603, '00:17:24' AS M201605 UNION
                        SELECT 13 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.03715 AS M201507, -0.01888 AS M201509, 0.12636 AS M201511, -0.15305 AS M201601, -0.15439 AS M201603, 0.08299 AS M201605 UNION
                        SELECT 14 AS ORD, 'Average' AS VARIABLE, '00:05:16' AS M201505, '00:05:05' AS M201507, '00:04:59' AS M201509, '00:05:36' AS M201511, '00:04:45' AS M201601, '00:04:01' AS M201603, '00:04:21' AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "time", "time", "time", "time", "time", "time", "time"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "time", "time", "time", "time", "time", "time", "time")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Visitas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 6.16869119506057 AS M201505, 7.12244139543568 AS M201507, 7.5 AS M201509, 6.16 AS M201511, 4.99 AS M201601, 4.69 AS M201603, 4.58 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.31492 AS M201505, 0.33873 AS M201507, 0.34754 AS M201509, 0.28175 AS M201511, 0.26194 AS M201601, 0.28951 AS M201603, 0.27294 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.15461 AS M201507, 0.05301 AS M201509, -0.17867 AS M201511, -0.18994 AS M201601, -0.06012 AS M201603, -0.02345 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 4.37350563481555 AS M201505, 4.6769646997893 AS M201507, 4.87 AS M201509, 5.17957211596643 AS M201511, 4.82 AS M201601, 4.51 AS M201603, 4.59 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.22328 AS M201505, 0.22242 AS M201507, 0.22567 AS M201509, 0.23691 AS M201511, 0.25302 AS M201601, 0.27840 AS M201603, 0.27354 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.06939 AS M201507, 0.04127 AS M201509, 0.06357 AS M201511, -0.06942 AS M201601, -0.06432 AS M201603, 0.01774 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 4.72570424216 AS M201505, 5.43118243376564 AS M201507, 5.61 AS M201509, 6.01844830468392 AS M201511, 4.65 AS M201601, 3.54 AS M201603, 3.84 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.24126 AS M201505, 0.25829 AS M201507, 0.25996 AS M201509, 0.27528 AS M201511, 0.24409 AS M201601, 0.21852 AS M201603, 0.22884 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.14929 AS M201507, 0.03292 AS M201509, 0.07281 AS M201511, -0.22738 AS M201601, -0.23871 AS M201603, 0.08475 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 4.32 AS M201505, 3.79659767258926 AS M201507, 3.6 AS M201509, 4.50497971738617 AS M201511, 4.59 AS M201601, 3.46 AS M201603, 3.77 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.22054 AS M201505, 0.18056 AS M201507, 0.16682 AS M201509, 0.20605 AS M201511, 0.24094 AS M201601, 0.21358 AS M201603, 0.22467 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.12116 AS M201507, -0.05178 AS M201509, 0.25138 AS M201511, 0.01887 AS M201601, -0.24619 AS M201603, 0.08960 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold", "comma:2+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );
                  
        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 19.5879010720361 AS M201505, 21.0271862015799 AS M201507, 21.58 AS M201509, 21.8630001380365 AS M201511, 19.05 AS M201601, 16.2 AS M201603, 16.78 AS M201605 UNION
                        SELECT 13 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.07348 AS M201507, 0.02629 AS M201509, 0.01311 AS M201511, -0.12866 AS M201601, -0.14961 AS M201603, 0.03580 AS M201605 UNION
                        SELECT 14 AS ORD, 'Average' AS VARIABLE, 4.89697526800903 AS M201505, 5.25679655039497 AS M201507, 5.395 AS M201509, 5.46575003450913 AS M201511, 4.7625 AS M201601, 4.05 AS M201603, 4.195 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma:2", "comma:2", "comma:2", "comma:2", "comma:2", "comma:2", "comma:2"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma:2", "comma:2", "comma:2", "comma:2", "comma:2", "comma:2", "comma:2")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Abandono") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.25232 AS M201505, 0.23651 AS M201507, 0.24690 AS M201509, 0.23806 AS M201511, 0.29230 AS M201601, 0.33860 AS M201603, 0.34130 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.17735 AS M201505, 0.15099 AS M201507, 0.15699 AS M201509, 0.18132 AS M201511, 0.18821 AS M201601, 0.12322 AS M201603, 0.14550 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.06266 AS M201507, 0.04391 AS M201509, -0.03580 AS M201511, 0.22784 AS M201601, 0.15840 AS M201603, 0.00797 AS M201605 UNION
                       SELECT 3 AS ORD, 'Tráfico' AS VARIABLE, 441446.456914607 AS M201505, 259295.351447595 AS M201507, 314923.9128 AS M201509, 535508.049840747 AS M201511, 649757.7622 AS M201601, 512273.709675316 AS M201603, 839895.9549 AS M201605 UNION
                       SELECT 4 AS ORD, 'Fravega' AS VARIABLE, 0.29780 AS M201505, 0.31536 AS M201507, 0.31020 AS M201509, 0.28116 AS M201511, 0.30520 AS M201601, 0.33730 AS M201603, 0.29440 AS M201605 UNION
                       SELECT 5 AS ORD, 'Share' AS VARIABLE, 0.29547 AS M201505, 0.30941 AS M201507, 0.28130 AS M201509, 0.31070 AS M201511, 0.28332 AS M201601, 0.21151 AS M201603, 0.21235 AS M201605 UNION
                       SELECT 6 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.05898 AS M201507, -0.01636 AS M201509, -0.09361 AS M201511, 0.08549 AS M201601, 0.10518 AS M201603, -0.12719 AS M201605 UNION
                       SELECT 7 AS ORD, 'Tráfico' AS VARIABLE, 735456.341975798 AS M201505, 531357.582089218 AS M201507, 564280.167 AS M201509, 917622.27635935 AS M201511, 978091.8364 AS M201601, 879355.443314077 AS M201603, 1225760.6016 AS M201605 UNION
                       SELECT 8 AS ORD, 'Garbarino' AS VARIABLE, 0.31626 AS M201505, 0.30381 AS M201507, 0.27920 AS M201509, 0.26548 AS M201511, 0.38440 AS M201601, 0.45450 AS M201603, 0.40470 AS M201605 UNION
                       SELECT 9 AS ORD, 'Share' AS VARIABLE, 0.32363 AS M201505, 0.34890 AS M201507, 0.29274 AS M201509, 0.35286 AS M201511, 0.41500 AS M201601, 0.51821 AS M201603, 0.51376 AS M201605 UNION
                       SELECT 10 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.03936 AS M201507, -0.08101 AS M201509, -0.04914 AS M201511, 0.44794 AS M201601, 0.18236 AS M201603, -0.10957 AS M201605 UNION
                       SELECT 11 AS ORD, 'Tráfico' AS VARIABLE, 805569.93698722 AS M201505, 599174.105651934 AS M201507, 587223.4912 AS M201509, 1042164.74501068 AS M201511, 1432686.8612 AS M201601, 2154445.8975 AS M201603, 2965650.5034 AS M201605 UNION
                       SELECT 12 AS ORD, 'Avenida' AS VARIABLE, 0.44000 AS M201505, 0.48753 AS M201507, 0.48870 AS M201509, 0.38841 AS M201511, 0.46580 AS M201601, 0.50670 AS M201603, 0.46840 AS M201605 UNION
                       SELECT 13 AS ORD, 'Share' AS VARIABLE, 0.20355 AS M201505, 0.19070 AS M201507, 0.26897 AS M201509, 0.15513 AS M201511, 0.11346 AS M201601, 0.14705 AS M201603, 0.12839 AS M201605 UNION
                       SELECT 14 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.10803 AS M201507, 0.00239 AS M201509, -0.20522 AS M201511, 0.19926 AS M201601, 0.08781 AS M201603, -0.07559 AS M201605 UNION
                       SELECT 15 AS ORD, 'Tráfico' AS VARIABLE, 506661.32 AS M201505, 327494.697709711 AS M201507, 539540.4384 AS M201509, 458154.202843709 AS M201511, 391699.1386 AS M201601, 611365.561278104 AS M201603, 741141.3572 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold", "percent:2+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
                  
        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 16 AS ORD, 'Total' AS VARIABLE, 0.31437 AS M201505, 0.31655 AS M201507, 0.31831 AS M201509, 0.27815 AS M201511, 0.34537 AS M201601, 0.41299 AS M201603, 0.37158 AS M201605 UNION
                        SELECT 17 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.00693 AS M201507, 0.00558 AS M201509, -0.12618 AS M201511, 0.24169 AS M201601, 0.19577 AS M201603, -0.10025 AS M201605 UNION
                        SELECT 18 AS ORD, 'Tráfico' AS VARIABLE, 2489134.05587763 AS M201505, 1717321.73689846 AS M201507, 2005968.0094 AS M201509, 2953449.27405448 AS M201511, 3452235.5984 AS M201601, 4157440.6117675 AS M201603, 5772448.4171 AS M201605 UNION
                        SELECT 19 AS ORD, 'Average' AS VARIABLE, 0.32659 AS M201505, 0.33580 AS M201507, 0.33125 AS M201509, 0.29328 AS M201511, 0.36193 AS M201601, 0.40928 AS M201603, 0.37720 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "percent:2", "percent:2", "percent:2", "percent:2", "percent:2", "percent:2", "percent:2"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:2", "percent:2", "percent:2", "percent:2", "percent:2", "percent:2", "percent:2")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Trafico_Neto") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1308069.54308539 AS M201505, 837021.648552405 AS M201507, 960588.0872 AS M201509, 1713953.20142751 AS M201511, 1573156.2378 AS M201601, 1000643.33012184 AS M201603, 1620977.0451 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.24095 AS M201505, 0.22574 AS M201507, 0.22361 AS M201509, 0.22361 AS M201511, 0.24042 AS M201601, 0.16933 AS M201603, 0.16604 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.36011 AS M201507, 0.14763 AS M201509, 0.78427 AS M201511, -0.08215 AS M201601, -0.36393 AS M201603, 0.61993 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 1734200.6580242 AS M201505, 1153566.41791078 AS M201507, 1254804.833 AS M201509, 2346045.05994625 AS M201511, 2226665.1636 AS M201601, 1727687.08059365 AS M201603, 2937828.3984 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.31945 AS M201505, 0.31111 AS M201507, 0.29209 AS M201509, 0.30608 AS M201511, 0.34029 AS M201601, 0.29237 AS M201603, 0.30094 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.33481 AS M201507, 0.08776 AS M201509, 0.86965 AS M201511, -0.05089 AS M201601, -0.22409 AS M201603, 0.70044 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 1741633.06301278 AS M201505, 1373023.89434807 AS M201507, 1516012.5088 AS M201509, 2883413.78826258 AS M201511, 2294386.1388 AS M201601, 2585809.1025 AS M201603, 4362371.4966 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.32082 AS M201505, 0.37030 AS M201507, 0.35290 AS M201509, 0.37619 AS M201511, 0.35064 AS M201601, 0.43758 AS M201603, 0.44686 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.21165 AS M201507, 0.10414 AS M201509, 0.90197 AS M201511, -0.20428 AS M201601, 0.12702 AS M201603, 0.68704 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 644841.68 AS M201505, 344242.302290289 AS M201507, 564491.5616 AS M201509, 721418.678698712 AS M201511, 449217.8614 AS M201601, 595197.614719733 AS M201603, 841141.6428 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.11878 AS M201505, 0.09284 AS M201507, 0.13140 AS M201509, 0.09412 AS M201511, 0.06865 AS M201601, 0.10072 AS M201603, 0.08616 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.46616 AS M201507, 0.63981 AS M201509, 0.27800 AS M201511, -0.37731 AS M201601, 0.32496 AS M201603, 0.41321 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );
                  
        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 5428744.94412237 AS M201505, 3707854.26310154 AS M201507, 4295896.9906 AS M201509, 7664830.72833506 AS M201511, 6543425.4016 AS M201601, 5909337.12793522 AS M201603, 9762318.5829 AS M201605 UNION
                        SELECT 13 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.31700 AS M201507, 0.15859 AS M201509, 0.78422 AS M201511, -0.14631 AS M201601, -0.09690 AS M201603, 0.65202 AS M201605 UNION
                        SELECT 14 AS ORD, 'Average' AS VARIABLE, 1594634.42137412 AS M201505, 1121203.98693708 AS M201507, 1243801.80966667 AS M201509, 2314470.68321212 AS M201511, 2031402.5134 AS M201601, 1771379.8377385 AS M201603, 2973725.6467 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
}

function get_trafico_panorama_mensual_indicador($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $head = array(
                    array("Competidor", "Acumulado", "Último Mes"),
                    array("Promedio", "Variación", "Promedio", "Variación")
                );
        $head_style = array(
                          array("row:2", "col:2+center", "col:2+center"),
                          array("text+center", "text+center", "text+center", "text+center")
                      );

        $body = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Tiempo_Promedio") {
        $head = array(
                    array("Competidor", "Acumulado", "Último Mes"),
                    array("Promedio", "Variación", "Promedio", "Variación")
                );
        $head_style = array(
                          array("row:2", "col:2+center", "col:2+center"),
                          array("text+center", "text+center", "text+center", "text+center")
                      );

        $body = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'GREEN' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'RED' AS MONTH_VAR UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'RED' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'RED' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Visitas") {
        $head = array(
                    array("Competidor", "Acumulado", "Último Mes"),
                    array("Promedio", "Variación", "Promedio", "Variación")
                );
        $head_style = array(
                          array("row:2", "col:2+center", "col:2+center"),
                          array("text+center", "text+center", "text+center", "text+center")
                      );

        $body = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'GREEN' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'RED' AS MONTH_VAR UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'RED' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'RED' AS MONTH_VAR UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'RED' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Abandono") {
        $head = array(
                    array("Competidor", "Acumulado", "Último Mes"),
                    array("Promedio", "Variación", "Promedio", "Variación")
                );
        $head_style = array(
                          array("row:2", "col:2+center", "col:2+center"),
                          array("text+center", "text+center", "text+center", "text+center")
                      );

        $body = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'GREEN' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'RED' AS MONTH_VAR UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'RED' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Trafico_Neto") {
        $head = array(
                    array("Competidor", "Acumulado", "Último Mes"),
                    array("Promedio", "Variación", "Promedio", "Variación")
                );
        $head_style = array(
                          array("row:2", "col:2+center", "col:2+center"),
                          array("text+center", "text+center", "text+center", "text+center")
                      );

        $body = "SELECT Competidor, ACUM_AVG, ACUM_VAR, MONTH_AVG, MONTH_VAR
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS ACUM_AVG, 'GREEN' AS ACUM_VAR, 'GREEN' AS MONTH_AVG, 'GREEN' AS MONTH_VAR UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS ACUM_AVG, 'RED' AS ACUM_VAR, 'RED' AS MONTH_AVG, 'RED' AS MONTH_VAR) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
}

function get_trafico_panorama_mensual_anual($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $head = array("Variable", "May-15", "May-16", "YTD");
        $head_style = array("text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M1, M2, M3
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1749516 AS M1, 2460873 AS M2, 0.406602168828407 AS M3 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.22095765797886 AS M1, 0.158410679735332 AS M2, 0 AS M3 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 2469657 AS M1, 4163589 AS M2, 0.685897677288789 AS M3 UNION
                       SELECT 3 AS ORD, 'Share' AS VARIABLE, 0.311908908938871 AS M1, 0.268017473322902 AS M2, 0 AS M3 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 2547203 AS M1, 7328022 AS M2, 1.87688967074866 AS M3 UNION
                       SELECT 5 AS ORD, 'Share' AS VARIABLE, 0.321702693360179 AS M1, 0.471717535254954 AS M2, 0 AS M3 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 1151503 AS M1, 1582283 AS M2, 0.374102368817103 AS M3 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.14543073972209 AS M1, 0.101854311686812 AS M2, 0 AS M3) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma+bold", "comma+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma+bold", "comma+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma+bold", "comma+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none")
                      );
                  
        $foot = "SELECT VARIABLE, M1, M2, M3
                  FROM (SELECT 8 AS ORD, 'Total' AS VARIABLE, 7917879 AS M1, 15534767 AS M2, 0.961985905568903 AS M3 UNION
                        SELECT 9 AS ORD, 'Average' AS VARIABLE, 1979469.75 AS M1, 3883691.75 AS M2, 0 AS M3) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "percent:1+bold+row:2"),
                          array("text", "comma", "comma", "none")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Tiempo_Promedio") {
        $head = array("Variable", "May-15", "May-16", "YTD");
        $head_style = array("text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M1, M2, M3
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, '00:06:14' AS M1, '00:04:49' AS M2, -0.227272727272727 AS M3 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.295652173913043 AS M1, 0.276819923371647 AS M2, 0 AS M3 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, '00:04:51' AS M1, '00:04:39' AS M2, -0.0412371134020631 AS M3 UNION
                       SELECT 3 AS ORD, 'Share' AS VARIABLE, 0.2300395256917 AS M1, 0.267241379310345 AS M2, 0 AS M3 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, '00:04:52' AS M1, '00:04:10' AS M2, -0.143835616438356 AS M3 UNION
                       SELECT 5 AS ORD, 'Share' AS VARIABLE, 0.230830039525692 AS M1, 0.239463601532567 AS M2, 0 AS M3 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, '00:05:08' AS M1, '00:03:46' AS M2, -0.266233766233766 AS M3 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.243478260869565 AS M1, 0.216475095785441 AS M2, 0 AS M3) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "time+bold", "time+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "time+bold", "time+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "time+bold", "time+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "time+bold", "time+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none")
                      );
                  
        $foot = "SELECT VARIABLE, M1, M2, M3
                  FROM (SELECT 8 AS ORD, 'Total' AS VARIABLE, '00:21:05' AS M1, '00:17:24' AS M2, -0.174703557312253 AS M3 UNION
                        SELECT 9 AS ORD, 'Average' AS VARIABLE, '00:05:16' AS M1, '00:04:21' AS M2, 0 AS M3) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "time", "time", "percent:1+bold+row:2"),
                          array("text", "time", "time", "none")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Visitas") {
        $head = array("Variable", "May-15", "May-16", "YTD");
        $head_style = array("text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M1, M2, M3
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 6.16869119506057 AS M1, 4.58 AS M2, -0.257541047983189 AS M3 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.31492354246505 AS M1, 0.272943980929678 AS M2, 0 AS M3 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 4.37350563481555 AS M1, 4.59 AS M2, 0.0495013344583429 AS M3 UNION
                       SELECT 3 AS ORD, 'Share' AS VARIABLE, 0.223275869054659 AS M1, 0.273539928486293 AS M2, 0 AS M3 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 4.72570424216 AS M1, 3.84 AS M2, -0.187422698665367 AS M3 UNION
                       SELECT 5 AS ORD, 'Share' AS VARIABLE, 0.241256284927151 AS M1, 0.228843861740167 AS M2, 0 AS M3 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 4.32 AS M1, 3.77 AS M2, -0.127314814814815 AS M3 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.220544303553139 AS M1, 0.224672228843862 AS M2, 0 AS M3) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma:2+bold", "comma:2+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma:2+bold", "comma:2+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma:2+bold", "comma:2+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma:2+bold", "comma:2+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none")
                      );
                  
        $foot = "SELECT VARIABLE, M1, M2, M3
                  FROM (SELECT 8 AS ORD, 'Total' AS VARIABLE, 19.5879010720361 AS M1, 16.78 AS M2, -0.143348746846833 AS M3 UNION
                        SELECT 9 AS ORD, 'Average' AS VARIABLE, 4.89697526800903 AS M1, 4.195 AS M2, 0 AS M3) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma:2", "comma:2", "percent:1+bold+row:2"),
                          array("text", "comma:2", "comma:2", "none")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Abandono") {
        $head = array("Variable", "May-15", "May-16", "YTD");
        $head_style = array("text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M1, M2, M3
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.252324904096109 AS M1, 0.3413 AS M2, 0.352621142263474 AS M3 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.80263979941216 AS M1, 0.918503829569717 AS M2, 0 AS M3 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 0.297796958029312 AS M1, 0.2944 AS M2, -0.0114069601375111 AS M3 UNION
                       SELECT 3 AS ORD, 'Share' AS VARIABLE, 0.947285372065995 AS M1, 0.792286924773878 AS M2, 0 AS M3 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 0.316256669369194 AS M1, 0.4047 AS M2, 0.279656807893458 AS M3 UNION
                       SELECT 5 AS ORD, 'Share' AS VARIABLE, 1.00600529533368 AS M1, 1.08912540236409 AS M2, 0 AS M3 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 0.44 AS M1, 0.4684 AS M2, 0.0645454545454545 AS M3 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 1.39963002465596 AS M1, 1.26055433275844 AS M2, 0 AS M3) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none")
                      );
                  
        $foot = "SELECT VARIABLE, M1, M2, M3
                  FROM (SELECT 8 AS ORD, 'Total' AS VARIABLE, 0.314368791929963 AS M1, 0.371582555251714 AS M2, 0.181995684019732 AS M3 UNION
                        SELECT 9 AS ORD, 'Average' AS VARIABLE, 0.326594632873654 AS M1, 0.3772 AS M2, 0 AS M3) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "percent:1", "percent:1", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Trafico_Neto") {
        $head = array("Variable", "May-15", "May-16", "YTD");
        $head_style = array("text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M1, M2, M3
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 1308069.54308539 AS M1, 1620977.0451 AS M2, 0.239213200604412 AS M3 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.240952477331178 AS M1, 0.166044268206874 AS M2, 0 AS M3 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 1734200.6580242 AS M1, 2937828.3984 AS M2, 0.694053329299913 AS M3 UNION
                       SELECT 3 AS ORD, 'Share' AS VARIABLE, 0.319447805316733 AS M1, 0.300935517874411 AS M2, 0 AS M3 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 1741633.06301278 AS M1, 4362371.4966 AS M2, 1.50475923387313 AS M3 UNION
                       SELECT 5 AS ORD, 'Share' AS VARIABLE, 0.320816888790921 AS M1, 0.446858137188974 AS M2, 0 AS M3 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 644841.68 AS M1, 841141.6428 AS M2, 0.304415748684235 AS M3 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.118782828561169 AS M1, 0.0861620767297404 AS M2, 0 AS M3) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma+bold", "comma+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma+bold", "comma+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none"),
                          array("text+bold", "comma+bold", "comma+bold", "percent:1+bold+row:2"),
                          array("text", "percent:1", "percent:1", "none")
                      );
                  
        $foot = "SELECT VARIABLE, M1, M2, M3
                  FROM (SELECT 8 AS ORD, 'Total' AS VARIABLE, 5428744.94412237 AS M1, 9762318.5829 AS M2, 0.798264365591448 AS M3 UNION
                        SELECT 9 AS ORD, 'Average' AS VARIABLE, 1357186.23603059 AS M1, 2440579.645725 AS M2, 0 AS M3) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "percent:1+bold+row:2"),
                          array("text", "comma", "comma", "none")
                      );
                      
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
}

function get_trafico_panorama_mensual_acumulado($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 12567510.29 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 19212721.86 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 26343565.53 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 7736608.06 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Tiempo_Promedio") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.028194444 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.02255787 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.022280093 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.021550926 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Visitas") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 41.21 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 33.02 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 33.82 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 28.04 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Abandono") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 1.9460 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 2.1414 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 2.4083 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 3.2455 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Trafico_Neto") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 9014409.09 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 13380797.61 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 16756649.99 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 4160551.34 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
}

function get_trafico_panorama_mensual_tendencia($user_id, $tipo) {
    if ($tipo == "Trafico_Total") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1749516 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1096317 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1275512 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 2249461 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 2222914 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1512917 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 2460873 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2469657 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1684924 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1819085 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3263667 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3204757 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 2607043 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4163589 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 2547203 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1972198 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 2103236 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 3925579 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 3727073 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4740255 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 7328022 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1151503 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 671737 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1104032 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1179573 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 840917 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1206563 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1582283 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Tiempo_Promedio") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 6.23333333333333 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 6.71666666666666 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 6.5 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 6.05 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 5.26666666666667 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 5.01666666666667 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4.81666666666667 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 4.85000000000001 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 4.61666666666667 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 4.56666666666667 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 5.15 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 4.41666666666667 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4.23333333333333 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4.65 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 4.86666666666667 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 4.56666666666667 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 4.6 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 6.03333333333333 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 4.55 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 3.3 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4.16666666666667 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 5.13333333333333 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 4.40000000000001 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 4.25 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 5.2 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 4.76666666666667 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 3.51666666666667 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 3.76666666666667 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Visitas") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 6.16869119506057 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 7.12244139543568 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 7.5 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 6.16 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 4.99 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4.69 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4.58 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 4.37350563481555 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 4.6769646997893 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 4.87 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 5.17957211596643 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 4.82 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 4.51 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4.59 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 4.72570424216 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 5.43118243376564 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 5.61 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 6.01844830468392 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 4.65 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 3.54 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 3.84 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 4.32 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 3.79659767258926 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 3.6 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 4.50497971738617 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 4.59 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 3.46 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 3.77 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Abandono") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 0.252324904096109 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 0.236514941798398 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 0.2469 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 0.238060579856098 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 0.2923 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 0.3386 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 0.3413 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 0.297796958029312 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 0.315359969998183 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 0.3102 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 0.281162931696978 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 0.3052 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 0.3373 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 0.2944 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 0.316256669369194 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 0.303810320085475 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 0.2792 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 0.26548054921772 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 0.3844 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 0.4545 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 0.4047 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 0.44 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 0.487534105921976 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 0.4887 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 0.388406863206809 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 0.4658 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 0.5067 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 0.4684 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Trafico_Neto") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1308069.54308539 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 837021.648552405 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 960588.0872 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1713953.20142751 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 1573156.2378 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1000643.33012184 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1620977.0451 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1734200.6580242 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1153566.41791078 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1254804.833 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 2346045.05994625 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 2226665.1636 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1727687.08059365 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 2937828.3984 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 1741633.06301278 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 1373023.89434807 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 1516012.5088 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 2883413.78826258 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 2294386.1388 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 2585809.1025 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 4362371.4966 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 644841.68 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 344242.302290289 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 564491.5616 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 721418.678698712 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 449217.8614 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 595197.614719733 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 841141.6428 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
}


function get_trafico_acumulado_Generacion_tabla($user_id) {
    $head = array("Variables", "Acumulado", "Directo", "Mail", "Referidos", "Búsquedas", "Social", "Displays");
    $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
    
    $body = "SELECT VARIABLE, M1, M2, M3, M4, M5, M6, M7
             FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 12567510.2910654 AS M1, 3657145.49470004 AS M2, 238782.695530243 AS M3, 1784586.46133129 AS M4, 6440849.02417102 AS M5, 314187.757276635 AS M6, 120648.098794228 AS M7 UNION
                   SELECT 1 AS ORD, 'Share Propio' AS VARIABLE, 0.19082 AS M1, 0.29100 AS M2, 0.01900 AS M3, 0.14200 AS M4, 0.51250 AS M5, 0.02500 AS M6, 0.00960 AS M7 UNION
                   SELECT 2 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.19899 AS M2, 0.13455 AS M3, 0.15859 AS M4, 0.21628 AS M5, 0.07806 AS M6, 0.19962 AS M7 UNION
                   SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 19212721.8602133 AS M1, 5264285.78969845 AS M2, 220946.301392453 AS M3, 2952995.34991479 AS M4, 9079932.35113682 AS M5, 1581207.00909556 AS M6, 96063.6093010666 AS M7 UNION
                   SELECT 4 AS ORD, 'Share Propio' AS VARIABLE, 0.29172 AS M1, 0.27400 AS M2, 0.01150 AS M3, 0.15370 AS M4, 0.47260 AS M5, 0.08230 AS M6, 0.00500 AS M7 UNION
                   SELECT 5 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.28644 AS M2, 0.12450 AS M3, 0.26242 AS M4, 0.30490 AS M5, 0.39285 AS M6, 0.15894 AS M7 UNION
                   SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 26343565.5332733 AS M1, 6930992.0918042 AS M2, 674395.277651796 AS M3, 4373031.87852336 AS M4, 12621202.2469912 AS M5, 1577979.57544307 AS M6, 150158.323539658 AS M7 UNION
                   SELECT 7 AS ORD, 'Share Propio' AS VARIABLE, 0.39999 AS M1, 0.26310 AS M2, 0.02560 AS M3, 0.16600 AS M4, 0.47910 AS M5, 0.05990 AS M6, 0.00570 AS M7 UNION
                   SELECT 8 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.37713 AS M2, 0.38000 AS M3, 0.38861 AS M4, 0.42382 AS M5, 0.39205 AS M6, 0.24845 AS M7 UNION
                   SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 7736608.05754026 AS M1, 2526002.53078689 AS M2, 640591.147164333 AS M3, 2142266.7711329 AS M4, 1637839.92578127 AS M5, 551620.15450262 AS M6, 237513.867366486 AS M7 UNION
                   SELECT 10 AS ORD, 'Share Propio' AS VARIABLE, 0.11747 AS M1, 0.32650 AS M2, 0.08280 AS M3, 0.27690 AS M4, 0.21170 AS M5, 0.07130 AS M6, 0.03070 AS M7 UNION
                   SELECT 11 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.13744 AS M2, 0.36095 AS M3, 0.19037 AS M4, 0.05500 AS M5, 0.13705 AS M6, 0.39299 AS M7) TMP
             ORDER BY ORD";
    $body_style = array(
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                  );
              
    $foot = "SELECT VARIABLE, M1, M2, M3, M4, M5, M6, M7
              FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 65860405.7420923 AS M1, 18378425.9069896 AS M2, 1774715.42173882 AS M3, 11252880.4609023 AS M4, 29779823.5480803 AS M5, 4024994.49631788 AS M6, 604383.899001438 AS M7 UNION
                    SELECT 13 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.27905 AS M2, 0.02695 AS M3, 0.17086 AS M4, 0.45217 AS M5, 0.06111 AS M6, 0.00918 AS M7 UNION
                    SELECT 14 AS ORD, 'Average' AS VARIABLE, 16465101.4355231 AS M1, 4594606.47674739 AS M2, 443678.855434706 AS M3, 2813220.11522558 AS M4, 7444955.88702008 AS M5, 1006248.62407947 AS M6, 151095.97475036 AS M7) TMP
              ORDER BY ORD";
    $foot_style = array(
                      array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                  );
                  
    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
            ));
}

function get_trafico_acumulado_Generacion_indicador($user_id) {
    $head = array("Competidor", "Directo", "Mail", "Referidos", "Búsquedas", "Social", "Displays");
    $head_style = array("text", "text", "text", "text", "text", "text", "text");

    $body = "SELECT Competidor, M1, M2, M3, M4, M5, M6
             FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'GREEN' AS M1, 'RED' AS M2, 'RED' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                   SELECT 1 AS ORD, 'Fravega' AS Competidor, 'RED' AS M1, 'RED' AS M2, 'RED' AS M3, 'GREEN' AS M4, 'GREEN' AS M5, 'RED' AS M6 UNION
                   SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'RED' AS M1, 'RED' AS M2, 'RED' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'RED' AS M6 UNION
                   SELECT 3 AS ORD, 'Avenida' AS Competidor, 'GREEN' AS M1, 'GREEN' AS M2, 'GREEN' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'GREEN' AS M6) TMP
             ORDER BY ORD";
    $body_style = array("text", "icon", "icon", "icon", "icon", "icon", "icon");
    
    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
            ));
}

function get_trafico_acumulado_Generacion_tendencia($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 3657145.49470004 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 238782.695530243 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 1784586.46133129 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 6440849.02417102 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 314187.757276635 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 120648.098794228 AS value) TMP
               ORDER BY ORD";

	$query2 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 5264285.78969845 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 220946.301392453 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 2952995.34991479 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 9079932.35113682 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 1581207.00909556 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 96063.6093010666 AS value) TMP
               ORDER BY ORD";

	$query3 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 6930992.0918042 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 674395.277651796 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 4373031.87852336 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 12621202.2469912 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 1577979.57544307 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 150158.323539658 AS value) TMP
               ORDER BY ORD";

	$query4 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 2526002.53078689 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 640591.147164333 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 2142266.7711329 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 1637839.92578127 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 551620.15450262 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 237513.867366486 AS value) TMP
               ORDER BY ORD";

	$query5 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 4594606.47674739 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 443678.855434706 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 2813220.11522558 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 7444955.88702008 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 1006248.62407947 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 151095.97475036 AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array("key"=>"Musimundo", "values"=>table_simple($query1)),
                array("key"=>"Fravega", "values"=>table_simple($query2)),
                array("key"=>"Garbarino", "values"=>table_simple($query3)),
                array("key"=>"Avenida", "values"=>table_simple($query4)),
                array("key"=>"Average", "values"=>table_simple($query5))
            ));
}


function get_trafico_acumulado_Busquedas_tabla($user_id) {
    $head = array("Variables", "Acumulado", "Orgánico", "Inorgánico");
    $head_style = array("text", "text", "text", "text");
    
    $body = "SELECT VARIABLE, M1, M2, M3
             FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 6440849.02417102 AS M1, 4628394.1087693 AS M2, 1812454.91540173 AS M3 UNION
                   SELECT 1 AS ORD, 'Share Propio' AS VARIABLE, 0.21628 AS M1, 0.71860 AS M2, 0.28140 AS M3 UNION
                   SELECT 2 AS ORD, 'Share Mercado' AS VARIABLE, 0.00000 AS M1, 0.23003 AS M2, 0.18764 AS M3 UNION
                   SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 9079932.35113682 AS M1, 6074474.74291053 AS M2, 3005457.60822629 AS M3 UNION
                   SELECT 4 AS ORD, 'Share Propio' AS VARIABLE, 0.30490 AS M1, 0.66900 AS M2, 0.33100 AS M3 UNION
                   SELECT 5 AS ORD, 'Share Mercado' AS VARIABLE, 0.00000 AS M1, 0.30190 AS M2, 0.31115 AS M3 UNION
                   SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 12621202.2469912 AS M1, 8796977.96615288 AS M2, 3824224.28083834 AS M3 UNION
                   SELECT 7 AS ORD, 'Share Propio' AS VARIABLE, 0.42382 AS M1, 0.69700 AS M2, 0.30300 AS M3 UNION
                   SELECT 8 AS ORD, 'Share Mercado' AS VARIABLE, 0.00000 AS M1, 0.43721 AS M2, 0.39591 AS M3 UNION
                   SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 1637839.92578127 AS M1, 620741.331871102 AS M2, 1017098.59391017 AS M3 UNION
                   SELECT 10 AS ORD, 'Share Propio' AS VARIABLE, 0.05500 AS M1, 0.37900 AS M2, 0.62100 AS M3 UNION
                   SELECT 11 AS ORD, 'Share Mercado' AS VARIABLE, 0.00000 AS M1, 0.03085 AS M2, 0.10530 AS M3) TMP
             ORDER BY ORD";
    $body_style = array(
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1")
                  );
              
    $foot = "SELECT VARIABLE, M1, M2, M3
              FROM (SELECT 12 AS ORD, 'Mercado' AS VARIABLE, 29779823.5480803 AS M1, 20120588.1497038 AS M2, 9659235.39837652 AS M3 UNION
                    SELECT 13 AS ORD, 'Share I.' AS VARIABLE, 0.00000 AS M1, 0.67564 AS M2, 0.32436 AS M3 UNION
                    SELECT 14 AS ORD, 'Average' AS VARIABLE, 9380661.20743302 AS M1, 6499948.93927757 AS M2, 2880712.26815545 AS M3) TMP
              ORDER BY ORD";
    $foot_style = array(
                      array("text", "comma", "comma", "comma"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "comma", "comma", "comma")
                  );
                  
    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
            ));
}

function get_trafico_acumulado_Busquedas_acumulado($user_id, $tipo) {
    if ($tipo == "Inorganico") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.188 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.311 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.396 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.105 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Organico") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.230 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.302 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.437 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.031 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
}

function get_trafico_acumulado_Busquedas_tendencia($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.7186 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.2814 AS value) TMP
               ORDER BY ORD";

	$query2 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.669 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.331 AS value) TMP
               ORDER BY ORD";

	$query3 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.697 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.303 AS value) TMP
               ORDER BY ORD";

	$query4 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.379 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.621 AS value) TMP
               ORDER BY ORD";

	$query5 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.67564497543844 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.32435502456156 AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array("key"=>"Musimundo", "values"=>table_simple($query1)),
                array("key"=>"Fravega", "values"=>table_simple($query2)),
                array("key"=>"Garbarino", "values"=>table_simple($query3)),
                array("key"=>"Avenida", "values"=>table_simple($query4)),
                array("key"=>"Mercado", "values"=>table_simple($query5))
            ));
}


function get_trafico_acumulado_Share_Canal_acumulado($user_id, $tipo) {
    if ($tipo == "Directo") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 3657145.49470004 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 5264285.78969845 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 6930992.0918042 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 2526002.53078689 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Mail") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 238782.695530243 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 220946.301392453 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 674395.277651796 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 640591.147164333 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Referidos") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 1784586.46133129 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 2952995.34991479 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 4373031.87852336 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 2142266.7711329 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Busquedas") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 6440849.02417102 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 9079932.35113682 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 12621202.2469912 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 1637839.92578127 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Social") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 314187.757276635 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 1581207.00909556 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 1577979.57544307 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 551620.15450262 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Displays") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 120648.098794228 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 96063.6093010666 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 150158.323539658 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 237513.867366486 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
}

function get_trafico_acumulado_Share_Canal_b100_acumulado($user_id, $tipo) {
    if ($tipo == "Directo") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.252035336913217 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.237311623072926 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.227871124198857 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.282781915815001 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Mail") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.13678905687545 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.0827933765298776 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.184305255579554 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.596112311015119 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Referidos") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.192255618738153 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.208096398591931 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.224749526130517 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.374898456539399 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Busquedas") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.305805835670386 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.281997732561609 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.285876245599379 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.126320186168626 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Social") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.10482180293501 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.345073375262054 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.251153039832285 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.29895178197065 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Displays") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 0.188235294117647 AS value UNION
                        SELECT 1 AS ORD, 'Fravega' AS label, 0.0980392156862745 AS value UNION
                        SELECT 2 AS ORD, 'Garbarino' AS label, 0.111764705882353 AS value UNION
                        SELECT 3 AS ORD, 'Avenida' AS label, 0.601960784313725 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
}


function get_trafico_mes_Generacion_tabla($user_id) {
    $head = array("Variables", "Acumulado", "Directo", "Mail", "Referidos", "Búsquedas", "Social", "Displays");
    $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
    
    $body = "SELECT VARIABLE, M1, M2, M3, M4, M5, M6, M7
             FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 2460873 AS M1, 1180259 AS M2, 44479 AS M3, 367357 AS M4, 812385 AS M5, 18884 AS M6, 37509 AS M7 UNION
                   SELECT 1 AS ORD, 'Share Propio' AS VARIABLE, 0.15841 AS M1, 0.47961 AS M2, 0.01807 AS M3, 0.14928 AS M4, 0.33012 AS M5, 0.00767 AS M6, 0.01524 AS M7 UNION
                   SELECT 2 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.13574 AS M2, 0.22415 AS M3, 0.18441 AS M4, 0.19869 AS M5, 0.05255 AS M6, 0.18650 AS M7 UNION
                   SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 4163589 AS M1, 1966844 AS M2, 24506 AS M3, 551789 AS M4, 1376707 AS M5, 172494 AS M6, 71249 AS M7 UNION
                   SELECT 4 AS ORD, 'Share Propio' AS VARIABLE, 0.26802 AS M1, 0.47239 AS M2, 0.00589 AS M3, 0.13253 AS M4, 0.33065 AS M5, 0.04143 AS M6, 0.01711 AS M7 UNION
                   SELECT 5 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.22620 AS M2, 0.12350 AS M3, 0.27699 AS M4, 0.33672 AS M5, 0.47998 AS M6, 0.35425 AS M7 UNION
                   SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 7328022 AS M1, 4736222 AS M2, 113766 AS M3, 762089 AS M4, 1535640 AS M5, 127668 AS M6, 52637 AS M7 UNION
                   SELECT 7 AS ORD, 'Share Propio' AS VARIABLE, 0.47172 AS M1, 0.64632 AS M2, 0.01552 AS M3, 0.10400 AS M4, 0.20956 AS M5, 0.01742 AS M6, 0.00718 AS M7 UNION
                   SELECT 8 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.54470 AS M2, 0.57331 AS M3, 0.38256 AS M4, 0.37559 AS M5, 0.35525 AS M6, 0.26171 AS M7 UNION
                   SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 1582283 AS M1, 811783 AS M2, 15685 AS M3, 310863 AS M4, 363891 AS M5, 40330 AS M6, 39731 AS M7 UNION
                   SELECT 10 AS ORD, 'Share Propio' AS VARIABLE, 0.10185 AS M1, 0.51305 AS M2, 0.00991 AS M3, 0.19646 AS M4, 0.22998 AS M5, 0.02549 AS M6, 0.02511 AS M7 UNION
                   SELECT 11 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.09336 AS M2, 0.07904 AS M3, 0.15605 AS M4, 0.08900 AS M5, 0.11222 AS M6, 0.19754 AS M7) TMP
             ORDER BY ORD";
    $body_style = array(
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                  );
              
    $foot = "SELECT VARIABLE, M1, M2, M3, M4, M5, M6, M7
              FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 15534767 AS M1, 8695108 AS M2, 198436 AS M3, 1992098 AS M4, 4088623 AS M5, 359376 AS M6, 201126 AS M7 UNION
                    SELECT 13 AS ORD, 'Share de Mercado' AS VARIABLE, 0.00000 AS M1, 0.55972 AS M2, 0.01277 AS M3, 0.12823 AS M4, 0.26319 AS M5, 0.02313 AS M6, 0.01295 AS M7 UNION
                    SELECT 14 AS ORD, 'Average' AS VARIABLE, 3883691.75 AS M1, 2173777 AS M2, 49609 AS M3, 498024.5 AS M4, 1022155.75 AS M5, 89844 AS M6, 50281.5 AS M7) TMP
              ORDER BY ORD";
    $foot_style = array(
                      array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                  );
                  
    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
            ));
}

function get_trafico_mes_Generacion_indicador($user_id) {
    $head = array("Competidor", "Directo", "Mail", "Referidos", "Búsquedas", "Social", "Displays");
    $head_style = array("text", "text", "text", "text", "text", "text", "text");

    $body = "SELECT Competidor, M1, M2, M3, M4, M5, M6
             FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'GREEN' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                   SELECT 1 AS ORD, 'Fravega' AS Competidor, 'RED' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'GREEN' AS M4, 'GREEN' AS M5, 'GREEN' AS M6 UNION
                   SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'RED' AS M5, 'RED' AS M6 UNION
                   SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'GREEN' AS M6) TMP
             ORDER BY ORD";
    $body_style = array("text", "icon", "icon", "icon", "icon", "icon", "icon");
    
    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
            ));
}

function get_trafico_mes_Generacion_tendencia($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 1180259 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 44479 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 367357 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 812385 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 18884 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 37509 AS value) TMP
               ORDER BY ORD";

	$query2 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 1966844 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 24506 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 551789 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 1376707 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 172494 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 71249 AS value) TMP
               ORDER BY ORD";

	$query3 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 4736222 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 113766 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 762089 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 1535640 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 127668 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 52637 AS value) TMP
               ORDER BY ORD";

	$query4 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 811783 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 15685 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 310863 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 363891 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 40330 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 39731 AS value) TMP
               ORDER BY ORD";

	$query5 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Directo' AS label, 2173777 AS value UNION
                     SELECT 2 AS ORD, 'Mail' AS label, 49609 AS value UNION
                     SELECT 3 AS ORD, 'Referidos' AS label, 498024.5 AS value UNION
                     SELECT 4 AS ORD, 'Búsquedas' AS label, 1022155.75 AS value UNION
                     SELECT 5 AS ORD, 'Social' AS label, 89844 AS value UNION
                     SELECT 6 AS ORD, 'Displays' AS label, 50281.5 AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array("key"=>"Musimundo", "values"=>table_simple($query1)),
                array("key"=>"Fravega", "values"=>table_simple($query2)),
                array("key"=>"Garbarino", "values"=>table_simple($query3)),
                array("key"=>"Avenida", "values"=>table_simple($query4)),
                array("key"=>"Average", "values"=>table_simple($query5))
            ));
}


function get_trafico_mes_Busquedas_tabla($user_id) {
    $head = array("Variables", "Acumulado", "Orgánico", "Inorgánico");
    $head_style = array("text", "text", "text", "text");
    
    $body = "SELECT VARIABLE, M1, M2, M3
             FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 812385 AS M1, 577756 AS M2, 234629 AS M3 UNION
                   SELECT 1 AS ORD, 'Share Propio' AS VARIABLE, 0.19869 AS M1, 0.71118 AS M2, 0.28882 AS M3 UNION
                   SELECT 2 AS ORD, 'Share Mercado' AS VARIABLE, 0.00000 AS M1, 0.21960 AS M2, 0.16095 AS M3 UNION
                   SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 1376707 AS M1, 789667 AS M2, 587040 AS M3 UNION
                   SELECT 4 AS ORD, 'Share Propio' AS VARIABLE, 0.33672 AS M1, 0.57359 AS M2, 0.42641 AS M3 UNION
                   SELECT 5 AS ORD, 'Share Mercado' AS VARIABLE, 0.00000 AS M1, 0.30015 AS M2, 0.40271 AS M3 UNION
                   SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 1535640 AS M1, 1179043 AS M2, 356597 AS M3 UNION
                   SELECT 7 AS ORD, 'Share Propio' AS VARIABLE, 0.37559 AS M1, 0.76779 AS M2, 0.23221 AS M3 UNION
                   SELECT 8 AS ORD, 'Share Mercado' AS VARIABLE, 0.00000 AS M1, 0.44815 AS M2, 0.24462 AS M3 UNION
                   SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 363891 AS M1, 84423 AS M2, 279468 AS M3 UNION
                   SELECT 10 AS ORD, 'Share Propio' AS VARIABLE, 0.08900 AS M1, 0.23200 AS M2, 0.76800 AS M3 UNION
                   SELECT 11 AS ORD, 'Share Mercado' AS VARIABLE, 0.00000 AS M1, 0.03209 AS M2, 0.19171 AS M3) TMP
             ORDER BY ORD";
    $body_style = array(
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1")
                  );
              
    $foot = "SELECT VARIABLE, M1, M2, M3
              FROM (SELECT 12 AS ORD, 'Mercado' AS VARIABLE, 4088623 AS M1, 2630889 AS M2, 1457734 AS M3 UNION
                    SELECT 13 AS ORD, 'Share I.' AS VARIABLE, 0.00000 AS M1, 0.64347 AS M2, 0.35653 AS M3 UNION
                    SELECT 14 AS ORD, 'Average' AS VARIABLE, 1241577.33333333 AS M1, 848822 AS M2, 392755.333333333 AS M3) TMP
              ORDER BY ORD";
    $foot_style = array(
                      array("text", "comma", "comma", "comma"),
                      array("text", "percent:1", "percent:1", "percent:1"),
                      array("text", "comma", "comma", "comma")
                  );
                  
    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
            ));
}

function get_trafico_mes_Busquedas_acumulado($user_id, $tipo) {
    if ($tipo == "Inorganico") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 577756 AS value UNION
                        SELECT 3 AS ORD, 'Fravega' AS label, 789667 AS value UNION
                        SELECT 6 AS ORD, 'Garbarino' AS label, 1179043 AS value UNION
                        SELECT 9 AS ORD, 'Avenida' AS label, 84423 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
    else if ($tipo == "Organico") {
        $query = "SELECT label, value
                  FROM (SELECT 0 AS ORD, 'Musimundo' AS label, 234629 AS value UNION
                        SELECT 3 AS ORD, 'Fravega' AS label, 587040 AS value UNION
                        SELECT 6 AS ORD, 'Garbarino' AS label, 356597 AS value UNION
                        SELECT 9 AS ORD, 'Avenida' AS label, 279468 AS value) TMP
                  ORDER BY ORD";
        to_json(table_simple($query));
    }
}

function get_trafico_mes_Busquedas_tendencia($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.711184967718508 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.288815032281492 AS value) TMP
               ORDER BY ORD";

	$query2 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.573591185342996 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.426408814657004 AS value) TMP
               ORDER BY ORD";

	$query3 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.767786069651741 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.232213930348259 AS value) TMP
               ORDER BY ORD";

	$query4 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.23200079144579 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.76799920855421 AS value) TMP
               ORDER BY ORD";

	$query5 = "SELECT label, value
               FROM (SELECT 0 AS ORD, 'Orgánico' AS label, 0.643465782978768 AS value UNION
                     SELECT 1 AS ORD, 'Inorgánico' AS label, 0.356534217021232 AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array("key"=>"Musimundo", "values"=>table_simple($query1)),
                array("key"=>"Fravega", "values"=>table_simple($query2)),
                array("key"=>"Garbarino", "values"=>table_simple($query3)),
                array("key"=>"Avenida", "values"=>table_simple($query4)),
                array("key"=>"Mercado", "values"=>table_simple($query5))
            ));
}


function get_trafico_tipo_share($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.23499 AS M201505, 0.11455 AS M201507, 0.11335 AS M201509, 0.23393 AS M201511, 0.07698 AS M201601, 0.08230 AS M201603, 0.14928 AS M201605 UNION
                       SELECT 1 AS ORD, 'Tráfico Total' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461.25126826 AS M201511, 2222914 AS M201601, 1512917.03979715 AS M201603, 2460873 AS M201605 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 0.23979 AS M201505, 0.13038 AS M201507, 0.10759 AS M201509, 0.24948 AS M201511, 0.08153 AS M201601, 0.07633 AS M201603, 0.13253 AS M201605 UNION
                       SELECT 3 AS ORD, 'Tráfico Total' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667.3363056 AS M201511, 3204757 AS M201601, 2607042.52390773 AS M201603, 4163589 AS M201605 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 0.25698 AS M201505, 0.15609 AS M201507, 0.20790 AS M201509, 0.25692 AS M201511, 0.08040 AS M201601, 0.06198 AS M201603, 0.10400 AS M201605 UNION
                       SELECT 5 AS ORD, 'Tráfico Total' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578.53327326 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 0.27401 AS M201505, 0.33084 AS M201507, 0.34678 AS M201509, 0.40586 AS M201511, 0.15923 AS M201601, 0.12913 AS M201603, 0.19646 AS M201605 UNION
                       SELECT 7 AS ORD, 'Tráfico Total' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572.88154242 AS M201511, 840917 AS M201601, 1206563.17599784 AS M201603, 1582283 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Totales") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.38002 AS M201505, 0.49232 AS M201507, 0.53730 AS M201509, 0.44469 AS M201511, 0.38097 AS M201601, 0.39026 AS M201603, 0.33012 AS M201605 UNION
                       SELECT 1 AS ORD, 'Tráfico Total' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461.25126826 AS M201511, 2222914 AS M201601, 1512917.03979715 AS M201603, 2460873 AS M201605 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 0.31879 AS M201505, 0.41367 AS M201507, 0.49597 AS M201509, 0.41359 AS M201511, 0.33501 AS M201601, 0.32544 AS M201603, 0.33065 AS M201605 UNION
                       SELECT 3 AS ORD, 'Tráfico Total' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667.3363056 AS M201511, 3204757 AS M201601, 2607042.52390773 AS M201603, 4163589 AS M201605 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 0.35606 AS M201505, 0.43791 AS M201507, 0.46179 AS M201509, 0.41844 AS M201511, 0.36599 AS M201601, 0.23684 AS M201603, 0.20956 AS M201605 UNION
                       SELECT 5 AS ORD, 'Tráfico Total' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578.53327326 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 0.09922 AS M201505, 0.10549 AS M201507, 0.13468 AS M201509, 0.13187 AS M201511, 0.14700 AS M201601, 0.21068 AS M201603, 0.22998 AS M201605 UNION
                       SELECT 7 AS ORD, 'Tráfico Total' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572.88154242 AS M201511, 840917 AS M201601, 1206563.17599784 AS M201603, 1582283 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Organicas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.31045 AS M201505, 0.37064 AS M201507, 0.37107 AS M201509, 0.31591 AS M201511, 0.27294 AS M201601, 0.27001 AS M201603, 0.23478 AS M201605 UNION
                       SELECT 1 AS ORD, 'Tráfico Total' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461.25126826 AS M201511, 2222914 AS M201601, 1512917.03979715 AS M201603, 2460873 AS M201605 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 0.23504 AS M201505, 0.27504 AS M201507, 0.29718 AS M201509, 0.27297 AS M201511, 0.21692 AS M201601, 0.19633 AS M201603, 0.18966 AS M201605 UNION
                       SELECT 3 AS ORD, 'Tráfico Total' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667.3363056 AS M201511, 3204757 AS M201601, 2607042.52390773 AS M201603, 4163589 AS M201605 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 0.30824 AS M201505, 0.33472 AS M201507, 0.35893 AS M201509, 0.31676 AS M201511, 0.23306 AS M201601, 0.15388 AS M201603, 0.16090 AS M201605 UNION
                       SELECT 5 AS ORD, 'Tráfico Total' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578.53327326 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 0.04908 AS M201505, 0.04709 AS M201507, 0.05897 AS M201509, 0.06356 AS M201511, 0.05813 AS M201601, 0.05431 AS M201603, 0.05336 AS M201605 UNION
                       SELECT 7 AS ORD, 'Tráfico Total' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572.88154242 AS M201511, 840917 AS M201601, 1206563.17599784 AS M201603, 1582283 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Inorganicas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.06957 AS M201505, 0.12168 AS M201507, 0.16623 AS M201509, 0.12878 AS M201511, 0.10803 AS M201601, 0.12025 AS M201603, 0.09534 AS M201605 UNION
                       SELECT 1 AS ORD, 'Tráfico Total' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461.25126826 AS M201511, 2222914 AS M201601, 1512917.03979715 AS M201603, 2460873 AS M201605 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 0.08375 AS M201505, 0.13863 AS M201507, 0.19879 AS M201509, 0.14062 AS M201511, 0.11809 AS M201601, 0.12912 AS M201603, 0.14099 AS M201605 UNION
                       SELECT 3 AS ORD, 'Tráfico Total' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667.3363056 AS M201511, 3204757 AS M201601, 2607042.52390773 AS M201603, 4163589 AS M201605 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 0.04781 AS M201505, 0.10319 AS M201507, 0.10285 AS M201509, 0.10168 AS M201511, 0.13293 AS M201601, 0.08296 AS M201603, 0.04866 AS M201605 UNION
                       SELECT 5 AS ORD, 'Tráfico Total' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578.53327326 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 0.05013 AS M201505, 0.05841 AS M201507, 0.07571 AS M201509, 0.06831 AS M201511, 0.08887 AS M201601, 0.15636 AS M201603, 0.17662 AS M201605 UNION
                       SELECT 7 AS ORD, 'Tráfico Total' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572.88154242 AS M201511, 840917 AS M201601, 1206563.17599784 AS M201603, 1582283 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Redes_Sociales") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.01565 AS M201505, 0.01465 AS M201507, 0.02194 AS M201509, 0.02573 AS M201511, 0.01628 AS M201601, 0.01246 AS M201603, 0.00767 AS M201605 UNION
                       SELECT 1 AS ORD, 'Tráfico Total' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461.25126826 AS M201511, 2222914 AS M201601, 1512917.03979715 AS M201603, 2460873 AS M201605 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 0.06113 AS M201505, 0.07744 AS M201507, 0.08414 AS M201509, 0.07303 AS M201511, 0.06554 AS M201601, 0.05384 AS M201603, 0.04143 AS M201605 UNION
                       SELECT 3 AS ORD, 'Tráfico Total' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667.3363056 AS M201511, 3204757 AS M201601, 2607042.52390773 AS M201603, 4163589 AS M201605 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 0.02968 AS M201505, 0.06688 AS M201507, 0.09288 AS M201509, 0.05655 AS M201511, 0.03779 AS M201601, 0.02674 AS M201603, 0.01742 AS M201605 UNION
                       SELECT 5 AS ORD, 'Tráfico Total' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578.53327326 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 0.23158 AS M201505, 0.12225 AS M201507, 0.14089 AS M201509, 0.07641 AS M201511, 0.04408 AS M201601, 0.04234 AS M201603, 0.02549 AS M201605 UNION
                       SELECT 7 AS ORD, 'Tráfico Total' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572.88154242 AS M201511, 840917 AS M201601, 1206563.17599784 AS M201603, 1582283 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Displays") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.09241 AS M201505, 0.07089 AS M201507, 0.01209 AS M201509, 0.00288 AS M201511, 0.00721 AS M201601, 0.00535 AS M201603, 0.01524 AS M201605 UNION
                       SELECT 1 AS ORD, 'Tráfico Total' AS VARIABLE, 1749516 AS M201505, 1096317 AS M201507, 1275512 AS M201509, 2249461.25126826 AS M201511, 2222914 AS M201601, 1512917.03979715 AS M201603, 2460873 AS M201605 UNION
                       SELECT 2 AS ORD, 'Fravega' AS VARIABLE, 0.09264 AS M201505, 0.06444 AS M201507, 0.00413 AS M201509, 0.00251 AS M201511, 0.00527 AS M201601, 0.00345 AS M201603, 0.01711 AS M201605 UNION
                       SELECT 3 AS ORD, 'Tráfico Total' AS VARIABLE, 2469657 AS M201505, 1684924 AS M201507, 1819085 AS M201509, 3263667.3363056 AS M201511, 3204757 AS M201601, 2607042.52390773 AS M201603, 4163589 AS M201605 UNION
                       SELECT 4 AS ORD, 'Garbarino' AS VARIABLE, 0.05049 AS M201505, 0.05382 AS M201507, 0.00566 AS M201509, 0.00391 AS M201511, 0.00254 AS M201601, 0.00360 AS M201603, 0.00718 AS M201605 UNION
                       SELECT 5 AS ORD, 'Tráfico Total' AS VARIABLE, 2547203 AS M201505, 1972198 AS M201507, 2103236 AS M201509, 3925578.53327326 AS M201511, 3727073 AS M201601, 4740255 AS M201603, 7328022 AS M201605 UNION
                       SELECT 6 AS ORD, 'Avenida' AS VARIABLE, 0.05200 AS M201505, 0.02342 AS M201507, 0.01459 AS M201509, 0.04139 AS M201511, 0.02378 AS M201601, 0.02139 AS M201603, 0.02511 AS M201605 UNION
                       SELECT 7 AS ORD, 'Tráfico Total' AS VARIABLE, 1151503 AS M201505, 671737 AS M201507, 1104032 AS M201509, 1179572.88154242 AS M201511, 840917 AS M201601, 1206563.17599784 AS M201603, 1582283 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold", "percent:1+bold"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
}

function get_trafico_tipo_indicador($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $head = array("Variable", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text");

        $body = "SELECT Competidor, M1, M2, M3, M4, M5, M6
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'RED' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'GREEN' AS M6 UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'GREEN' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'RED' AS M6) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Totales") {
        $head = array("Variable", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text");

        $body = "SELECT Competidor, M1, M2, M3, M4, M5, M6
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'RED' AS M6 UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'RED' AS M6 UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'RED' AS M6) TMP
                 ORDER BY ORD";                 
        $body_style = array("text", "icon", "icon", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Organicas") {
        $head = array("Variable", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text");

        $body = "SELECT Competidor, M1, M2, M3, M4, M5, M6
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS M1, 'RED' AS M2, 'RED' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'RED' AS M6 UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'GREEN' AS M6 UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'RED' AS M6) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Inorganicas") {
        $head = array("Variable", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text");

        $body = "SELECT Competidor, M1, M2, M3, M4, M5, M6
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'RED' AS M5, 'RED' AS M6 UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'RED' AS M6 UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'GREEN' AS M6) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Redes_Sociales") {
        $head = array("Variable", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text");

        $body = "SELECT Competidor, M1, M2, M3, M4, M5, M6
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'GREEN' AS M3, 'RED' AS M4, 'RED' AS M5, 'RED' AS M6 UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'GREEN' AS M1, 'RED' AS M2, 'GREEN' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'RED' AS M6 UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'RED' AS M6) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Displays") {
        $head = array("Variable", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text");

        $body = "SELECT Competidor, M1, M2, M3, M4, M5, M6
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'RED' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                       SELECT 1 AS ORD, 'Fravega' AS Competidor, 'RED' AS M1, 'RED' AS M2, 'RED' AS M3, 'GREEN' AS M4, 'RED' AS M5, 'GREEN' AS M6 UNION
                       SELECT 2 AS ORD, 'Garbarino' AS Competidor, 'GREEN' AS M1, 'RED' AS M2, 'RED' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'RED' AS M6 UNION
                       SELECT 3 AS ORD, 'Avenida' AS Competidor, 'RED' AS M1, 'GREEN' AS M2, 'GREEN' AS M3, 'RED' AS M4, 'GREEN' AS M5, 'RED' AS M6) TMP
                 ORDER BY ORD";
        $body_style = array("text", "icon", "icon", "icon", "icon", "icon", "icon");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
}

function get_trafico_tipo_variacion($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 411118 AS M201505, 125585 AS M201507, 144580 AS M201509, 526224 AS M201511, 171120 AS M201601, 124518 AS M201603, 367357 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.20833 AS M201505, 0.14347 AS M201507, 0.12459 AS M201509, 0.18609 AS M201511, 0.19761 AS M201601, 0.16105 AS M201603, 0.18441 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.69453 AS M201507, 0.15125 AS M201509, 2.63967 AS M201511, -0.67482 AS M201601, -0.27234 AS M201603, 1.95023 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 592209 AS M201505, 219673 AS M201507, 195707 AS M201509, 814212 AS M201511, 261293 AS M201601, 199005 AS M201603, 551789 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.30009 AS M201505, 0.25096 AS M201507, 0.16865 AS M201509, 0.28794 AS M201511, 0.30173 AS M201601, 0.25740 AS M201603, 0.27699 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.62906 AS M201507, -0.10910 AS M201509, 3.16036 AS M201511, -0.67908 AS M201601, -0.23838 AS M201603, 1.77274 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 654587 AS M201505, 307848 AS M201507, 437273 AS M201509, 1008551 AS M201511, 299655 AS M201601, 293809 AS M201603, 762089 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.33170 AS M201505, 0.35169 AS M201507, 0.37683 AS M201509, 0.35667 AS M201511, 0.34603 AS M201601, 0.38002 AS M201603, 0.38256 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.52971 AS M201507, 0.42042 AS M201509, 1.30646 AS M201511, -0.70289 AS M201601, -0.01951 AS M201603, 1.59382 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 315529 AS M201505, 222238 AS M201507, 382852 AS M201509, 478738 AS M201511, 133901 AS M201601, 155809 AS M201603, 310863 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.15989 AS M201505, 0.25389 AS M201507, 0.32993 AS M201509, 0.16930 AS M201511, 0.15463 AS M201601, 0.20153 AS M201603, 0.15605 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.29567 AS M201507, 0.72271 AS M201509, 0.25045 AS M201511, -0.72030 AS M201601, 0.16361 AS M201603, 0.99515 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );

        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 1973443 AS M201505, 875344 AS M201507, 1160412 AS M201509, 2827725 AS M201511, 865969 AS M201601, 773141 AS M201603, 1992098 AS M201605 UNION
                        SELECT 13 AS ORD, 'Share I.' AS VARIABLE, 0.24924 AS M201505, 0.16135 AS M201507, 0.18414 AS M201509, 0.26631 AS M201511, 0.08663 AS M201601, 0.07680 AS M201603, 0.12823 AS M201605 UNION
                        SELECT 14 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.55644 AS M201507, 0.32566 AS M201509, 1.43683 AS M201511, -0.69376 AS M201601, -0.10720 AS M201603, 1.57663 AS M201605 UNION
                        SELECT 15 AS ORD, 'Average' AS VARIABLE, 493360.75 AS M201505, 218836 AS M201507, 290103 AS M201509, 706931.25 AS M201511, 216492.25 AS M201601, 193285.25 AS M201603, 498024.5 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Busquedas_Totales") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 664853 AS M201505, 539738 AS M201507, 685328 AS M201509, 1000312 AS M201511, 846856 AS M201601, 590435 AS M201603, 812385 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.26881 AS M201505, 0.24858 AS M201507, 0.25313 AS M201509, 0.24114 AS M201511, 0.24848 AS M201601, 0.20969 AS M201603, 0.19869 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.18818 AS M201507, 0.26974 AS M201509, 0.45961 AS M201511, -0.15341 AS M201601, -0.30279 AS M201603, 0.37591 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 787303 AS M201505, 696997 AS M201507, 902203 AS M201509, 1349817 AS M201511, 1073634 AS M201601, 848441 AS M201603, 1376707 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.31831 AS M201505, 0.32101 AS M201507, 0.33323 AS M201509, 0.32539 AS M201511, 0.31502 AS M201601, 0.30132 AS M201603, 0.33672 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.11470 AS M201507, 0.29441 AS M201509, 0.49613 AS M201511, -0.20461 AS M201601, -0.20975 AS M201603, 0.62263 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 906945 AS M201505, 863648 AS M201507, 971245 AS M201509, 1642600 AS M201511, 1364061 AS M201601, 1122694 AS M201603, 1535640 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.36669 AS M201505, 0.39777 AS M201507, 0.35873 AS M201509, 0.39597 AS M201511, 0.40023 AS M201601, 0.39872 AS M201603, 0.37559 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.04774 AS M201507, 0.12458 AS M201509, 0.69123 AS M201511, -0.16957 AS M201601, -0.17695 AS M201603, 0.36782 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 114249 AS M201505, 70864 AS M201507, 148690 AS M201509, 155553 AS M201511, 123613 AS M201601, 254193 AS M201603, 363891 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.04619 AS M201505, 0.03264 AS M201507, 0.05492 AS M201509, 0.03750 AS M201511, 0.03627 AS M201601, 0.09027 AS M201603, 0.08900 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.37974 AS M201507, 1.09824 AS M201509, 0.04616 AS M201511, -0.20533 AS M201601, 1.05636 AS M201603, 0.43155 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );

        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 2473350 AS M201505, 2171247 AS M201507, 2707466 AS M201509, 4148282 AS M201511, 3408164 AS M201601, 2815763 AS M201603, 4088623 AS M201605 UNION
                        SELECT 13 AS ORD, 'Share I.' AS VARIABLE, 0.31238 AS M201505, 0.40022 AS M201507, 0.42963 AS M201509, 0.39067 AS M201511, 0.34096 AS M201601, 0.27971 AS M201603, 0.26319 AS M201605 UNION
                        SELECT 14 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.12214 AS M201507, 0.24696 AS M201509, 0.53216 AS M201511, -0.17842 AS M201601, -0.17382 AS M201603, 0.45205 AS M201605 UNION
                        SELECT 15 AS ORD, 'Average' AS VARIABLE, 618337.5 AS M201505, 542811.75 AS M201507, 676866.5 AS M201509, 1037070.5 AS M201511, 852041 AS M201601, 703940.75 AS M201603, 1022155.75 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Busquedas_Organicas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 543131 AS M201505, 406336 AS M201507, 473301 AS M201509, 710621.6448 AS M201511, 606712 AS M201601, 408507 AS M201603, 577756 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.27636 AS M201505, 0.26022 AS M201507, 0.25808 AS M201509, 0.24337 AS M201511, 0.27337 AS M201601, 0.23815 AS M201603, 0.21960 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.25186 AS M201507, 0.16480 AS M201509, 0.50142 AS M201511, -0.14622 AS M201601, -0.32669 AS M201603, 0.41431 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 580466 AS M201505, 463423 AS M201507, 540595 AS M201509, 890879.22 AS M201511, 695170 AS M201601, 511830 AS M201603, 789667 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.29536 AS M201505, 0.29678 AS M201507, 0.29478 AS M201509, 0.30510 AS M201511, 0.31323 AS M201601, 0.29839 AS M201603, 0.30015 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.20164 AS M201507, 0.16653 AS M201509, 0.64796 AS M201511, -0.21968 AS M201601, -0.26373 AS M201603, 0.54283 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 785154 AS M201505, 660132 AS M201507, 754917 AS M201509, 1243448.2 AS M201511, 868624 AS M201601, 729442 AS M201603, 1179043 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.39951 AS M201505, 0.42275 AS M201507, 0.41164 AS M201509, 0.42585 AS M201511, 0.39138 AS M201601, 0.42525 AS M201603, 0.44815 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.15923 AS M201507, 0.14358 AS M201509, 0.64713 AS M201511, -0.30144 AS M201601, -0.16023 AS M201603, 0.61636 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 56519 AS M201505, 31630 AS M201507, 65104 AS M201509, 74976.546 AS M201511, 48879 AS M201601, 65529 AS M201603, 84423 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.02876 AS M201505, 0.02026 AS M201507, 0.03550 AS M201509, 0.02568 AS M201511, 0.02202 AS M201601, 0.03820 AS M201603, 0.03209 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.44037 AS M201507, 1.05830 AS M201509, 0.15164 AS M201511, -0.34808 AS M201601, 0.34064 AS M201603, 0.28833 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );

        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 1965270 AS M201505, 1561521 AS M201507, 1833917 AS M201509, 2919925.6108 AS M201511, 2219385 AS M201601, 1715308 AS M201603, 2630889 AS M201605 UNION
                        SELECT 13 AS ORD, 'Share I.' AS VARIABLE, 0.24821 AS M201505, 0.28783 AS M201507, 0.29101 AS M201509, 0.27499 AS M201511, 0.22203 AS M201601, 0.17039 AS M201603, 0.16935 AS M201605 UNION
                        SELECT 14 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.20544 AS M201507, 0.17444 AS M201509, 0.59218 AS M201511, -0.23992 AS M201601, -0.22712 AS M201603, 0.53377 AS M201605 UNION
                        SELECT 15 AS ORD, 'Average' AS VARIABLE, 491317.5 AS M201505, 390380.25 AS M201507, 458479.25 AS M201509, 729981.4027 AS M201511, 554846.25 AS M201601, 428827 AS M201603, 657722.25 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Busquedas_Inorganicas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 121722 AS M201505, 133402 AS M201507, 212027 AS M201509, 289690.3552 AS M201511, 240144 AS M201601, 181928 AS M201603, 234629 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.23957 AS M201505, 0.21879 AS M201507, 0.24272 AS M201509, 0.23584 AS M201511, 0.20201 AS M201601, 0.16532 AS M201603, 0.16095 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.09596 AS M201507, 0.58938 AS M201509, 0.36629 AS M201511, -0.17103 AS M201601, -0.24242 AS M201603, 0.28968 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 206837 AS M201505, 233574 AS M201507, 361608 AS M201509, 458937.78 AS M201511, 378464 AS M201601, 336611 AS M201603, 587040 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.40710 AS M201505, 0.38308 AS M201507, 0.41395 AS M201509, 0.37362 AS M201511, 0.31836 AS M201601, 0.30588 AS M201603, 0.40271 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.12927 AS M201507, 0.54815 AS M201509, 0.26916 AS M201511, -0.17535 AS M201601, -0.11059 AS M201603, 0.74397 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 121791 AS M201505, 203516 AS M201507, 216328 AS M201509, 399151.8 AS M201511, 495437 AS M201601, 393252 AS M201603, 356597 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.23971 AS M201505, 0.33378 AS M201507, 0.24764 AS M201509, 0.32495 AS M201511, 0.41676 AS M201601, 0.35735 AS M201603, 0.24462 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.67103 AS M201507, 0.06295 AS M201509, 0.84512 AS M201511, 0.24122 AS M201601, -0.20625 AS M201603, -0.09321 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 57730 AS M201505, 39234 AS M201507, 83586 AS M201509, 80576.454 AS M201511, 74734 AS M201601, 188664 AS M201603, 279468 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.11362 AS M201505, 0.06435 AS M201507, 0.09569 AS M201509, 0.06560 AS M201511, 0.06287 AS M201601, 0.17144 AS M201603, 0.19171 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.32039 AS M201507, 1.13045 AS M201509, -0.03601 AS M201511, -0.07251 AS M201601, 1.52447 AS M201603, 0.48130 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );

        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 508080 AS M201505, 609726 AS M201507, 873549 AS M201509, 1228356.3892 AS M201511, 1188779 AS M201601, 1100455 AS M201603, 1457734 AS M201605 UNION
                        SELECT 13 AS ORD, 'Share I.' AS VARIABLE, 0.06417 AS M201505, 0.11239 AS M201507, 0.13862 AS M201509, 0.11568 AS M201511, 0.11893 AS M201601, 0.10932 AS M201603, 0.09384 AS M201605 UNION
                        SELECT 14 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.20006 AS M201507, 0.43269 AS M201509, 0.40617 AS M201511, -0.03222 AS M201601, -0.07430 AS M201603, 0.32466 AS M201605 UNION
                        SELECT 15 AS ORD, 'Average' AS VARIABLE, 127020 AS M201505, 152431.5 AS M201507, 218387.25 AS M201509, 307089.0973 AS M201511, 297194.75 AS M201601, 275113.75 AS M201603, 364433.5 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Redes_Sociales") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 27373 AS M201505, 16062 AS M201507, 27984 AS M201509, 57875 AS M201511, 36192 AS M201601, 18852 AS M201603, 18884 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.05258 AS M201505, 0.04455 AS M201507, 0.05261 AS M201509, 0.09514 AS M201511, 0.08532 AS M201601, 0.05593 AS M201603, 0.05255 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.41322 AS M201507, 0.74225 AS M201509, 1.06815 AS M201511, -0.37465 AS M201601, -0.47911 AS M201603, 0.00170 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 150964 AS M201505, 130478 AS M201507, 153050 AS M201509, 238333 AS M201511, 210054 AS M201601, 140362 AS M201603, 172494 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.28998 AS M201505, 0.36186 AS M201507, 0.28773 AS M201509, 0.39178 AS M201511, 0.49521 AS M201601, 0.41641 AS M201603, 0.47998 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.13570 AS M201507, 0.17299 AS M201509, 0.55722 AS M201511, -0.11865 AS M201601, -0.33178 AS M201603, 0.22892 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 75601 AS M201505, 131909 AS M201507, 195339 AS M201509, 221988 AS M201511, 140853 AS M201601, 126774 AS M201603, 127668 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.14522 AS M201505, 0.36583 AS M201507, 0.36723 AS M201509, 0.36491 AS M201511, 0.33207 AS M201601, 0.37610 AS M201603, 0.35525 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, 0.74480 AS M201507, 0.48086 AS M201509, 0.13642 AS M201511, -0.36549 AS M201601, -0.09996 AS M201603, 0.00705 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 266662 AS M201505, 82122 AS M201507, 155547 AS M201509, 90137 AS M201511, 37069 AS M201601, 51086 AS M201603, 40330 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.51222 AS M201505, 0.22776 AS M201507, 0.29243 AS M201509, 0.14817 AS M201511, 0.08739 AS M201601, 0.15156 AS M201603, 0.11222 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.69204 AS M201507, 0.89410 AS M201509, -0.42052 AS M201511, -0.58875 AS M201601, 0.37813 AS M201603, -0.21055 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );

        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 520600 AS M201505, 360571 AS M201507, 531920 AS M201509, 608333 AS M201511, 424168 AS M201601, 337074 AS M201603, 359376 AS M201605 UNION
                        SELECT 13 AS ORD, 'Share I.' AS VARIABLE, 0.06575 AS M201505, 0.06646 AS M201507, 0.08441 AS M201509, 0.05729 AS M201511, 0.04244 AS M201601, 0.03348 AS M201603, 0.02313 AS M201605 UNION
                        SELECT 14 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.30739 AS M201507, 0.47522 AS M201509, 0.14366 AS M201511, -0.30274 AS M201601, -0.20533 AS M201603, 0.06616 AS M201605 UNION
                        SELECT 15 AS ORD, 'Average' AS VARIABLE, 130150 AS M201505, 90142.75 AS M201507, 132980 AS M201509, 152083.25 AS M201511, 106042 AS M201601, 84268.5 AS M201603, 89844 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
    else if ($tipo == "Displays") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 161678 AS M201505, 77719 AS M201507, 15425 AS M201509, 6474 AS M201511, 16032 AS M201601, 8101 AS M201603, 37509 AS M201605 UNION
                       SELECT 1 AS ORD, 'Share' AS VARIABLE, 0.27926 AS M201505, 0.25220 AS M201507, 0.30273 AS M201509, 0.08211 AS M201511, 0.25703 AS M201601, 0.13511 AS M201603, 0.18650 AS M201605 UNION
                       SELECT 2 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.51930 AS M201507, -0.80153 AS M201509, -0.58029 AS M201511, 1.47637 AS M201601, -0.49470 AS M201603, 3.63017 AS M201605 UNION
                       SELECT 3 AS ORD, 'Fravega' AS VARIABLE, 228778 AS M201505, 108572 AS M201507, 7512 AS M201509, 8185 AS M201511, 16876 AS M201601, 8995 AS M201603, 71249 AS M201605 UNION
                       SELECT 4 AS ORD, 'Share' AS VARIABLE, 0.39516 AS M201505, 0.35231 AS M201507, 0.14743 AS M201509, 0.10381 AS M201511, 0.27056 AS M201601, 0.15002 AS M201603, 0.35425 AS M201605 UNION
                       SELECT 5 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.52543 AS M201507, -0.93081 AS M201509, 0.08959 AS M201511, 1.06182 AS M201601, -0.46699 AS M201603, 6.92096 AS M201605 UNION
                       SELECT 6 AS ORD, 'Garbarino' AS VARIABLE, 128612 AS M201505, 106145 AS M201507, 11909 AS M201509, 15364 AS M201511, 9470 AS M201601, 17059 AS M201603, 52637 AS M201605 UNION
                       SELECT 7 AS ORD, 'Share' AS VARIABLE, 0.22215 AS M201505, 0.34444 AS M201507, 0.23373 AS M201509, 0.19486 AS M201511, 0.15182 AS M201601, 0.28452 AS M201603, 0.26171 AS M201605 UNION
                       SELECT 8 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.17469 AS M201507, -0.88780 AS M201509, 0.29012 AS M201511, -0.38362 AS M201601, 0.80137 AS M201603, 2.08559 AS M201605 UNION
                       SELECT 9 AS ORD, 'Avenida' AS VARIABLE, 59878 AS M201505, 15732 AS M201507, 16107 AS M201509, 48823 AS M201511, 19997 AS M201601, 25803 AS M201603, 39731 AS M201605 UNION
                       SELECT 10 AS ORD, 'Share' AS VARIABLE, 0.10343 AS M201505, 0.05105 AS M201507, 0.31611 AS M201509, 0.61922 AS M201511, 0.32059 AS M201601, 0.43035 AS M201603, 0.19754 AS M201605 UNION
                       SELECT 11 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.73727 AS M201507, 0.02384 AS M201509, 2.03117 AS M201511, -0.59042 AS M201601, 0.29034 AS M201603, 0.53978 AS M201605) TMP
                 ORDER BY ORD";
        $body_style = array(
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1")
                      );

        $foot = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605
                  FROM (SELECT 12 AS ORD, 'Total' AS VARIABLE, 578946 AS M201505, 308168 AS M201507, 50953 AS M201509, 78846 AS M201511, 62375 AS M201601, 59958 AS M201603, 201126 AS M201605 UNION
                        SELECT 13 AS ORD, 'Share I.' AS VARIABLE, 0.07312 AS M201505, 0.05680 AS M201507, 0.00809 AS M201509, 0.00743 AS M201511, 0.00624 AS M201601, 0.00596 AS M201603, 0.01295 AS M201605 UNION
                        SELECT 14 AS ORD, 'Var. M' AS VARIABLE, 0.00000 AS M201505, -0.46771 AS M201507, -0.83466 AS M201509, 0.54743 AS M201511, -0.20890 AS M201601, -0.03875 AS M201603, 2.35445 AS M201605 UNION
                        SELECT 15 AS ORD, 'Average' AS VARIABLE, 144736.5 AS M201505, 77042 AS M201507, 12738.25 AS M201509, 19711.5 AS M201511, 15593.75 AS M201601, 14989.5 AS M201603, 50281.5 AS M201605) TMP
                  ORDER BY ORD";
        $foot_style = array(
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1"),
                          array("text", "comma", "comma", "comma", "comma", "comma", "comma", "comma")
                      );
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                    array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
                ));
    }
}

function get_trafico_tipo_tendencia($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 411118 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 125585 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 144580 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 526224 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 171120 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 124518 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 367357 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 592209 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 219673 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 195707 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 814212 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 261293 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 199005 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 551789 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 654587 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 307848 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 437273 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1008551 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 299655 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 293809 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 762089 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 315529 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 222238 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 382852 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 478738 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 133901 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 155809 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 310863 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Totales") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 664853 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 539738 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 685328 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1000312 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 846856 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 590435 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 812385 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 787303 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 696997 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 902203 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1349817 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 1073634 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 848441 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1376707 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 906945 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 863648 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 971245 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1642600 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 1364061 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 1122694 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1535640 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 114249 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 70864 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 148690 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 155553 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 123613 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 254193 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 363891 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Organicas") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 543131 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 406336 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 473301 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 710621.6448 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 606712 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 408507 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 577756 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 580466 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 463423 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 540595 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 890879.22 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 695170 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 511830 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 789667 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 785154 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 660132 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 754917 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 1243448.2 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 868624 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 729442 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 1179043 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 56519 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 31630 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 65104 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 74976.546 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 48879 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 65529 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 84423 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Inorganicas") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 121722 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 133402 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 212027 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 289690.3552 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 240144 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 181928 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 234629 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 206837 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 233574 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 361608 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 458937.78 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 378464 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 336611 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 587040 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 121791 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 203516 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 216328 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 399151.8 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 495437 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 393252 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 356597 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 57730 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 39234 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 83586 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 80576.454 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 74734 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 188664 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 279468 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Redes_Sociales") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 27373 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 16062 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 27984 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 57875 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 36192 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 18852 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 18884 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 150964 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 130478 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 153050 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 238333 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 210054 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 140362 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 172494 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 75601 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 131909 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 195339 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 221988 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 140853 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 126774 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 127668 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 266662 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 82122 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 155547 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 90137 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 37069 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 51086 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 40330 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Displays") {
        $query1 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 161678 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 77719 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 15425 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 6474 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 16032 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 8101 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 37509 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 228778 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 108572 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 7512 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 8185 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 16876 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 8995 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 71249 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 128612 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 106145 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 11909 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 15364 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 9470 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 17059 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 52637 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 1 AS ORD, '2015-05-01' AS label, 59878 AS value UNION
                         SELECT 2 AS ORD, '2015-07-01' AS label, 15732 AS value UNION
                         SELECT 3 AS ORD, '2015-09-01' AS label, 16107 AS value UNION
                         SELECT 4 AS ORD, '2015-11-01' AS label, 48823 AS value UNION
                         SELECT 5 AS ORD, '2016-01-01' AS label, 19997 AS value UNION
                         SELECT 6 AS ORD, '2016-03-01' AS label, 25803 AS value UNION
                         SELECT 7 AS ORD, '2016-05-01' AS label, 39731 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
}


function get_share_trafico_tipo_share_mes_tabla($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.20833 AS M201505, 0.14347 AS M201507, 0.12459 AS M201509, 0.18609 AS M201511, 0.19761 AS M201601, 0.16105 AS M201603, 0.18441 AS M201605, 0.17222 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.30009 AS M201505, 0.25096 AS M201507, 0.16865 AS M201509, 0.28794 AS M201511, 0.30173 AS M201601, 0.25740 AS M201603, 0.27699 AS M201605, 0.26339 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.33170 AS M201505, 0.35169 AS M201507, 0.37683 AS M201509, 0.35667 AS M201511, 0.34603 AS M201601, 0.38002 AS M201603, 0.38256 AS M201605, 0.36078 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.15989 AS M201505, 0.25389 AS M201507, 0.32993 AS M201509, 0.16930 AS M201511, 0.15463 AS M201601, 0.20153 AS M201603, 0.15605 AS M201605, 0.20360 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Totales") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.26881 AS M201505, 0.24858 AS M201507, 0.25313 AS M201509, 0.24114 AS M201511, 0.24848 AS M201601, 0.20969 AS M201603, 0.19869 AS M201605, 0.23836 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.31831 AS M201505, 0.32101 AS M201507, 0.33323 AS M201509, 0.32539 AS M201511, 0.31502 AS M201601, 0.30132 AS M201603, 0.33672 AS M201605, 0.32157 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.36669 AS M201505, 0.39777 AS M201507, 0.35873 AS M201509, 0.39597 AS M201511, 0.40023 AS M201601, 0.39872 AS M201603, 0.37559 AS M201605, 0.38481 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.04619 AS M201505, 0.03264 AS M201507, 0.05492 AS M201509, 0.03750 AS M201511, 0.03627 AS M201601, 0.09027 AS M201603, 0.08900 AS M201605, 0.05526 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Organicas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.27636 AS M201505, 0.26022 AS M201507, 0.25808 AS M201509, 0.24337 AS M201511, 0.27337 AS M201601, 0.23815 AS M201603, 0.21960 AS M201605, 0.25274 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.29536 AS M201505, 0.29678 AS M201507, 0.29478 AS M201509, 0.30510 AS M201511, 0.31323 AS M201601, 0.29839 AS M201603, 0.30015 AS M201605, 0.30054 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.39951 AS M201505, 0.42275 AS M201507, 0.41164 AS M201509, 0.42585 AS M201511, 0.39138 AS M201601, 0.42525 AS M201603, 0.44815 AS M201605, 0.41779 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.02876 AS M201505, 0.02026 AS M201507, 0.03550 AS M201509, 0.02568 AS M201511, 0.02202 AS M201601, 0.03820 AS M201603, 0.03209 AS M201605, 0.02893 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Inorganicas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.23957 AS M201505, 0.21879 AS M201507, 0.24272 AS M201509, 0.23584 AS M201511, 0.20201 AS M201601, 0.16532 AS M201603, 0.16095 AS M201605, 0.20931 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.40710 AS M201505, 0.38308 AS M201507, 0.41395 AS M201509, 0.37362 AS M201511, 0.31836 AS M201601, 0.30588 AS M201603, 0.40271 AS M201605, 0.37210 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.23971 AS M201505, 0.33378 AS M201507, 0.24764 AS M201509, 0.32495 AS M201511, 0.41676 AS M201601, 0.35735 AS M201603, 0.24462 AS M201605, 0.30926 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.11362 AS M201505, 0.06435 AS M201507, 0.09569 AS M201509, 0.06560 AS M201511, 0.06287 AS M201601, 0.17144 AS M201603, 0.19171 AS M201605, 0.10933 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Redes_Sociales") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.05258 AS M201505, 0.04455 AS M201507, 0.05261 AS M201509, 0.09514 AS M201511, 0.08532 AS M201601, 0.05593 AS M201603, 0.05255 AS M201605, 0.06267 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.28998 AS M201505, 0.36186 AS M201507, 0.28773 AS M201509, 0.39178 AS M201511, 0.49521 AS M201601, 0.41641 AS M201603, 0.47998 AS M201605, 0.38900 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.14522 AS M201505, 0.36583 AS M201507, 0.36723 AS M201509, 0.36491 AS M201511, 0.33207 AS M201601, 0.37610 AS M201603, 0.35525 AS M201605, 0.32952 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.51222 AS M201505, 0.22776 AS M201507, 0.29243 AS M201509, 0.14817 AS M201511, 0.08739 AS M201601, 0.15156 AS M201603, 0.11222 AS M201605, 0.21882 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Displays") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.27926 AS M201505, 0.25220 AS M201507, 0.30273 AS M201509, 0.08211 AS M201511, 0.25703 AS M201601, 0.13511 AS M201603, 0.18650 AS M201605, 0.21356 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.39516 AS M201505, 0.35231 AS M201507, 0.14743 AS M201509, 0.10381 AS M201511, 0.27056 AS M201601, 0.15002 AS M201603, 0.35425 AS M201605, 0.25336 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.22215 AS M201505, 0.34444 AS M201507, 0.23373 AS M201509, 0.19486 AS M201511, 0.15182 AS M201601, 0.28452 AS M201603, 0.26171 AS M201605, 0.24189 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.10343 AS M201505, 0.05105 AS M201507, 0.31611 AS M201509, 0.61922 AS M201511, 0.32059 AS M201601, 0.43035 AS M201603, 0.19754 AS M201605, 0.29119 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
}

function get_share_trafico_tipo_share_mes_grafico($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.20833 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.14347 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.12459 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.18609 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.19761 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.16105 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.18441 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.17222 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.30009 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.25096 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.16865 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.28794 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.30173 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.25740 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.27699 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.26339 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.33170 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.35169 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.37683 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.35667 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.34603 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.38002 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.38256 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.36078 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.15989 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.25389 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.32993 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.16930 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.15463 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.20153 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.15605 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.20360 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Totales") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.26881 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.24858 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.25313 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.24114 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.24848 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.20969 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.19869 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.23836 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.31831 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.32101 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.33323 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.32539 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.31502 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.30132 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.33672 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.32157 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.36669 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.39777 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.35873 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.39597 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.40023 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.39872 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.37559 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.38481 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.04619 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.03264 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.05492 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.03750 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.03627 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.09027 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.08900 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.05526 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Organicas") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.27636 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.26022 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.25808 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.24337 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.27337 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.23815 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.21960 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.25274 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.29536 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.29678 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.29478 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.30510 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.31323 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.29839 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.30015 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.30054 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.39951 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.42275 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.41164 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.42585 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.39138 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.42525 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.44815 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.41779 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.02876 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.02026 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.03550 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.02568 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.02202 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.03820 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.03209 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.02893 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Inorganicas") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.23957 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.21879 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.24272 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.23584 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.20201 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.16532 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.16095 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.20931 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.40710 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.38308 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.41395 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.37362 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.31836 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.30588 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.40271 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.37210 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.23971 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.33378 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.24764 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.32495 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.41676 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.35735 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.24462 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.30926 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.11362 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.06435 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.09569 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.06560 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.06287 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.17144 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.19171 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.10933 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Redes_Sociales") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.05258 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.04455 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.05261 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.09514 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.08532 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.05593 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.05255 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.06267 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.28998 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.36186 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.28773 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.39178 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.49521 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.41641 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.47998 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.38900 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.14522 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.36583 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.36723 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.36491 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.33207 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.37610 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.35525 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.32952 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.51222 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.22776 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.29243 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.14817 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.08739 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.15156 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.11222 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.21882 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Displays") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.27926 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.25220 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.30273 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.08211 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.25703 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.13511 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.18650 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.21356 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.39516 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.35231 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.14743 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.10381 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.27056 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.15002 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.35425 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.25336 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.22215 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.34444 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.23373 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.19486 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.15182 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.28452 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.26171 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.24189 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.10343 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.05105 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.31611 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.61922 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.32059 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.43035 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.19754 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.29119 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
}

function get_share_trafico_tipo_share_trafico_tabla($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.23499 AS M201505, 0.11455 AS M201507, 0.11335 AS M201509, 0.23393 AS M201511, 0.07698 AS M201601, 0.08230 AS M201603, 0.14928 AS M201605, 0.14363 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.23979 AS M201505, 0.13038 AS M201507, 0.10759 AS M201509, 0.24948 AS M201511, 0.08153 AS M201601, 0.07633 AS M201603, 0.13253 AS M201605, 0.14538 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.25698 AS M201505, 0.15609 AS M201507, 0.20790 AS M201509, 0.25692 AS M201511, 0.08040 AS M201601, 0.06198 AS M201603, 0.10400 AS M201605, 0.16061 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.27401 AS M201505, 0.33084 AS M201507, 0.34678 AS M201509, 0.40586 AS M201511, 0.15923 AS M201601, 0.12913 AS M201603, 0.19646 AS M201605, 0.26319 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Totales") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.38002 AS M201505, 0.49232 AS M201507, 0.53730 AS M201509, 0.44469 AS M201511, 0.38097 AS M201601, 0.39026 AS M201603, 0.33012 AS M201605, 0.42224 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.31879 AS M201505, 0.41367 AS M201507, 0.49597 AS M201509, 0.41359 AS M201511, 0.33501 AS M201601, 0.32544 AS M201603, 0.33065 AS M201605, 0.37616 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.35606 AS M201505, 0.43791 AS M201507, 0.46179 AS M201509, 0.41844 AS M201511, 0.36599 AS M201601, 0.23684 AS M201603, 0.20956 AS M201605, 0.35522 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.09922 AS M201505, 0.10549 AS M201507, 0.13468 AS M201509, 0.13187 AS M201511, 0.14700 AS M201601, 0.21068 AS M201603, 0.22998 AS M201605, 0.15127 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Organicas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.31045 AS M201505, 0.37064 AS M201507, 0.37107 AS M201509, 0.31591 AS M201511, 0.27294 AS M201601, 0.27001 AS M201603, 0.23478 AS M201605, 0.30654 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.23504 AS M201505, 0.27504 AS M201507, 0.29718 AS M201509, 0.27297 AS M201511, 0.21692 AS M201601, 0.19633 AS M201603, 0.18966 AS M201605, 0.24045 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.30824 AS M201505, 0.33472 AS M201507, 0.35893 AS M201509, 0.31676 AS M201511, 0.23306 AS M201601, 0.15388 AS M201603, 0.16090 AS M201605, 0.26664 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.04908 AS M201505, 0.04709 AS M201507, 0.05897 AS M201509, 0.06356 AS M201511, 0.05813 AS M201601, 0.05431 AS M201603, 0.05336 AS M201605, 0.05493 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Busquedas_Inorganicas") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.06957 AS M201505, 0.12168 AS M201507, 0.16623 AS M201509, 0.12878 AS M201511, 0.10803 AS M201601, 0.12025 AS M201603, 0.09534 AS M201605, 0.11570 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.08375 AS M201505, 0.13863 AS M201507, 0.19879 AS M201509, 0.14062 AS M201511, 0.11809 AS M201601, 0.12912 AS M201603, 0.14099 AS M201605, 0.13571 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.04781 AS M201505, 0.10319 AS M201507, 0.10285 AS M201509, 0.10168 AS M201511, 0.13293 AS M201601, 0.08296 AS M201603, 0.04866 AS M201605, 0.08858 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.05013 AS M201505, 0.05841 AS M201507, 0.07571 AS M201509, 0.06831 AS M201511, 0.08887 AS M201601, 0.15636 AS M201603, 0.17662 AS M201605, 0.09635 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Redes_Sociales") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.01565 AS M201505, 0.01465 AS M201507, 0.02194 AS M201509, 0.02573 AS M201511, 0.01628 AS M201601, 0.01246 AS M201603, 0.00767 AS M201605, 0.01634 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.06113 AS M201505, 0.07744 AS M201507, 0.08414 AS M201509, 0.07303 AS M201511, 0.06554 AS M201601, 0.05384 AS M201603, 0.04143 AS M201605, 0.06522 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.02968 AS M201505, 0.06688 AS M201507, 0.09288 AS M201509, 0.05655 AS M201511, 0.03779 AS M201601, 0.02674 AS M201603, 0.01742 AS M201605, 0.04685 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.23158 AS M201505, 0.12225 AS M201507, 0.14089 AS M201509, 0.07641 AS M201511, 0.04408 AS M201601, 0.04234 AS M201603, 0.02549 AS M201605, 0.09758 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Displays") {
        $head = array("Variable", "May-15", "Jul-15", "Sep-15", "Nov-15", "Ene-16", "Mar-16", "May-16", "Promedio");
        $head_style = array("text", "text", "text", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT VARIABLE, M201505, M201507, M201509, M201511, M201601, M201603, M201605, Promedio
                 FROM (SELECT 0 AS ORD, 'Musimundo' AS VARIABLE, 0.09241 AS M201505, 0.07089 AS M201507, 0.01209 AS M201509, 0.00288 AS M201511, 0.00721 AS M201601, 0.00535 AS M201603, 0.01524 AS M201605, 0.02944 AS Promedio UNION
                       SELECT 1 AS ORD, 'Fravega' AS VARIABLE, 0.09264 AS M201505, 0.06444 AS M201507, 0.00413 AS M201509, 0.00251 AS M201511, 0.00527 AS M201601, 0.00345 AS M201603, 0.01711 AS M201605, 0.02708 AS Promedio UNION
                       SELECT 2 AS ORD, 'Garbarino' AS VARIABLE, 0.05049 AS M201505, 0.05382 AS M201507, 0.00566 AS M201509, 0.00391 AS M201511, 0.00254 AS M201601, 0.00360 AS M201603, 0.00718 AS M201605, 0.01817 AS Promedio UNION
                       SELECT 3 AS ORD, 'Avenida' AS VARIABLE, 0.05200 AS M201505, 0.02342 AS M201507, 0.01459 AS M201509, 0.04139 AS M201511, 0.02378 AS M201601, 0.02139 AS M201603, 0.02511 AS M201605, 0.02881 AS Promedio) TMP
                 ORDER BY ORD";
        $body_style = array("text", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1", "percent:1");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
}

function get_share_trafico_tipo_share_trafico_grafico($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.23499 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.11455 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.11335 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.23393 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.07698 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.08230 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.14928 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.14363 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.23979 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.13038 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.10759 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.24948 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.08153 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.07633 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.13253 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.14538 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.25698 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.15609 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.20790 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.25692 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.08040 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.06198 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.10400 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.16061 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.27401 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.33084 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.34678 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.40586 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.15923 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.12913 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.19646 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.26319 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Totales") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.38002 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.49232 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.53730 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.44469 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.38097 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.39026 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.33012 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.42224 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.31879 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.41367 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.49597 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.41359 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.33501 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.32544 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.33065 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.37616 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.35606 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.43791 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.46179 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.41844 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.36599 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.23684 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.20956 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.35522 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.09922 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.10549 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.13468 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.13187 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.14700 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.21068 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.22998 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.15127 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Organicas") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.31045 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.37064 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.37107 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.31591 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.27294 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.27001 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.23478 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.30654 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.23504 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.27504 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.29718 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.27297 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.21692 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.19633 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.18966 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.24045 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.30824 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.33472 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.35893 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.31676 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.23306 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.15388 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.16090 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.26664 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.04908 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.04709 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.05897 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.06356 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.05813 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.05431 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.05336 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.05493 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Busquedas_Inorganicas") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.06957 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.12168 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.16623 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.12878 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.10803 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.12025 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.09534 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.11570 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.08375 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.13863 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.19879 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.14062 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.11809 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.12912 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.14099 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.13571 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.04781 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.10319 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.10285 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.10168 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.13293 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.08296 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.04866 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.08858 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.05013 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.05841 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.07571 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.06831 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.08887 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.15636 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.17662 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.09635 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Redes_Sociales") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.01565 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.01465 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.02194 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.02573 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.01628 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.01246 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.00767 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.01634 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.06113 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.07744 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.08414 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.07303 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.06554 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.05384 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.04143 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.06522 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.02968 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.06688 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.09288 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.05655 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.03779 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.02674 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.01742 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.04685 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.23158 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.12225 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.14089 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.07641 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.04408 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.04234 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.02549 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.09758 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
    else if ($tipo == "Displays") {
        $query1 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.09241 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.07089 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.01209 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.00288 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.00721 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.00535 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.01524 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.02944 AS value) TMP
                   ORDER BY ORD";

        $query2 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.09264 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.06444 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.00413 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.00251 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.00527 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.00345 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.01711 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.02708 AS value) TMP
                   ORDER BY ORD";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.05049 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.05382 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.00566 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.00391 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.00254 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.00360 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.00718 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.01817 AS value) TMP
                   ORDER BY ORD";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 0 AS ORD, '201505' AS label, 0.05200 AS value UNION
                         SELECT 1 AS ORD, '201507' AS label, 0.02342 AS value UNION
                         SELECT 2 AS ORD, '201509' AS label, 0.01459 AS value UNION
                         SELECT 3 AS ORD, '201511' AS label, 0.04139 AS value UNION
                         SELECT 4 AS ORD, '201601' AS label, 0.02378 AS value UNION
                         SELECT 5 AS ORD, '201603' AS label, 0.02139 AS value UNION
                         SELECT 6 AS ORD, '201605' AS label, 0.02511 AS value UNION
                         SELECT 7 AS ORD, 'Promedio' AS label, 0.02881 AS value) TMP
                   ORDER BY ORD";

        to_json(array(
                    array('key'=>competidor_label($user_id, 1), 'values'=>table_simple($query1)),
                    array('key'=>competidor_label($user_id, 2), 'values'=>table_simple($query2)),
                    array('key'=>competidor_label($user_id, 3), 'values'=>table_simple($query3)),
                    array('key'=>competidor_label($user_id, 4), 'values'=>table_simple($query4))
                ));
    }
}


function get_redes_sociales_tabla($user_id) {
    $head = array("Variables", "Musimundo", "Fravega", "Garbarino", "Avenida");
    $head_style = array("text", "text", "text", "text", "text");
    
    $body = "SELECT VARIABLE, M1, M2, M3, M4
             FROM (SELECT 0 AS ORD, 'Tráfico Total' AS VARIABLE, 12567510.2910654 AS M1, 19212721.8602133 AS M2, 26343565.5332733 AS M3, 7736608.05754026 AS M4 UNION
                   SELECT 1 AS ORD, 'Share Redes ' AS VARIABLE, 0.0161704263846496 AS M1, 0.0622366267882214 AS M2, 0.0387241430440204 AS M3, 0.0934457315949197 AS M4 UNION
                   SELECT 2 AS ORD, 'Tráfico Redes' AS VARIABLE, 203222 AS M1, 1195735 AS M2, 1020132 AS M3, 722953 AS M4 UNION
                   SELECT 3 AS ORD, 'Facebook' AS VARIABLE, 173267.0772 AS M1, 1122795.165 AS M2, 888432.9588 AS M3, 690998.4774 AS M4 UNION
                   SELECT 4 AS ORD, 'Share Facebook' AS VARIABLE, 0.8526 AS M1, 0.939 AS M2, 0.8709 AS M3, 0.9558 AS M4 UNION
                   SELECT 5 AS ORD, 'Facebook' AS VARIABLE, 0.0602564625690328 AS M1, 0.390470399373214 AS M2, 0.308967105535195 AS M3, 0.240306032522558 AS M4 UNION
                   SELECT 6 AS ORD, 'You Tube' AS VARIABLE, 14347.4732 AS M1, 40176.6959999999 AS M2, 72531.3852 AS M3, 21327.1135 AS M4 UNION
                   SELECT 7 AS ORD, 'Share You Tube' AS VARIABLE, 0.0706 AS M1, 0.0336 AS M2, 0.0711 AS M3, 0.0295 AS M4 UNION
                   SELECT 8 AS ORD, 'You Tube' AS VARIABLE, 0.0966923792586695 AS M1, 0.270764076213243 AS M2, 0.488813054964622 AS M3, 0.143730489563465 AS M4 UNION
                   SELECT 9 AS ORD, 'Twitter' AS VARIABLE, 13412.652 AS M1, 21881.9505 AS M2, 41519.3724 AS M3, 9759.8655 AS M4 UNION
                   SELECT 10 AS ORD, 'Share Twitter' AS VARIABLE, 0.066 AS M1, 0.0183 AS M2, 0.0407 AS M3, 0.0135 AS M4 UNION
                   SELECT 11 AS ORD, 'Twitter' AS VARIABLE, 0.154927307579623 AS M1, 0.252754762857904 AS M2, 0.47958334998386 AS M3, 0.112734579578614 AS M4 UNION
                   SELECT 12 AS ORD, 'Reddit' AS VARIABLE, 0 AS M1, 10402.8945 AS M2, 11935.5444 AS M3, 0 AS M4 UNION
                   SELECT 13 AS ORD, 'Share Reddit' AS VARIABLE, 0 AS M1, 0.0087 AS M2, 0.0117 AS M3, 0 AS M4 UNION
                   SELECT 14 AS ORD, 'Reddit' AS VARIABLE, 0 AS M1, 0.465694784965479 AS M2, 0.534305215034521 AS M3, 0 AS M4 UNION
                   SELECT 15 AS ORD, 'Otros' AS VARIABLE, 2194.7976 AS M1, 478.293999999969 AS M2, 5712.73919999999 AS M3, 867.543600000026 AS M4 UNION
                   SELECT 16 AS ORD, 'Share Otros' AS VARIABLE, 0.0108 AS M1, 0.000399999999999974 AS M2, 0.00559999999999999 AS M3, 0.00120000000000004 AS M4 UNION
                   SELECT 17 AS ORD, 'Otros' AS VARIABLE, 0.237188889709251 AS M1, 0.0516886034569151 AS M2, 0.617368211103616 AS M3, 0.0937542957302179 AS M4) TMP
             ORDER BY ORD";
    $body_style = array(
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text+bold", "comma+bold", "comma+bold", "comma+bold", "comma+bold"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1"),
                      array("text", "percent:1", "percent:1", "percent:1", "percent:1")
                  );
              
    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
            ));
}

function get_redes_sociales_b100_grafico($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Share Redes ' AS label, 0.0161704263846496 AS value UNION
                     SELECT 5 AS ORD, 'Facebook' AS label, 0.0602564625690328 AS value UNION
                     SELECT 8 AS ORD, 'You Tube' AS label, 0.0966923792586695 AS value UNION
                     SELECT 11 AS ORD, 'Twitter' AS label, 0.154927307579623 AS value UNION
                     SELECT 14 AS ORD, 'Reddit' AS label, 0 AS value UNION
                     SELECT 17 AS ORD, 'Otros' AS label, 0.237188889709251 AS value) TMP
               ORDER BY ORD";

	$query2 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Share Redes ' AS label, 0.0622366267882214 AS value UNION
                     SELECT 5 AS ORD, 'Facebook' AS label, 0.390470399373214 AS value UNION
                     SELECT 8 AS ORD, 'You Tube' AS label, 0.270764076213243 AS value UNION
                     SELECT 11 AS ORD, 'Twitter' AS label, 0.252754762857904 AS value UNION
                     SELECT 14 AS ORD, 'Reddit' AS label, 0.465694784965479 AS value UNION
                     SELECT 17 AS ORD, 'Otros' AS label, 0.0516886034569151 AS value) TMP
               ORDER BY ORD";

	$query3 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Share Redes ' AS label, 0.0387241430440204 AS value UNION
                     SELECT 5 AS ORD, 'Facebook' AS label, 0.308967105535195 AS value UNION
                     SELECT 8 AS ORD, 'You Tube' AS label, 0.488813054964622 AS value UNION
                     SELECT 11 AS ORD, 'Twitter' AS label, 0.47958334998386 AS value UNION
                     SELECT 14 AS ORD, 'Reddit' AS label, 0.534305215034521 AS value UNION
                     SELECT 17 AS ORD, 'Otros' AS label, 0.617368211103616 AS value) TMP
               ORDER BY ORD";

	$query4 = "SELECT label, value
               FROM (SELECT 1 AS ORD, 'Share Redes ' AS label, 0.0934457315949197 AS value UNION
                     SELECT 5 AS ORD, 'Facebook' AS label, 0.240306032522558 AS value UNION
                     SELECT 8 AS ORD, 'You Tube' AS label, 0.143730489563465 AS value UNION
                     SELECT 11 AS ORD, 'Twitter' AS label, 0.112734579578614 AS value UNION
                     SELECT 14 AS ORD, 'Reddit' AS label, 0 AS value UNION
                     SELECT 17 AS ORD, 'Otros' AS label, 0.0937542957302179 AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array("key"=>"Musimundo", "values"=>table_simple($query1)),
                array("key"=>"Fravega", "values"=>table_simple($query2)),
                array("key"=>"Garbarino", "values"=>table_simple($query3)),
                array("key"=>"Avenida", "values"=>table_simple($query4))
            ));
}

function get_redes_sociales_grafico($user_id) {
	$query1 = "SELECT label, value
               FROM (SELECT 4 AS ORD, 'Share Facebook' AS label, 0.8526 AS value UNION
                     SELECT 7 AS ORD, 'Share You Tube' AS label, 0.0706 AS value UNION
                     SELECT 10 AS ORD, 'Share Twitter' AS label, 0.066 AS value UNION
                     SELECT 13 AS ORD, 'Share Reddit' AS label, 0 AS value UNION
                     SELECT 16 AS ORD, 'Share Otros' AS label, 0.0108 AS value) TMP
               ORDER BY ORD";

	$query2 = "SELECT label, value
               FROM (SELECT 4 AS ORD, 'Share Facebook' AS label, 0.939 AS value UNION
                     SELECT 7 AS ORD, 'Share You Tube' AS label, 0.0336 AS value UNION
                     SELECT 10 AS ORD, 'Share Twitter' AS label, 0.0183 AS value UNION
                     SELECT 13 AS ORD, 'Share Reddit' AS label, 0.0087 AS value UNION
                     SELECT 16 AS ORD, 'Share Otros' AS label, 0.000399999999999974 AS value) TMP
               ORDER BY ORD";

	$query3 = "SELECT label, value
               FROM (SELECT 4 AS ORD, 'Share Facebook' AS label, 0.8709 AS value UNION
                     SELECT 7 AS ORD, 'Share You Tube' AS label, 0.0711 AS value UNION
                     SELECT 10 AS ORD, 'Share Twitter' AS label, 0.0407 AS value UNION
                     SELECT 13 AS ORD, 'Share Reddit' AS label, 0.0117 AS value UNION
                     SELECT 16 AS ORD, 'Share Otros' AS label, 0.00559999999999999 AS value) TMP
               ORDER BY ORD";

	$query4 = "SELECT label, value
               FROM (SELECT 4 AS ORD, 'Share Facebook' AS label, 0.9558 AS value UNION
                     SELECT 7 AS ORD, 'Share You Tube' AS label, 0.0295 AS value UNION
                     SELECT 10 AS ORD, 'Share Twitter' AS label, 0.0135 AS value UNION
                     SELECT 13 AS ORD, 'Share Reddit' AS label, 0 AS value UNION
                     SELECT 16 AS ORD, 'Share Otros' AS label, 0.00120000000000004 AS value) TMP
               ORDER BY ORD";

    to_json(array(
                array("key"=>"Musimundo", "values"=>table_simple($query1)),
                array("key"=>"Fravega", "values"=>table_simple($query2)),
                array("key"=>"Garbarino", "values"=>table_simple($query3)),
                array("key"=>"Avenida", "values"=>table_simple($query4))
            ));
}


function get_dominios_tabla($user_id, $tipo) {
    if ($tipo == "Referidos") {
        $head = array("ID", "Dominio", "Referidos", "Musimundo", "Fravega", "Garbarino", "Avenida");
        $head_style = array("comma", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT ID, Domian, M0, M1, M2, M3, M4
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'hotsale.com.ar' AS Domian, 0.7072 AS M0, 0.199 AS M1, 0.305 AS M2, 0.377 AS M3, 0.118 AS M4 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'mercadolibre.com.ar' AS Domian, 0.0779 AS M0, 0 AS M1, 0.074 AS M2, 0.42 AS M3, 0.506 AS M4 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'lanacion.com.ar' AS Domian, 0.0302 AS M0, 0.014 AS M1, 0.387 AS M2, 0.547 AS M3, 0.052 AS M4 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'infobae.com' AS Domian, 0.0169 AS M0, 0 AS M1, 0.903 AS M2, 0.094 AS M3, 0 AS M4 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'hotsalearg.com.ar' AS Domian, 0.0151 AS M0, 0.195 AS M1, 0.279 AS M2, 0.418 AS M3, 0.108 AS M4 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'images.newsletter.ndwcdn.com.ar' AS Domian, 0.0129 AS M0, 1 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'ads01.groovinads.com' AS Domian, 0.0124 AS M0, 0 AS M1, 0.068 AS M2, 0.932 AS M3, 0 AS M4 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'descuentocity.com' AS Domian, 0.0104 AS M0, 0.005 AS M1, 0 AS M2, 0.173 AS M3, 0.822 AS M4 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'gurudeofertas.com' AS Domian, 0.008 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 1 AS M4 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'api.herolens.com' AS Domian, 0.007 AS M0, 0 AS M1, 0 AS M2, 0.839 AS M3, 0.161 AS M4 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'lg.com' AS Domian, 0.006 AS M0, 0.262 AS M1, 0.425 AS M2, 0.314 AS M3, 0 AS M4 UNION
                       SELECT 11 AS ORD, 12 AS ID, 'appnew.emblujet.com' AS Domian, 0.005 AS M0, 0 AS M1, 1 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'samsung.com' AS Domian, 0.005 AS M0, 0.094 AS M1, 0.284 AS M2, 0.622 AS M3, 0 AS M4 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'foros.3dgames.com.ar' AS Domian, 0.005 AS M0, 0.064 AS M1, 0.177 AS M2, 0.678 AS M3, 0.081 AS M4 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'mydplr.net' AS Domian, 0.005 AS M0, 0 AS M1, 0 AS M2, 1 AS M3, 0 AS M4 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'cybermonday.com.ar' AS Domian, 0.004 AS M0, 0.263 AS M1, 0.361 AS M2, 0.32 AS M3, 0.056 AS M4 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'msn.com' AS Domian, 0.003 AS M0, 0.013 AS M1, 0 AS M2, 0.814 AS M3, 0.173 AS M4 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'amexhotsale.com.ar' AS Domian, 0.003 AS M0, 0.352 AS M1, 0.103 AS M2, 0.302 AS M3, 0.242 AS M4 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'lavoz.com.ar' AS Domian, 0.003 AS M0, 1 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 19 AS ORD, 20 AS ID, 'philips.com.ar' AS Domian, 0.003 AS M0, 0.414 AS M1, 0.121 AS M2, 0.465 AS M3, 0 AS M4) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "percent:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Organicas") {
        $head = array("ID", "Dominio", "Referidos", "Musimundo", "Fravega", "Garbarino", "Avenida");
        $head_style = array("comma", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT ID, Domian, M0, M1, M2, M3, M4
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'garbarino' AS Domian, 0.203858406209676 AS M0, 0.00534763949344543 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'fravega' AS Domian, 0.144931686949724 AS M0, 0.0049010031537638 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'musimundo' AS Domian, 0.119372085465335 AS M0, 0.9851277095437 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'cyber monday' AS Domian, 0.0211082892592317 AS M0, 0.0895351434389925 AS M1, 0 AS M2, 0 AS M3, 0.000710982784743542 AS M4 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'avenida' AS Domian, 0.0100067978588353 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0.990929272838058 AS M4 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'garbarino cyber monday' AS Domian, 0.00602439446548653 AS M0, 0.013845947260022 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'cyber monday garbarino' AS Domian, 0.0059385058073589 AS M0, 0.0341745731941382 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'cyber monday fravega' AS Domian, 0.0039149829227443 AS M0, 0.068037715825111 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'cyber monday musimundo' AS Domian, 0.00334381437176679 AS M0, 0.992465798694961 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'black friday' AS Domian, 0.00306101835495473 AS M0, 0.00414375784959159 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'fravega cyber monday' AS Domian, 0.00294988089982635 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 11 AS ORD, 12 AS ID, 'avenida.com' AS Domian, 0.00237945225351392 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 1 AS M4 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'musimundo cyber monday' AS Domian, 0.00226697727118448 AS M0, 0.988886976978639 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'garbarino celulares' AS Domian, 0.00218022454372415 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'cibermonday' AS Domian, 0.00205648225308902 AS M0, 0.0531524102275699 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'fravega catalogo' AS Domian, 0.00179451461934596 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'ciber monday' AS Domian, 0.00175239140843816 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'musimundo catalogo' AS Domian, 0.00162511576018736 AS M0, 0.987161701044894 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'fravega celulares' AS Domian, 0.00158652143869951 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 19 AS ORD, 20 AS ID, 'celulares' AS Domian, 0.00138776392847887 AS M0, 0.100539655436856 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 20 AS ORD, 21 AS ID, 'cybermonday' AS Domian, 0.00130344613993788 AS M0, 0.0873772370094992 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 21 AS ORD, 22 AS ID, 'garbarino rosario' AS Domian, 0.00117337855658957 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 22 AS ORD, 23 AS ID, 'black friday musimundo' AS Domian, 0.00104947712998867 AS M0, 1 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 23 AS ORD, 24 AS ID, 'musimundo celulares' AS Domian, 0.00104052881823082 AS M0, 0.987395647022997 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 24 AS ORD, 25 AS ID, 'garbarino argentina' AS Domian, 0.00101596113254049 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "percent:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Inorganicas") {
        $head = array("ID", "Dominio", "Referidos", "Musimundo", "Fravega", "Garbarino", "Avenida");
        $head_style = array("comma", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT ID, Domian, M0, M1, M2, M3, M4
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'garbarino' AS Domian, 0.0553390730531365 AS M0, 0.0452931369053873 AS M1, 0 AS M2, 0 AS M3, 0.0094164283998516 AS M4 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'fravega' AS Domian, 0.054429985498787 AS M0, 0.0477983409518301 AS M1, 0 AS M2, 0 AS M3, 0.00638246748667153 AS M4 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'musimundo' AS Domian, 0.0414579913104355 AS M0, 0.858903600894751 AS M1, 0 AS M2, 0 AS M3, 0.00384060830756755 AS M4 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'avenida' AS Domian, 0.00610450153837292 AS M0, 0.0103948200916904 AS M1, 0 AS M2, 0 AS M3, 0.969520272925774 AS M4 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'cyber monday' AS Domian, 0.00394148886016747 AS M0, 0.163676174453123 AS M1, 0 AS M2, 0 AS M3, 0.0587591178647909 AS M4 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'compumundo' AS Domian, 0.00374794842828747 AS M0, 0.390523447391463 AS M1, 0 AS M2, 0 AS M3, 0.00386208636752714 AS M4 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'black friday' AS Domian, 0.003730308806402 AS M0, 0.0311862986808333 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'fravega cyber monday' AS Domian, 0.00198611727061213 AS M0, 0.0851983195954007 AS M1, 0 AS M2, 0 AS M3, 0.00728803920355748 AS M4 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'cyber monday fravega' AS Domian, 0.00168259098641156 AS M0, 0.0691401092408682 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'olx' AS Domian, 0.00167042573147115 AS M0, 0.00633123979966358 AS M1, 0 AS M2, 0 AS M3, 0.86869388928081 AS M4 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'cyber monday garbarino' AS Domian, 0.00152626910083664 AS M0, 0.00692922753115754 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 11 AS ORD, 12 AS ID, 'avenida.com' AS Domian, 0.00151408295854641 AS M0, 0.00698499762762383 AS M1, 0 AS M2, 0 AS M3, 0.936165392895812 AS M4 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'carrefour' AS Domian, 0.00123558501979361 AS M0, 0.308138384122366 AS M1, 0 AS M2, 0 AS M3, 0.0468600712996721 AS M4 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'movistar' AS Domian, 0.00105817510930509 AS M0, 0.281531780992821 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'personal' AS Domian, 0.00103113655657492 AS M0, 0.369234481133771 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'garbarino cyber monday' AS Domian, 0.000950160617771433 AS M0, 0.0111306085262486 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'musimundo catalogo' AS Domian, 0.000921976575895579 AS M0, 0.973386261978813 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'black friday argentina' AS Domian, 0.00089119117662195 AS M0, 0.011867112411907 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'www.avenida.com' AS Domian, 0.000850665733202469 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0.985623393297706 AS M4 UNION
                       SELECT 19 AS ORD, 20 AS ID, 'walmart' AS Domian, 0.000849298332979563 AS M0, 0.261501965468079 AS M1, 0 AS M2, 0 AS M3, 0.0170433638793356 AS M4 UNION
                       SELECT 20 AS ORD, 21 AS ID, 'fravega catalogo' AS Domian, 0.000849286394905965 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 21 AS ORD, 22 AS ID, 'musimundo la plata' AS Domian, 0.000835631610137107 AS M0, 1 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 22 AS ORD, 23 AS ID, 'black friday 2015' AS Domian, 0.000819856225790703 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 23 AS ORD, 24 AS ID, 'aire acondicionado portatil' AS Domian, 0.000691597016771492 AS M0, 0.168211432072492 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 24 AS ORD, 25 AS ID, 'notebook' AS Domian, 0.000646885520206795 AS M0, 0.261582380019054 AS M1, 0 AS M2, 0 AS M3, 0.358020702679052 AS M4) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "percent:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Social") {
        $head = array("ID", "Dominio", "Referidos", "Musimundo", "Fravega", "Garbarino", "Avenida");
        $head_style = array("comma", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT ID, Domian, M0, M1, M2, M3, M4
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'facebook.com' AS Domian, 0.703419346653185 AS M0, 0.0779804961057417 AS M1, 0 AS M2, 0 AS M3, 0.139229786567823 AS M4 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'facebook.com/?ref=tn_tnmn' AS Domian, 0.0409048138141809 AS M0, 0.0226274008105621 AS M1, 0 AS M2, 0 AS M3, 0.12999975263987 AS M4 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'youtube.com' AS Domian, 0.0212671155906287 AS M0, 0.110857090176249 AS M1, 0 AS M2, 0 AS M3, 0.557410578245691 AS M4 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'twitter.com' AS Domian, 0.013369057155599 AS M0, 0.0456098403477341 AS M1, 0 AS M2, 0 AS M3, 0.303828184275603 AS M4 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'facebook.com/?_rdr=p' AS Domian, 0.00964567849131523 AS M0, 0.0359838456966085 AS M1, 0 AS M2, 0 AS M3, 0.0666400719102244 AS M4 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'facebook.com/home.php' AS Domian, 0.00710531663270569 AS M0, 0.0488491399345861 AS M1, 0 AS M2, 0 AS M3, 0.0493450244126466 AS M4 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'facebook.com/?sk=h_chr' AS Domian, 0.0067677945295511 AS M0, 0.350449785947176 AS M1, 0 AS M2, 0 AS M3, 0.0518059496590098 AS M4 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'facebook.com/?ref=logo' AS Domian, 0.00591259828008328 AS M0, 0.058703228264257 AS M1, 0 AS M2, 0 AS M3, 0.256962961639577 AS M4 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'facebook.com/?q=' AS Domian, 0.00569531628912651 AS M0, 0.0609428149114815 AS M1, 0 AS M2, 0 AS M3, 0.17216601082917 AS M4 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'google.com.ar/_/chrome/newtab?espv=2&ie=UTF-8' AS Domian, 0.00379158938622802 AS M0, 0.0377553923901246 AS M1, 0 AS M2, 0 AS M3, 0.0259598464867943 AS M4 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'apps.facebook.com/jackpotpartycasino/?fb_source=canvas_bookmark' AS Domian, 0.0034377808979193 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 1 AS M4 UNION
                       SELECT 11 AS ORD, 12 AS ID, 'youtube.com/?gl=AR&hl=es-419' AS Domian, 0.00333058077732837 AS M0, 0.0442417311807065 AS M1, 0 AS M2, 0 AS M3, 0.683572963457072 AS M4 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'web.facebook.com' AS Domian, 0.00296066302772279 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0.0163872310592463 AS M4 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'facebook.com/GarbarinoGarantiaDeConfianza/?fref=ts' AS Domian, 0.00278388406756429 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'reddit.com/r/argentina/comments/3r6zel/cybermonday_thread' AS Domian, 0.00232493094087834 AS M0, 0.980426081624925 AS M1, 0 AS M2, 0 AS M3, 0.0195739183750745 AS M4 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'twitter.com/?lang=es' AS Domian, 0.00194250782688769 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0.711273924847396 AS M4 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'taringa.net/posts/info/9280909/Descargar-Codem-Anses-y-consulta-Cuil.html' AS Domian, 0.00191799267224026 AS M0, 1 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'facebook.com/musimundo/?fref=ts' AS Domian, 0.00179329113343134 AS M0, 1 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'facebook.com/fravegaonline/?fref=ts' AS Domian, 0.00157766071040428 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 19 AS ORD, 20 AS ID, 'mail.google.com/mail/u/0/#inbox' AS Domian, 0.00131682124735188 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0.34738705246379 AS M4 UNION
                       SELECT 20 AS ORD, 21 AS ID, 'youtube.com/feed/subscriptions' AS Domian, 0.00128955489128309 AS M0, 0.685588463533702 AS M1, 0 AS M2, 0 AS M3, 0.0608789309418292 AS M4 UNION
                       SELECT 21 AS ORD, 22 AS ID, 'apps.facebook.com/jackpotpartycasino/?fb_source=bookmark&ref=bookmarks&count=0&fb_bmpos=_0' AS Domian, 0.00128916783671974 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 1 AS M4 UNION
                       SELECT 22 AS ORD, 23 AS ID, 'facebook.com/email/unreachable' AS Domian, 0.00127090359606196 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 23 AS ORD, 24 AS ID, 'facebook.com/avenida.com.ar/?fref=nf' AS Domian, 0.00122714207945156 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 1 AS M4 UNION
                       SELECT 24 AS ORD, 25 AS ID, 'facebook.com/musimundo' AS Domian, 0.00121481012264704 AS M0, 1 AS M1, 0 AS M2, 0 AS M3, 0 AS M4) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "percent:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Ad_Net") {
        $head = array("ID", "Dominio", "Referidos", "Musimundo", "Fravega", "Garbarino", "Avenida");
        $head_style = array("comma", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT ID, Domian, M0, M1, M2, M3, M4
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'Yahoo Display Ads' AS Domian, 0.587629249606837 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'Google Display Network' AS Domian, 0.221677530258222 AS M0, 0 AS M1, 0.18332585728777 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'Criteo' AS Domian, 0.17075212557855 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'CPX24' AS Domian, 0.00547253872591983 AS M0, 0 AS M1, 0.507368341037823 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'Smart Ad Server' AS Domian, 0.00378757258136693 AS M0, 0 AS M1, 0.733079785267935 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'Appnexus' AS Domian, 0.00279158788411799 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'Adf.ly' AS Domian, 0.002162925206621 AS M0, 0 AS M1, 0.700211551753828 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'Propeller Ads Media' AS Domian, 0.00168104519688411 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'Adcash' AS Domian, 0.00101097968673174 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'inMind' AS Domian, 0.000717682183228925 AS M0, 0 AS M1, 0.351712139125809 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'Mediahub' AS Domian, 0.000465264647352998 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 11 AS ORD, 12 AS ID, 'Outbrain' AS Domian, 0.000252417535875926 AS M0, 0 AS M1, 1 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'Adplex Media' AS Domian, 0.000252417535875926 AS M0, 0 AS M1, 1 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'Voluum' AS Domian, 0.000252417535875926 AS M0, 0 AS M1, 1 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'PopMyAds' AS Domian, 0.000252417535875926 AS M0, 0 AS M1, 1 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'Microsoft adCenter' AS Domian, 0.000252417535875926 AS M0, 0 AS M1, 1 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'Wi Get Media' AS Domian, 0.000252417535875926 AS M0, 0 AS M1, 1 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'AdSupply' AS Domian, 0.00016849661445529 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'sh.st' AS Domian, 0.00016849661445529 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "percent:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Publisher") {
        $head = array("ID", "Dominio", "Referidos", "Musimundo", "Fravega", "Garbarino", "Avenida");
        $head_style = array("comma", "text", "text", "text", "text", "text", "text");
        
        $body = "SELECT ID, Domian, M0, M1, M2, M3, M4
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'ar-mg6.mail.yahoo.com' AS Domian, 0.228498563516781 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'ar-mg5.mail.yahoo.com' AS Domian, 0.219560904296509 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'espanol.yahoo.com' AS Domian, 0.17219131042907 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'youtube.com' AS Domian, 0.118293653569723 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'login.yahoo.com' AS Domian, 0.0723950396841994 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'ar-mg4.mail.yahoo.com' AS Domian, 0.0545197212436564 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'beap-bc.yahoo.com' AS Domian, 0.0187690843625702 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'facebook.com' AS Domian, 0.0184635718403998 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'snt146.mail.live.com' AS Domian, 0.0163022125407227 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'mail.google.com' AS Domian, 0.0150384443888819 AS M0, 0 AS M1, 0.210525765004637 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'google.com.ar' AS Domian, 0.0114447535800748 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 11 AS ORD, 12 AS ID, 'bay179.mail.live.com' AS Domian, 0.00978588185333044 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'bay175.mail.live.com' AS Domian, 0.00889211593130329 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'blu168.mail.live.com' AS Domian, 0.00889211593130329 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'blu179.mail.live.com' AS Domian, 0.00592807728753553 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'finance.yahoo.com' AS Domian, 0.00204103923713419 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'es-us.noticias.yahoo.com' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'blu171.mail.live.com' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'taringa.net' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 19 AS ORD, 20 AS ID, 'bay180.mail.live.com' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 20 AS ORD, 21 AS ID, 'bay167.mail.live.com' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 21 AS ORD, 22 AS ID, 'blu174.mail.live.com' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 22 AS ORD, 23 AS ID, 'blu182.mail.live.com' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 23 AS ORD, 24 AS ID, 'blu176.mail.live.com' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4 UNION
                       SELECT 24 AS ORD, 25 AS ID, 'col131.mail.live.com' AS Domian, 0.00148201932188388 AS M0, 0 AS M1, 0 AS M2, 0 AS M3, 0 AS M4) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "percent:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
}


function get_outlinks_tabla($user_id) {
    $head = array(
                array("ID", "Musimundo", "Fravega", "Garbarino", "Avenida"),
                array("Dominio", "Share Tráfico", "Variación", "Dominio", "Share Tráfico", "Variación", "Dominio", "Share Tráfico", "Variación", "Dominio", "Share Tráfico", "Variación")
            );
    $head_style = array(
                      array("text+row:2", "text+col:3", "text+col:3", "text+col:3", "text+col:3"),
                      array("text", "text", "text", "text", "text", "text", "text", "text", "text", "text", "text", "text")
                  );
    
    $body = "SELECT ID, M11, M12, M13, M21, M22, M23, M31, M32, M33, M41, M42, M43
             FROM (SELECT 0 AS ORD, 1 AS ID, 'services2.nps.com.ar' AS M11, 0.0657971976876447 AS M12, 0 AS M13, 'booking.com' AS M21, 0.475185072771445 AS M22, 0.096942188492472 AS M23, 'facebook.com' AS M31, 0.459096305403137 AS M32, 1.06788338737492 AS M33, 'google.com.ar' AS M41, 0.472456024115223 AS M42, 0.0747046031165954 AS M43 UNION
                   SELECT 1 AS ORD, 2 AS ID, 'ads.ad4game.com' AS M11, 0.0553977038613329 AS M12, 0.730995780546964 AS M13, '10990-194244.ampclicks.com' AS M21, 0.058351356610849 AS M22, 0.700262970666056 AS M23, 'owa.garbarino.com.ar' AS M31, 0.115038084959647 AS M32, 0 AS M33, 'facebook.com' AS M41, 0.459120317099937 AS M42, 3.00957776291664 AS M43 UNION
                   SELECT 2 AS ORD, 3 AS ID, 'facebook.com' AS M11, 0.0500901629223791 AS M12, 1.1358651524507 AS M13, 'youtube.com' AS M21, 0.0464999989146001 AS M22, -0.196064106370713 AS M23, 'twitter.com' AS M31, 0.0701827957087054 AS M32, 1.6861499905925 AS M33, 'youtube.com' AS M41, 0.0310103773526648 AS M42, 0 AS M43 UNION
                   SELECT 3 AS ORD, 4 AS ID, 'track.skincareimprove.com' AS M11, 0.0496030128629263 AS M12, 2.74867273739504 AS M13, 'connect814.com' AS M21, 0.0396162071047558 AS M22, 6.05240797529927 AS M23, 'fravega.com' AS M31, 0.0579344011174135 AS M32, 1.95918969523793 AS M33, 'web.facebook.com' AS M41, 0.0157991909680255 AS M42, 0 AS M43 UNION
                   SELECT 4 AS ORD, 5 AS ID, 'tuenti.com.ar' AS M11, 0.0433931360315834 AS M12, -0.136213626948759 AS M13, 'track.skincareimprove.com' AS M21, 0.0287972173370651 AS M22, 0.888053701606607 AS M23, 'google.com.ar' AS M31, 0.0545175178074806 AS M32, 6.83902181096811 AS M33, 'twitter.com' AS M41, 0.00447215732011005 AS M42, 0.00730624647218902 AS M43 UNION
                   SELECT 5 AS ORD, 6 AS ID, 'prize.4you.quizzitch.co' AS M11, 0.041993512050603 AS M12, 1.40292631528123 AS M13, 'click.primosearch.com' AS M21, 0.0259716737550051 AS M22, -0.607661136339287 AS M23, 'd3lfzbr90tctqz.cloudfront.net' AS M31, 0.0377001887289391 AS M32, -0.344299195248816 AS M33, 'fravega.com' AS M41, 0.00369167049313334 AS M42, 0 AS M43 UNION
                   SELECT 6 AS ORD, 7 AS ID, 'cdn.adservingsolutionsinc.com' AS M11, 0.0418888066229895 AS M12, -0.589643437646184 AS M13, 'prize.4you.quizzitch.co' AS M21, 0.0230036655353653 AS M22, 2.57321943817174 AS M23, 'pstatic.bestpriceninja.com' AS M31, 0.0282870443827042 AS M32, 0.904375883373629 AS M33, 'avalancha.com' AS M41, 0.00290852918636546 AS M42, 0 AS M43 UNION
                   SELECT 7 AS ORD, 8 AS ID, 'thegreatspringgiveaway.com' AS M11, 0.0418106567971121 AS M12, 0 AS M13, 'stamplive.com' AS M21, 0.021565278575545 AS M22, 1.92866206347127 AS M23, '10990-50538615.ampclicks.com' AS M31, 0.0257025626572741 AS M32, 0 AS M33, 'istock.com' AS M41, 0.00239065608196562 AS M42, 0 AS M43 UNION
                   SELECT 8 AS ORD, 9 AS ID, 'twitter.com' AS M11, 0.0393260149415815 AS M12, -0.364959105484924 AS M13, 'mercadopago.com' AS M21, 0.0200300188551157 AS M22, 5.86029311103136 AS M23, 'click.primosearch.com' AS M31, 0.021350049429361 AS M32, 0.256544739021473 AS M33, 'play.google.com' AS M41, 0.00229000247886201 AS M42, -0.92856525371583 AS M43 UNION
                   SELECT 9 AS ORD, 10 AS ID, '10990-13373085.ampclicks.com' AS M11, 0.0388579507537939 AS M12, -0.446546811176345 AS M13, 'facebook.com' AS M21, 0.0174755380557858 AS M22, 0.95481433721325 AS M23, 'booking.com' AS M31, 0.0208729042003691 AS M32, -0.734290644837508 AS M33, 'pornoenargentina.com' AS M41, 0.00223246463321326 AS M42, 0 AS M43 UNION
                   SELECT 10 AS ORD, 11 AS ID, 'google.com.ar' AS M11, 0.0365173653413855 AS M12, 0.544049750645233 AS M13, 'feclik.com' AS M21, 0.017454438240696 AS M22, 8.20262910169567 AS M23, 'es.pinterest.com' AS M31, 0.0189083484340319 AS M32, 0 AS M33, 'compumundo.com.ar' AS M41, 0.0013085955439525 AS M42, 0 AS M43 UNION
                   SELECT 11 AS ORD, 12 AS ID, 'fatlosshappyhour.com' AS M11, 0.0277932662545929 AS M12, 0 AS M13, 'accounts.google.com' AS M21, 0.0107673248520736 AS M22, 2.00979527303626 AS M23, 'prize.4you.quizzitch.co' AS M31, 0.0153775206155509 AS M32, 0 AS M33, 'ad.soicos.com' AS M41, 0.00129074656813146 AS M42, 0 AS M43 UNION
                   SELECT 12 AS ORD, 13 AS ID, 'ad.soicos.com' AS M11, 0.0223400089830864 AS M12, 0.049036052481938 AS M13, 'google.com.ar' AS M21, 0.00985821064093952 AS M22, 1.39525666446248 AS M23, 'youtube.com' AS M31, 0.0152079495896008 AS M32, 0.322604212099795 AS M33, 'ads.ad4game.com' AS M41, 0.00102926815841693 AS M42, 0 AS M43 UNION
                   SELECT 13 AS ORD, 14 AS ID, 'directv.com.ar' AS M11, 0.0212611924115424 AS M12, -0.681172402405636 AS M13, 'clpremdo.com' AS M21, 0.00975042008925551 AS M22, 0 AS M23, 'instagram.com' AS M31, 0.0148742810832486 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 14 AS ORD, 15 AS ID, 'es.reimageplus.com' AS M11, 0.0211129056955584 AS M12, -0.516870642434394 AS M13, 'econfianza.org' AS M21, 0.00909433586303587 AS M22, 9.09808635006232 AS M23, 'servicios1.afip.gov.ar' AS M31, 0.00769770121165404 AS M32, 5.47478164915133 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 15 AS ORD, 16 AS ID, 'econfianza.org' AS M11, 0.0188928757899637 AS M12, 48.0813964456518 AS M13, '10990-1701434.ampclicks.com' AS M21, 0.00834744501892882 AS M22, 2.99004399589907 AS M23, 'misimundo.com' AS M31, 0.00475928908066682 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 16 AS ORD, 17 AS ID, 'click.primosearch.com' AS M11, 0.0176010621945676 AS M12, -0.849402877720273 AS M13, 'newsweeklatino.com' AS M21, 0.00668590312557815 AS M22, 0.327751666275179 AS M23, 'f.piesearch.com' AS M31, 0.00453653455354936 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 17 AS ORD, 18 AS ID, 'getmusicla.com' AS M11, 0.0172724528754475 AS M12, 3.02769291766012 AS M13, 'aliexpress.com' AS M21, 0.00661582022313809 AS M22, 4.88955662169163 AS M23, 'decomposeselbows.com' AS M31, 0.00343585488403785 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 18 AS ORD, 19 AS ID, 'booking.com' AS M11, 0.0171404842622569 AS M12, -0.175536790673904 AS M13, 'animeid.tv' AS M21, 0.00595699240643206 AS M22, 0 AS M23, 'vsb.tatlocalisation.com' AS M31, 0.00330482035866398 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 19 AS ORD, 20 AS ID, 'connect814.com' AS M11, 0.0146084669887278 AS M12, 7.5735155778148 AS M13, 'collegefreebies.net' AS M21, 0.00583562657467104 AS M22, 6.83241035886263 AS M23, 'centrifugescompletions.com' AS M31, 0.00315139216205332 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 20 AS ORD, 21 AS ID, 'fravega.com' AS M11, 0.0145522836731343 AS M12, 3.80868325476163 AS M13, 'pmkzz.secure.jigi.info' AS M21, 0.00580289756752142 AS M22, 0 AS M23, 'wcp.commonwealthprussia.com' AS M31, 0.0029960248550802 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 21 AS ORD, 22 AS ID, 'youtube.com' AS M11, 0.0141046781131376 AS M12, 0 AS M13, 'rewards.todayonly.co' AS M21, 0.00573574450587185 AS M22, 0 AS M23, 'clpremdo.com' AS M31, 0.00241112033587093 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 22 AS ORD, 23 AS ID, 'stamplive.com' AS M11, 0.0135513792516031 AS M12, -0.208438555541294 AS M13, 'support.mircosoft.com-supportcenter.space' AS M21, 0.0055722704573351 AS M22, 0 AS M23, 'ctxfeed.media-serving.com' AS M31, 0.00185369697272214 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 23 AS ORD, 24 AS ID, 'newsweeklatino.com' AS M11, 0.0118300644405327 AS M12, 5.49598933500222 AS M13, 'onclicktop.com' AS M21, 0.00501477868494438 AS M22, 0 AS M23, 'v2.polarr.co' AS M31, 0.00155215244424807 AS M32, 0 AS M33, '' AS M41, 0 AS M42, 0 AS M43 UNION
                   SELECT 24 AS ORD, 25 AS ID, 'clpremdo.com' AS M11, 0.0115537201657062 AS M12, 0 AS M13, 'newtab-tv.com' AS M21, 0.00493893930021585 AS M22, 2.0394509834117 AS M23, 'musimundo.com.ar' AS M31, 0.00154309932141752 AS M32, -0.816868393025519 AS M33, '' AS M41, 0 AS M42, 0 AS M43) TMP
             ORDER BY ORD";
    $body_style = array("comma", "text", "progress-bar:1+bold", "percent:1+bold", "text", "progress-bar:1+bold", "percent:1+bold", "text", "progress-bar:1+bold", "percent:1+bold", "text", "progress-bar:1+bold", "percent:1+bold");

    $foot = "SELECT ID, M11, M21, M31, M41
              FROM (SELECT 25 AS ORD, 'Visitas Salientes' AS ID, 200000 AS M11, 320000 AS M21, 430000 AS M31, 36000 AS M41 UNION
                    SELECT 26 AS ORD, 'Dominios' AS ID, 170 AS M11, 142 AS M21, 271 AS M31, 16 AS M41) TMP
              ORDER BY ORD";
    $foot_style = array("text", "comma+col:3", "comma+col:3", "comma+col:3", "comma+col:3");
                  
    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style),
                array("type"=>"foot", "data"=>table_simple($foot), "style"=>$foot_style)
            ));
}


function get_subdominios_tabla($user_id, $tipo) {
    if ($tipo == "Subdominios") {
        $head = array(
                    array("ID", "Musimundo", "Fravega", "Garbarino", "Avenida"),
                    array("Subdominio", "Tráfico", "Subdominio", "Tráfico", "Subdominio", "Tráfico", "Subdominio", "Tráfico")
                );
        $head_style = array(
                          array("text+row:2", "text+col:2", "text+col:2", "text+col:2", "text+col:2"),
                          array("text", "text", "text", "text", "text", "text", "text", "text", "text", "text", "text", "text")
                      );
        
        $body = "SELECT ID, M11, M12, M21, M22, M31, M32, M41, M42
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'musimundo.com' AS M11, 0.622947637542209 AS M12, 'fravega.com' AS M21, 0.99780090463372 AS M22, 'garbarino.com' AS M31, 0.989701558293155 AS M32, 'producto.avenida.com.ar' AS M41, 0.271197447137439 AS M42 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'cybermonday.musimundo.com' AS M11, 0.21305542301844 AS M12, 'manuales.fravega.com' AS M21, 0.00114151800415852 AS M22, '10k.garbarino.com' AS M31, 0.00463479523511975 AS M32, 'ofertas.avenida.com.ar' AS M41, 0.167464198681874 AS M42 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'cybermonday2.musimundo.com' AS M11, 0.058592295771027 AS M12, 'listas.fravega.com' AS M21, 0.00105162221474708 AS M22, 'listas.garbarino.com' AS M31, 0.00244405177881641 AS M32, 'avenida.com.ar' AS M41, 0.154492106271443 AS M42 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'cybermonday1.musimundo.com' AS M11, 0.0526356612490204 AS M12, 'validador.fravega.com' AS M21, 5.95514737419381E-06 AS M22, 'sumate.garbarino.com' AS M31, 0.00101588092746457 AS M32, 'cybermonday.avenida.com.ar' AS M41, 0.105566445581942 AS M42 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'eecheckout.musimundo.com' AS M11, 0.0296129183740715 AS M12, ' ' AS M21, 0 AS M22, 'ventas.garbarino.com' AS M31, 0.000976952636898707 AS M32, 'hogar.avenida.com.ar' AS M41, 0.0808077235958209 AS M42 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'blackfriday.musimundo.com' AS M11, 0.0111047036632643 AS M12, ' ' AS M21, 0 AS M22, 'cac.garbarino.com' AS M31, 0.00039670249838874 AS M32, 'electronica.avenida.com.ar' AS M41, 0.0600830204036786 AS M42 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'eecatalogo.musimundo.com' AS M11, 0.00171147865941304 AS M12, ' ' AS M21, 0 AS M22, 'caci.garbarino.com' AS M31, 0.000297332430656548 AS M32, 'busqueda.avenida.com.ar' AS M41, 0.0545948933342714 AS M42 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'contenidos.musimundo.com' AS M11, 0.00147657962729428 AS M12, ' ' AS M21, 0 AS M22, 'mejoresofertas.garbarino.com' AS M31, 0.000214170007527038 AS M32, 'electrodomesticos.avenida.com.ar' AS M41, 0.038204721039724 AS M42 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'wap.musimundo.com' AS M11, 0.00126718286671258 AS M12, ' ' AS M21, 0 AS M22, 'capacitacion.garbarino.com' AS M31, 0.000135246068232815 AS M32, 'deportes.avenida.com.ar' AS M41, 0.0152391304416156 AS M42 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'loschicos.musimundo.com' AS M11, 0.000885846197740744 AS M12, ' ' AS M21, 0 AS M22, 'm.garbarino.com' AS M31, 0.000133820476964422 AS M32, 'bebes.avenida.com.ar' AS M41, 0.0105657762915288 AS M42 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'wwww.musimundo.com' AS M11, 0.000836531017843637 AS M12, ' ' AS M21, 0 AS M22, 'local.garbarino.com' AS M31, 3.16887478774311E-05 AS M32, 'moda.avenida.com.ar' AS M41, 0.00931233726237416 AS M42 UNION
                       SELECT 11 AS ORD, 12 AS ID, '2fwww.musimundo.com' AS M11, 0.00064037771191075 AS M12, ' ' AS M21, 0 AS M22, 'servicios.garbarino.com' AS M31, 1.58640065198511E-05 AS M32, 'vehiculos.avenida.com.ar' AS M41, 0.00891919998144649 AS M42 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'mochila2.musimundo.com' AS M11, 0.000499126427242812 AS M12, ' ' AS M21, 0 AS M22, 'ux.garbarino.com' AS M31, 1.93689237832821E-06 AS M32, 'cuidadopersonal.avenida.com.ar' AS M41, 0.00627942332851625 AS M42 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'com.musimundo.com' AS M11, 0.000371238718533143 AS M12, '' AS M21, 0 AS M22, ' ' AS M31, 0 AS M32, 'marca.avenida.com.ar' AS M41, 0.00624194949202779 AS M42 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'm.musimundo.com' AS M11, 0.000365767197484055 AS M12, '' AS M21, 0 AS M22, ' ' AS M31, 0 AS M32, 'customerservice.avenida.com.ar' AS M41, 0.00293236998211002 AS M42 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'mochila1.musimundo.com' AS M11, 0.000339433289022554 AS M12, '' AS M21, 0 AS M22, ' ' AS M31, 0 AS M32, 'alimentos.avenida.com.ar' AS M41, 0.00209207346280415 AS M42 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'blogs.musimundo.com' AS M11, 0.000303388854120406 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, 'mascotas.avenida.com.ar' AS M41, 0.00201116471685832 AS M42 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'desafio.musimundo.com' AS M11, 0.000269396260748178 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, 'aniversario.avenida.com.ar' AS M41, 0.00170586155316938 AS M42 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'trineo2.musimundo.com' AS M11, 0.000255658113268121 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, 'kibana.avenida.com.ar' AS M41, 0.000770583546073853 AS M42 UNION
                       SELECT 19 AS ORD, 20 AS ID, 'webmcom010.musimundo.com' AS M11, 0.000243348629391632 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, 'dynamicassets.avenida.com.ar' AS M41, 0.000561721901151438 AS M42 UNION
                       SELECT 20 AS ORD, 21 AS ID, 'webmail.musimundo.com' AS M11, 0.000231912758295194 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, 'hotsale.avenida.com.ar' AS M41, 0.000434327928108166 AS M42 UNION
                       SELECT 21 AS ORD, 22 AS ID, 'hotsale3.musimundo.com' AS M11, 0.000230719033954719 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, 'email.avenida.com.ar' AS M41, 0.000328013945007143 AS M42 UNION
                       SELECT 22 AS ORD, 23 AS ID, 'cybermonday3.musimundo.com' AS M11, 0.000211062688178348 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, 'beneficios.avenida.com.ar' AS M41, 0.000106927906470936 AS M42 UNION
                       SELECT 23 AS ORD, 24 AS ID, 'sorpendete.musimundo.com' AS M11, 0.000175437634744071 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, 'staging.avenida.com.ar' AS M41, 5.45121320269276E-05 AS M42 UNION
                       SELECT 24 AS ORD, 25 AS ID, 'panel.musimundo.com' AS M11, 0.000174263171785047 AS M12, '' AS M21, 0 AS M22, '' AS M31, 0 AS M32, '' AS M41, 0 AS M42) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Organico") {
        $head = array(
                    array("ID", "Musimundo", "Fravega", "Garbarino", "Avenida"),
                    array("Subdominio", "Tráfico", "Subdominio", "Tráfico", "Subdominio", "Tráfico", "Subdominio", "Tráfico")
                );
        $head_style = array(
                          array("text+row:2", "text+col:2", "text+col:2", "text+col:2", "text+col:2"),
                          array("text", "text", "text", "text", "text", "text", "text", "text", "text", "text", "text", "text")
                      );
        
        $body = "SELECT ID, M11, M12, M21, M22, M31, M32, M41, M42
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'tiendeo.com.ar' AS M11, 0.0243610816347688 AS M12, 'garbarino.com' AS M21, 0.0424300416713765 AS M22, 'fravega.com' AS M31, 0.0479663691433571 AS M32, 'formafit.mercadoshops.com.ar' AS M41, 0.0129512869417637 AS M42 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'garbarino.com' AS M11, 0.0213982921121691 AS M12, 'musimundo.com' AS M21, 0.0387527941084056 AS M22, 'tiendeo.com.ar' AS M31, 0.0386140758652587 AS M32, 'avenidacantina.com' AS M41, 0.00927756394979147 AS M42 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'fravega.com' AS M11, 0.0212003801294413 AS M12, 'tiendeo.com.ar' AS M21, 0.0308283749557921 AS M22, 'musimundo.com' AS M31, 0.0348373755709131 AS M32, 'baratometro.com.ar' AS M41, 0.00894519223353215 AS M42 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'compumundo.com.ar' AS M11, 0.018823117559352 AS M12, 'compumundo.com.ar' AS M21, 0.0285757918434843 AS M22, 'compumundo.com.ar' AS M31, 0.0341100079677723 AS M32, 'tiendanaranja.com' AS M41, 0.00780185140088258 AS M42 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'carrefour.com.ar' AS M11, 0.0164452712243921 AS M12, 'celulares.mercadolibre.com.ar' AS M21, 0.0251475637871288 AS M22, 'garbarinocatalogo.com' AS M31, 0.0305537161103475 AS M32, 'megatone.net' AS M41, 0.00777310292177871 AS M42 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'falabella.com.ar' AS M11, 0.014226902667274 AS M12, 'megatone.net' AS M21, 0.0222076520198577 AS M22, 'megatone.net' AS M31, 0.0179804434453352 AS M32, 'ues-drinks.com' AS M41, 0.00714471275236678 AS M42 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'megatone.net' AS M11, 0.0107537269466752 AS M12, 'carrefour.com.ar' AS M21, 0.0208774268881741 AS M22, 'carrefour.com.ar' AS M31, 0.017083951922266 AS M32, 'marianomadrueno.es' AS M41, 0.00638661999200879 AS M42 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'computacion.mercadolibre.com.ar' AS M11, 0.0105572140578961 AS M12, 'falabella.com.ar' AS M21, 0.0178019232417758 AS M22, 'notebooks.mercadolibre.com.ar' AS M31, 0.0150160441335939 AS M32, 'electropuntonet.com' AS M41, 0.00633993826133887 AS M42 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'rodo.com.ar' AS M11, 0.0105198650575349 AS M12, 'idol3.alcatelonetouch.com' AS M21, 0.015245269254005 AS M22, 'falabella.com.ar' AS M31, 0.0130461598135086 AS M32, 'ruedas4x4.com' AS M41, 0.00628117333494079 AS M42 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'cetrogar.com.ar' AS M11, 0.0103382009620248 AS M12, 'tienda.personal.com.ar' AS M21, 0.014983768849659 AS M22, 'rodo.com.ar' AS M31, 0.0122160698185355 AS M32, 'images.ozongo.com' AS M41, 0.0054369551897857 AS M42 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'friv.co' AS M11, 0.0102538857395513 AS M12, 'iguanafix.com.ar' AS M21, 0.0115014681072072 AS M22, 'ribeiro.com.ar' AS M31, 0.0115791351072915 AS M32, 'palaciolicores.com' AS M41, 0.0047957448860376 AS M42 UNION
                       SELECT 11 AS ORD, 12 AS ID, 'juegosdefriv.com.ar' AS M11, 0.00850935722601152 AS M12, 'catalogo.claro.com.co' AS M21, 0.0106739562097231 AS M22, 'iguanafix.com.ar' AS M31, 0.0087164305190461 AS M32, 'reifen4x4.com' AS M41, 0.00475818686285706 AS M42 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'newsearch123.com' AS M11, 0.00804227983217502 AS M12, 'guia.clarin.com' AS M21, 0.00904867359246404 AS M22, 'cetrogar.com.ar' AS M31, 0.00871576528553775 AS M32, 'beaelectronica.com.ar' AS M41, 0.00473157959718905 AS M42 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'ribeiro.com.ar' AS M11, 0.00675792956664959 AS M12, 'smart-gsm.com' AS M21, 0.00844568524560648 AS M22, 'newsearch123.com' AS M31, 0.00772021226104921 AS M32, 'fanstore.com.ar' AS M41, 0.00470677048208555 AS M42 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'iguanafix.com.ar' AS M11, 0.00671884802377475 AS M12, 'garbarinocatalogo.com' AS M21, 0.00755634917837162 AS M22, 'philips.com.ar' AS M31, 0.00716371476362603 AS M32, 'selecto.com.ar' AS M41, 0.00469133745596484 AS M42 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'juegos-friv.com.mx' AS M11, 0.00570734476115504 AS M12, 'motorola.com.ar' AS M21, 0.00597267649586301 AS M22, 'wuignier.com.ar' AS M31, 0.00610389631881693 AS M32, 'surbatdigital.com.ar' AS M41, 0.00466065824135949 AS M42 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'juegosfriv.co' AS M11, 0.0052427434880149 AS M12, 'newsearch123.com' AS M21, 0.00532059060432736 AS M22, 'electropuntonet.com' AS M31, 0.00589897680194586 AS M32, 'www2.launch.online-banking.hsbc.com.ar' AS M41, 0.00465571693088747 AS M42 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'friv2.juegos' AS M11, 0.00385905872078776 AS M12, 'rodo.com.ar' AS M21, 0.00442327893987898 AS M22, 'tuenti.com.ar' AS M31, 0.00527011609106137 AS M32, '9gtzz.fixit.0126.pics' AS M41, 0.00461787610273834 AS M42 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'compucordoba.com.ar' AS M11, 0.00376805335691 AS M12, 'movistar.com.ar' AS M21, 0.00381839668173858 AS M22, 'easy.com.ar' AS M31, 0.00493708929598641 AS M32, 'dataprint.com.ar' AS M41, 0.00454180356825293 AS M42 UNION
                       SELECT 19 AS ORD, 20 AS ID, 'linio.com.co' AS M11, 0.00366074657216993 AS M12, 'cetrogar.com.ar' AS M21, 0.00342368751017163 AS M22, 'lpnk.com.ar' AS M31, 0.00407420643545078 AS M32, 'orientehogar.com.ar' AS M41, 0.00434005214163808 AS M42 UNION
                       SELECT 20 AS ORD, 21 AS ID, 'ebayclassifiedsgroup.com' AS M11, 0.00353398311278329 AS M12, 'tuenti.com.ar' AS M21, 0.00341073201010559 AS M22, 'tienda.personal.com.ar' AS M31, 0.00375810787531366 AS M32, 'hyrmaluf.com.ar' AS M41, 0.00428544681032431 AS M42 UNION
                       SELECT 21 AS ORD, 22 AS ID, 'friv10.com' AS M11, 0.00349724745623804 AS M12, 'search.theanswerfinder.com' AS M21, 0.00339822695081183 AS M22, 'atma.com.ar' AS M31, 0.00373703520741287 AS M32, 'latinosconfba.com' AS M41, 0.00423752568060225 AS M42 UNION
                       SELECT 22 AS ORD, 23 AS ID, '11149-340-117.ampclicks.com' AS M11, 0.00336431468465628 AS M12, 'diaadia.com.ar' AS M21, 0.00332516551937336 AS M22, 'guia.clarin.com' AS M31, 0.0035269599165981 AS M32, 'promomarket.com.ar' AS M41, 0.00422347136280785 AS M42 UNION
                       SELECT 23 AS ORD, 24 AS ID, 'friv4.com.co' AS M11, 0.00319413298411364 AS M12, 'afip.gob.ar' AS M21, 0.00326667024297964 AS M22, 'movistar.com.ar' AS M31, 0.00325610628281649 AS M32, 'nicofarfan1.tumblr.com' AS M41, 0.00422301044309125 AS M42 UNION
                       SELECT 24 AS ORD, 25 AS ID, 'veadigital.com.ar' AS M11, 0.0031508857314887 AS M12, 'iprofesional.com' AS M21, 0.00325789686246151 AS M22, 'todojuegos.cl' AS M31, 0.00314669056731779 AS M32, 'gifsdenaturaleza.blogspot.com.ar' AS M41, 0.0041864904667834 AS M42) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($tipo == "Inorganico") {
        $head = array(
                    array("ID", "Musimundo", "Fravega", "Garbarino", "Avenida"),
                    array("Subdominio", "Tráfico", "Subdominio", "Tráfico", "Subdominio", "Tráfico", "Subdominio", "Tráfico")
                );
        $head_style = array(
                          array("text+row:2", "text+col:2", "text+col:2", "text+col:2", "text+col:2"),
                          array("text", "text", "text", "text", "text", "text", "text", "text", "text", "text", "text", "text")
                      );
        
        $body = "SELECT ID, M11, M12, M21, M22, M31, M32, M41, M42
                 FROM (SELECT 0 AS ORD, 1 AS ID, 'ribeiro.com.ar' AS M11, 0.0189172457861894 AS M12, 'garbarino.com' AS M21, 0.0312370802989112 AS M22, 'ribeiro.com.ar' AS M31, 0.0345247552325763 AS M32, 'electropuntonet.com' AS M41, 0.0561356064142403 AS M42 UNION
                       SELECT 1 AS ORD, 2 AS ID, 'fravega.com' AS M11, 0.0185795481016611 AS M12, 'ribeiro.com.ar' AS M21, 0.0305058237388737 AS M22, 'electropuntonet.com' AS M31, 0.029687865413839 AS M32, 'desillas.com' AS M41, 0.0337119249366684 AS M42 UNION
                       SELECT 2 AS ORD, 3 AS ID, 'megatone.net' AS M11, 0.0166012823225726 AS M12, 'electropuntonet.com' AS M21, 0.0198746890899915 AS M22, 'fravega.com' AS M31, 0.0202223577661177 AS M32, 'garbarino.com' AS M41, 0.0328113779331122 AS M42 UNION
                       SELECT 3 AS ORD, 4 AS ID, 'garbarino.com' AS M11, 0.0131773351895478 AS M12, 'musimundo.com' AS M21, 0.0185468873842694 AS M22, 'cetrogar.com.ar' AS M31, 0.0186410436597416 AS M32, 'ribeiro.com.ar' AS M41, 0.0323195769282144 AS M42 UNION
                       SELECT 4 AS ORD, 5 AS ID, 'electropuntonet.com' AS M11, 0.012047142878482 AS M12, 'cetrogar.com.ar' AS M21, 0.0162288639966023 AS M22, 'electrodomesticos.avenida.com.ar' AS M31, 0.0175928526256229 AS M32, 'sommiercenter.com' AS M41, 0.0262123178056023 AS M42 UNION
                       SELECT 5 AS ORD, 6 AS ID, 'cetrogar.com.ar' AS M11, 0.0117727374243166 AS M12, 'megatone.net' AS M21, 0.014464083373089 AS M22, 'musimundo.com' AS M31, 0.00921276497225846 AS M32, 'kavanag.com.ar' AS M41, 0.0246477146566791 AS M42 UNION
                       SELECT 6 AS ORD, 7 AS ID, 'compumundo.com.ar' AS M11, 0.0108195387704284 AS M12, 'atma.com.ar' AS M21, 0.0136268380343475 AS M22, 'megatone.net' AS M31, 0.00688713968870563 AS M32, 'sodimac.com.ar' AS M41, 0.0230826964310515 AS M42 UNION
                       SELECT 7 AS ORD, 8 AS ID, 'electrodomesticos.avenida.com.ar' AS M11, 0.00942735965542515 AS M12, 'compumundo.com.ar' AS M21, 0.0127018057128339 AS M22, 'atma.com.ar' AS M31, 0.00523351085491023 AS M32, 'simmonsalpublico.com.ar' AS M41, 0.0215368392794705 AS M42 UNION
                       SELECT 8 AS ORD, 9 AS ID, 'movistar.com.ar' AS M11, 0.00599440089443475 AS M12, 'appsec.claro.com.ar' AS M21, 0.0119047969638214 AS M22, 'appsec.claro.com.ar' AS M31, 0.00332743065730264 AS M32, 'dormicentro.com' AS M41, 0.0208249080757612 AS M42 UNION
                       SELECT 9 AS ORD, 10 AS ID, 'storehd.com.ar' AS M11, 0.00468476687066756 AS M12, 'electrodomesticos.avenida.com.ar' AS M21, 0.0101343906387887 AS M22, 'motorola.com.ar' AS M31, 0.00241205850628618 AS M32, 'bmania.com.ar' AS M41, 0.0205825866266097 AS M42 UNION
                       SELECT 10 AS ORD, 11 AS ID, 'motorola.com.ar' AS M11, 0.00391399158286629 AS M12, 'motorola.com.ar' AS M21, 0.00967760315252202 AS M22, 'samsung.com' AS M31, 0.0022656599625737 AS M32, 'bestbuddiesargentina.org' AS M41, 0.0203720235017235 AS M42 UNION
                       SELECT 11 AS ORD, 12 AS ID, 'xtrnotebooks.com.ar' AS M11, 0.00330080544147689 AS M12, 'walmartonline.com.ar' AS M21, 0.00880680138507873 AS M22, 'compumundo.com.ar' AS M31, 0.00218302398661992 AS M32, 'musimundo.com' AS M41, 0.0185275593751706 AS M42 UNION
                       SELECT 12 AS ORD, 13 AS ID, 'atma.com.ar' AS M11, 0.00318631719830774 AS M12, 'lg.com' AS M21, 0.00761691548198396 AS M22, 'siam.com.ar' AS M31, 0.00213057036718775 AS M32, 'fravega.com' AS M41, 0.0164679388647256 AS M42 UNION
                       SELECT 13 AS ORD, 14 AS ID, 'walmartonline.com.ar' AS M11, 0.00312808938078337 AS M12, 'storehd.com.ar' AS M21, 0.00721499276994233 AS M22, 'whirlpoolstore.com.ar' AS M31, 0.00175232662705191 AS M32, 'indformanova.com' AS M41, 0.0161216540539839 AS M42 UNION
                       SELECT 14 AS ORD, 15 AS ID, 'staples.com.ar' AS M11, 0.00297859772467144 AS M12, 'sodimac.com.ar' AS M21, 0.00683306181126917 AS M22, 'movistar.com.ar' AS M31, 0.00165566975100646 AS M32, 'en-sanfernando.com.ar' AS M41, 0.0130663358532298 AS M42 UNION
                       SELECT 15 AS ORD, 16 AS ID, 'appsec.claro.com.ar' AS M11, 0.00293976364277333 AS M12, 'crtecnologia.com.ar' AS M21, 0.00658976441506341 AS M22, 'sanyo.com.ar' AS M31, 0.00160105574425524 AS M32, 'arredo.com.ar' AS M41, 0.0122218269641488 AS M42 UNION
                       SELECT 16 AS ORD, 17 AS ID, 'casadelaudio.com' AS M11, 0.00293947579832194 AS M12, 'noblex.com.ar' AS M21, 0.00595145538703284 AS M22, 'dormicentro.com' AS M31, 0.00156153539765599 AS M32, 'compumundo.com.ar' AS M41, 0.0120684604901779 AS M42 UNION
                       SELECT 17 AS ORD, 18 AS ID, 'coradir.com.ar' AS M11, 0.00292179280084029 AS M12, 'tienda.personal.com.ar' AS M21, 0.00558976590279241 AS M22, 'bidcom.com.ar' AS M31, 0.00148881754985003 AS M32, 'appsec.claro.com.ar' AS M41, 0.0119977668328436 AS M42 UNION
                       SELECT 18 AS ORD, 19 AS ID, 'dellacasaonline.com.ar' AS M11, 0.0028669662309964 AS M12, 'xtrnotebooks.com.ar' AS M21, 0.00548770189045213 AS M22, 'walmartonline.com.ar' AS M31, 0.00126597815722502 AS M32, 'colchonesnoninoni.com' AS M41, 0.011334131504233 AS M42 UNION
                       SELECT 19 AS ORD, 20 AS ID, 'tiendanaranja.com' AS M11, 0.00280680736339777 AS M12, 'samsung.com' AS M21, 0.00500609279227425 AS M22, 'tienda.personal.com.ar' AS M31, 0.00121504964502651 AS M32, 'dhivano.com.ar' AS M41, 0.0112911439076321 AS M42 UNION
                       SELECT 20 AS ORD, 21 AS ID, 'noblex.com.ar' AS M11, 0.00278981520273166 AS M12, 'gelineablanca.com.ar' AS M21, 0.00447589392358749 AS M22, 'sodimac.com.ar' AS M31, 0.00114866139934346 AS M32, 'morshop.com.ar' AS M41, 0.0109364092383372 AS M42 UNION
                       SELECT 21 AS ORD, 22 AS ID, 'bidcom.com.ar' AS M11, 0.00277362144641284 AS M12, 'bidcom.com.ar' AS M21, 0.00414484563364166 AS M22, 'staples.com.ar' AS M31, 0.00110624291033756 AS M32, 'metroblanc.com.ar' AS M41, 0.0109202100947412 AS M42 UNION
                       SELECT 22 AS ORD, 23 AS ID, 'samsung.com' AS M11, 0.00276916627142743 AS M12, 'siam.com.ar' AS M21, 0.00409672750242179 AS M22, 'lg.com' AS M31, 0.00102039878983568 AS M32, 'toolkit.com.ar' AS M41, 0.0104545095148221 AS M42 UNION
                       SELECT 23 AS ORD, 24 AS ID, 'sodimac.com.ar' AS M11, 0.00273403221281634 AS M12, 'buenosairescelu.com' AS M21, 0.00382559238852164 AS M22, 'tiendanaranja.com' AS M31, 0.000966900786991035 AS M32, 'firena.com.ar' AS M41, 0.0102057297025767 AS M42 UNION
                       SELECT 24 AS ORD, 25 AS ID, 'tienda.personal.com.ar' AS M11, 0.00251716615130694 AS M12, 'whirlpool.com.ar' AS M21, 0.00345109086530903 AS M22, 'jlbsrl.com.ar' AS M31, 0.000896121985921792 AS M32, 'hiperaudio.com.ar' AS M41, 0.00982235758717261 AS M42) TMP
                 ORDER BY ORD";
        $body_style = array("comma", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold", "text", "progress-bar:1+bold");

        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$action = isset($_GET['action']) ? strval($_GET['action']) : "";
$user_id = intval($_GET['user']); //no default
$competidor = isset($_GET['competidor']) ? strval($_GET['competidor']) : "";
$tipo = isset($_GET['tipo']) ? strval($_GET['tipo']) : "";

if ($action == "posts") get_posts($user_id);
else if ($action == "test") test();
else if ($action == "trafico_panorama_mensual_tabla") get_trafico_panorama_mensual_tabla($user_id, $tipo);
else if ($action == "trafico_panorama_mensual_indicador") get_trafico_panorama_mensual_indicador($user_id, $tipo);
else if ($action == "trafico_panorama_mensual_anual") get_trafico_panorama_mensual_anual($user_id, $tipo);
else if ($action == "trafico_panorama_mensual_acumulado") get_trafico_panorama_mensual_acumulado($user_id, $tipo);
else if ($action == "trafico_panorama_mensual_tendencia") get_trafico_panorama_mensual_tendencia($user_id, $tipo);
else if ($action == "trafico_acumulado_Generacion_tabla") get_trafico_acumulado_Generacion_tabla($user_id);
else if ($action == "trafico_acumulado_Generacion_indicador") get_trafico_acumulado_Generacion_indicador($user_id);
else if ($action == "trafico_acumulado_Generacion_tendencia") get_trafico_acumulado_Generacion_tendencia($user_id);
else if ($action == "trafico_acumulado_Busquedas_tabla") get_trafico_acumulado_Busquedas_tabla($user_id);
else if ($action == "trafico_acumulado_Busquedas_acumulado") get_trafico_acumulado_Busquedas_acumulado($user_id, $tipo);
else if ($action == "trafico_acumulado_Busquedas_tendencia") get_trafico_acumulado_Busquedas_tendencia($user_id);
else if ($action == "trafico_acumulado_Share_Canal_acumulado") get_trafico_acumulado_Share_Canal_acumulado($user_id, $tipo);
else if ($action == "trafico_acumulado_Share_Canal_b100_acumulado") get_trafico_acumulado_Share_Canal_b100_acumulado($user_id, $tipo);
else if ($action == "trafico_mes_Generacion_tabla") get_trafico_mes_Generacion_tabla($user_id);
else if ($action == "trafico_mes_Generacion_indicador") get_trafico_mes_Generacion_indicador($user_id);
else if ($action == "trafico_mes_Generacion_tendencia") get_trafico_mes_Generacion_tendencia($user_id);
else if ($action == "trafico_mes_Busquedas_tabla") get_trafico_mes_Busquedas_tabla($user_id);
else if ($action == "trafico_mes_Busquedas_acumulado") get_trafico_mes_Busquedas_acumulado($user_id, $tipo);
else if ($action == "trafico_mes_Busquedas_tendencia") get_trafico_mes_Busquedas_tendencia($user_id);
else if ($action == "trafico_tipo_share") get_trafico_tipo_share($user_id, $tipo);
else if ($action == "trafico_tipo_indicador") get_trafico_tipo_indicador($user_id, $tipo);
else if ($action == "trafico_tipo_variacion") get_trafico_tipo_variacion($user_id, $tipo);
else if ($action == "trafico_tipo_tendencia") get_trafico_tipo_tendencia($user_id, $tipo);
else if ($action == "share_trafico_tipo_share_mes_tabla") get_share_trafico_tipo_share_mes_tabla($user_id, $tipo);
else if ($action == "share_trafico_tipo_share_mes_grafico") get_share_trafico_tipo_share_mes_grafico($user_id, $tipo);
else if ($action == "share_trafico_tipo_share_trafico_tabla") get_share_trafico_tipo_share_trafico_tabla($user_id, $tipo);
else if ($action == "share_trafico_tipo_share_trafico_grafico") get_share_trafico_tipo_share_trafico_grafico($user_id, $tipo);
else if ($action == "redes_sociales_tabla") get_redes_sociales_tabla($user_id);
else if ($action == "redes_sociales_b100_grafico") get_redes_sociales_b100_grafico($user_id);
else if ($action == "redes_sociales_grafico") get_redes_sociales_grafico($user_id);
else if ($action == "dominios_tabla") get_dominios_tabla($user_id, $tipo);
else if ($action == "outlinks_tabla") get_outlinks_tabla($user_id);
else if ($action == "subdominios_tabla") get_subdominios_tabla($user_id, $tipo);

//else if ($action == "trafico_tipo_variacion") get_trafico_tipo_variacion($user_id, $tipo);

?>

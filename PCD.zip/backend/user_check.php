<?php

include_once("lib.php");

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_check_login($UID) {
    $query = "SELECT STATUS
              FROM (SELECT 0 AS ORD, 'SUCCESS' AS STATUS FROM TB_USERS WHERE UID='".$UID."' UNION
                    SELECT 1 AS ORD, 'FAILURE' AS STATUS) TMP
              ORDER BY ORD
              LIMIT 1";
             
    to_json(table_simple($query));
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$UID = strval($_GET['UID']);

get_check_login($UID);

?>


--------------------------------------------------------------------------------------------------------------------------------
-- PCD
--------------------------------------------------------------------------------------------------------------------------------

-- DONE
Frontend Graficos + Paginas Dinamicas
* Audiencia
Backend php
* Hardcodeado
Colores por Competidores / Identidad visual
* CSS

--TODO
Frontend Graficos + Paginas Dinamicas
* Nombre Competidores Dinamico
* Estado General - Alertas
* Trafico
* Graficos Responsivo
BBDD
* Tablas
* Vistas
Backend php
* BBDD
* WorldCloud
Colores por Competidores / Identidad visual
* BBDD
Frontend Ingreso datos
Encriptacion usuarios

--------------------------------------------------------------------------------------------------------------------------------
-- HOJAS

Def Value:
    Fecha: ultimo periodo

-- Audiencia

// TODO: Preguntar por los valores amarillos

---- Intereses de la Audiencia (Share y Share b=100)

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Industria (Arte y Entretenimiento, Internet & Telcos, Shoppings, Noticias & Medios, Negocios e industrias, Computer & Electronic)
Segmento (ej. Musica y Audio, Peliculas, Tv y Video, Celebridades y Noticias, Arte, Fotografia, Animación y Comics, Humor)
Periodo
Cantidad (Trafico)

** Grafico de posicionamiento por Industrias y por Competidores

** Cuadro posicionamiento por Industrias entre Competidores por Periodo - variación periodo anterior, promedio entre periodos

---- Que buscan tu audiencia

Industria (Arte y Entretenimiento, Internet & Telcos, Shoppings, Noticias & Medios, Negocios e industrias, Computer & Electronic)
Periodo
Site
Posicion

** Cuadro posicionamiento por Industria

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Industria (Arte y Entretenimiento, Internet & Telcos, Shoppings, Noticias & Medios, Negocios e industrias, Computer & Electronic)
Periodo
Palabra Clave
Posicion

** Word Cloud


-- Audiencia Sitios

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Periodo
Site
Posicion

** Cuadro posicionamiento entre Competidores


-- Gr Audiencia

** Grafico tendencia por Industria por Periodo - promedio por Competidor


-- Gr Audiencia 2

** Grafico share por Industria por Competidor


-- Panorama Mensual

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Indicador (Tráfico total, Tiempo promedio de visitas, Páginas vistas por visita, Abandono, Tráfico Neto)
Periodo
Metrica (Trafico, Tiempo, Paginas, Abandono%, Trafico)

** Cuadro posicionamiento por Indicadores entre Competidores por Periodo - valor, share, variacion mensual

** Semaforos por Indicadores entre Competidores - si arriba del promedio general de promedio y variacion del acumulado y del ultimo mes

** Grafico de dona acumulado por Indicadores entre Competidores

** Grafico de tendencia por Indicadores entre Competidores por Periodo


-- G Trafico Acum

---- Generacion de trafico

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Canal de Ingreso (Directo, Mail, Referidos, Búsquedas, Social, Displays)
Periodo
Cantidad

** Cuadro posicionamiento por Canal de Ingreso entre Competidores - valor, share propio, share mercado, promedio por canal

** Semaforos por Canal entre Competidores - si arriba del promedio general de share mercado

** Grafico columnas por Canal entre Competidores + promedio

** Grafico de dona por Canal entre Competidores - share acumulado

** Grafico de dona por Canal entre Competidores - share propio

---- Tipo de trafico

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Tipo de Grafico (Orgánico, Inorgánico)
Periodo
Cantidad

** Cuadro posicionamiento por Tipo entre Competidores - valor, share propio, share mercado, promedio por tipo

** Grafico de dona por Tipo entre Competidores - share acumulado

** Grafico columnas por Tipo entre Competidores + promedio


-- G Trafico Mes

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Canal de Ingreso (Directo, Mail, Referidos, Búsquedas, Social, Displays)
Periodo
Cantidad

** Cuadro posicionamiento por Canal de Ingreso entre Competidores - valor, share propio, share mercado, promedio por canal

** Semaforos por Canal entre Competidores - si arriba del promedio general de share mercado

** Grafico columnas por Canal entre Competidores + promedio

---- Tipo de trafico

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Tipo de Trafico (Orgánico, Inorgánico)
Periodo
Cantidad

** Cuadro posicionamiento por Tipo entre Competidores - valor, share propio, share mercado, promedio por tipo

** Grafico de dona por Tipo entre Competidores - share acumulado

** Grafico columnas por Tipo entre Competidores + promedio


-- T Trafico

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Categoria de Trafico (Referidos, Búsquedas, Búsquedas Orgánica, Búsquedas Inorgánica, Redes Sociales, Displays)
Periodo
Cantidad

** Cuadro posicionamiento por Categoria entre Competidores por Periodo - valor, share propio

** Cuadro posicionamiento por Categoria entre Competidores por Periodo - valor, share mercado, variacion mensual

** Semaforos por Categoria entre Competidores por Periodo - si arriba del promedio general de share mercado

** Grafico de tendencia por Categoria entre Competidores por Periodo

** Cuadro posicionamiento por Categoria entre Competidores por Periodo - share mercado

** Grafico de columnas por Categoria entre Competidores por Periodo - share mercado

** Cuadro posicionamiento por Categoria entre Competidores por Periodo - share propio

** Grafico de columnas por Categoria entre Competidores por Periodo - share propio


-- T Anual

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Indicador (Tráfico total, Tiempo promedio de visitas, Páginas vistas por visita, Abandono, Tráfico Neto)
Periodo
Metrica (Trafico, Tiempo, Paginas, Abandono%, Trafico)

** Cuadro posicionamiento por Indicadores entre Competidores por Periodo - valor, share, variacion interanual, total, promedio


-- Redes Sociales

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Red Social (Facebook, YouTube, Twitter, Reddit, Otros)
Periodo
Cantidad

** Grafico de columnas por Red Social entre Competidores - share general + b=100

** Grafico de columnas por Red Social entre Competidores - share red social


-- Comparativos

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Origen (Referidos, Orgánicas, Inorgánicas, Social, Ad Net, Publisher)
Periodo
Domino
Cantidad

** Cuadro posicionamiento por Origen y Dominio entre Competidores - valor, share


-- Outlinks

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Periodo
Domino
Cantidad

** Cuadro posicionamiento por Origen y Dominio entre Competidores - share, variacion


-- Subdominios

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Periodo
Subdomino
Cantidad

** Cuadro posicionamiento por Origen y Dominio entre Competidores - share


-- Com Org (Organico)

// TODO: Preguntar calculo Afinidad

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Periodo
Domino
Cantidad

** Cuadro posicionamiento por Origen y Dominio entre Competidores - share


-- Com Inor (Inorganico)

// TODO: Preguntar calculo Afinidad

Competidor (Musimundo, Fravega, Garbarino, Avenida, Resto)
Periodo
Domino
Cantidad

** Cuadro posicionamiento por Origen y Dominio entre Competidores - share


--------------------------------------------------------------------------------------------------------------------------------

-- Table: users

-- DROP TABLE users;

CREATE TABLE users
(
  user_id integer NOT NULL,
  user_name text,
  user_pass text,
  CONSTRAINT pk_users PRIMARY KEY (user_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE users
  OWNER TO pcd;

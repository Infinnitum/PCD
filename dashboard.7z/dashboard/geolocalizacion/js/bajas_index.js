
var T_STORE_CAN = 0;
var STORE_CAN = 0;
var T_QTY = 0;
var QTY = 0;

var width = 250, height = 175;


$("#left-list-btn").click(function() {
    animateLeftSidebar();
    return false;
});

$("#right-list-btn").click(function() {
    animateRightSidebar();
    return false;
});

function animateLeftSidebar() {
    $("#left-sidebar").animate({
        width: "toggle"
    }, 350, function() {
        map.invalidateSize();
    });
}

$("#right-sidebar-toggle-btn").click(function() {
    animateSidebar();
    return false;
});

$("#right-sidebar-hide-btn").click(function() {
    animateSidebar();
    return false;
});

function animateRightSidebar() {
    $("#right-sidebar").animate({
        width: "toggle"
    }, 350, function() {
        map.invalidateSize();
    });
}

function leftsidebarClick(id) {
    var layer = markerClusters.getLayer(id);
    map.setView([layer.getLatLng().lat, layer.getLatLng().lng], 17);
    layer.fire("click");
    /* Hide sidebar and go to the map on small screens */
    if (document.body.clientWidth <= 767) {
        $("#leftsidebar").hide();
        map.invalidateSize();
    }
}

function rightsidebarClick(id) {
    var layer = markerClusters.getLayer(id);
    map.setView([layer.getLatLng().lat, layer.getLatLng().lng], 17);
    layer.fire("click");
    /* Hide sidebar and go to the map on small screens */
    if (document.body.clientWidth <= 767) {
        $("#rightsidebar").hide();
        map.invalidateSize();
    }
}



var map, featureList, index;

var now = Date.now();

var mapbox = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: '',
    maxZoom: 18,
    id: 'mapbox.streets-basic',
    accessToken: 'pk.eyJ1IjoiaW5maW5uaXR1bSIsImEiOiJjaXNkejZwMnQwMDltMnRydGJvODZldnN6In0.lF3t96xrVEORbrytfp0zYg'
});

map = L.map("map", {
    zoom: 10,
    center: [-34.61772, -58.42516],
    layers: [mapbox],
    zoomControl: false,
    attributionControl: false
});

var zoomControl = L.control.zoom().addTo(map);

/*
var map = L.map('map').setView([0, 0], 2);

L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
*/

function onEachFeature(feature, layer) {
    var popupContent = "<div style=\"width: 200px; height: 200px;\"><b>" + feature.properties.N + "</b></div>";

    //T_STORE_CAN = T_STORE_CAN + 1;
    /*
    P0MES_TRX = P0MES_TRX + +store.feature.properties.M0T;
    P0MES_VOL = P0MES_VOL + +store.feature.properties.M0V;
    P0MES_ARA = P0MES_ARA + +store.feature.properties.M0A;
    P1MES_TRX = P1MES_TRX + +store.feature.properties.M1T;
    P1MES_VOL = P1MES_VOL + +store.feature.properties.M1V;
    P1MES_ARA = P1MES_ARA + +store.feature.properties.M1A;
    P2MES_TRX = P2MES_TRX + +store.feature.properties.M2T;
    P2MES_VOL = P2MES_VOL + +store.feature.properties.M2V;
    P2MES_ARA = P2MES_ARA + +store.feature.properties.M2A;
    P3MES_TRX = P3MES_TRX + +store.feature.properties.M3T;
    P3MES_VOL = P3MES_VOL + +store.feature.properties.M3V;
    P3MES_ARA = P3MES_ARA + +store.feature.properties.M3A;
    P4MES_TRX = P4MES_TRX + +store.feature.properties.M4T;
    P4MES_VOL = P4MES_VOL + +store.feature.properties.M4V;
    P4MES_ARA = P4MES_ARA + +store.feature.properties.M4A;
    P5MES_TRX = P5MES_TRX + +store.feature.properties.M5T;
    P5MES_VOL = P5MES_VOL + +store.feature.properties.M5V;
    P5MES_ARA = P5MES_ARA + +store.feature.properties.M5A;
    */
    
    layer.on({
        click: function (e) {
        
            if (feature.id) {
                //usage:
                //alert("../data/cuit/" + feature.id);
                readTextFile("/data/cuit/" + feature.id + ".json", function(text){
                    var store = JSON.parse(text);
                    M0T = store.M0T;
                    M0V = store.M0V;
                    M0A = store.M0A;
                    M1T = store.M1T;
                    M1V = store.M1V;
                    M1A = store.M1A;
                    M2T = store.M2T;
                    M2V = store.M2V;
                    M2A = store.M2A;
                    M3T = store.M3T;
                    M3V = store.M3V;
                    M3A = store.M3A;
                    M4T = store.M4T;
                    M4V = store.M4V;
                    M4A = store.M4A;
                    M5T = store.M5T;
                    M5V = store.M5V;
                    M5A = store.M5A;
                
                    document.getElementById('Nombre').innerHTML = /*feature.id*/ feature.properties.N;
                    document.getElementById('Fantasia').innerHTML = feature.properties.F;
                    document.getElementById('Performance').innerHTML = feature.properties.RE;
                    document.getElementById('Banco').innerHTML = feature.properties.A;
                    document.getElementById('Rubro').innerHTML = feature.properties.R;

                    document.getElementById('Terminales').innerHTML = (feature.properties.T == '0' ? '-' : feature.properties.T);
                    document.getElementById('Posnet').innerHTML = (feature.properties.S == '0' ? '-' : feature.properties.S);
                    document.getElementById('Lapos').innerHTML = (feature.properties.L == '0' ? '-' : feature.properties.L);
                    document.getElementById('Ecommerce').innerHTML = (feature.properties.C == '0' ? '-' : feature.properties.C);
                    document.getElementById('Otros').innerHTML = (feature.properties.O == '0' ? '-' : feature.properties.O);
                    document.getElementById('Debito').innerHTML = (feature.properties.B == '0' ? '&#10008;' : '&#10004;');
                    
                    nv.addGraph(function() {
                        d3.select('#coT svg > *').remove();
                        coT = nv.models.multiBarHorizontalChart()
                            .x(function(d) { return d.label })
                            .y(function(d) { return d.value })
                            .barColor(d3.scale.category20().range())
                            .duration(550)
                            .margin({left: 75, right: 50})
                            .showControls(false)
                            .showValues(true)
                            .width(width)
                            .height(height);
                        coT.yAxis.tickFormat(d3.format(',.0d'));
                        coT.xAxis.axisLabel('Trx').axisLabelDistance(5);
                        d3.select('#coT svg')
                            .datum([{key: "Trx / K",
                                     values: [
                                         {"label" : "Abr", "value" : (isNaN(Number(M5T)) ? 0 : Number(M5T))},
                                         {"label" : "May", "value" : (isNaN(Number(M4T)) ? 0 : Number(M4T))},
                                         {"label" : "Jun", "value" : (isNaN(Number(M3T)) ? 0 : Number(M3T))},
                                         {"label" : "Jul", "value" : (isNaN(Number(M2T)) ? 0 : Number(M2T))},
                                         {"label" : "Ago", "value" : (isNaN(Number(M1T)) ? 0 : Number(M1T))},
                                         {"label" : "Sep", "value" : (isNaN(Number(M0T)) ? 0 : Number(M0T))}
                                     ]}])
                            .call(coT)
                            .style({ 'width': width, 'height': height });
                        nv.utils.windowResize(coT.update);
                        return coT;
                    });
                    
                    nv.addGraph(function() {
                        d3.select('#coV svg > *').remove();
                        coV = nv.models.multiBarHorizontalChart()
                            .x(function(d) { return d.label })
                            .y(function(d) { return d.value })
                            .barColor(d3.scale.category20().range())
                            .duration(550)
                            .margin({left: 75, right: 50})
                            .showControls(false)
                            .showValues(true)
                            .width(width)
                            .height(height);
                        coV.yAxis.tickFormat(d3.format(',.0d'));
                        coV.xAxis.axisLabel('Volumen').axisLabelDistance(5);
                        d3.select('#coV svg')
                            .datum([{key: "Volumen / K",
                                     values: [
                                         {"label" : "Abr", "value" : (isNaN(Number(M5V)) ? 0 : Number(M5V))},
                                         {"label" : "May", "value" : (isNaN(Number(M4V)) ? 0 : Number(M4V))},
                                         {"label" : "Jun", "value" : (isNaN(Number(M3V)) ? 0 : Number(M3V))},
                                         {"label" : "Jul", "value" : (isNaN(Number(M2V)) ? 0 : Number(M2V))},
                                         {"label" : "Ago", "value" : (isNaN(Number(M1V)) ? 0 : Number(M1V))},
                                         {"label" : "Sep", "value" : (isNaN(Number(M0V)) ? 0 : Number(M0V))}
                                     ]}])
                            .call(coV)
                            .style({ 'width': width, 'height': height });
                        nv.utils.windowResize(coV.update);
                        //coV.update;
                        return coV;
                    });

                    nv.addGraph(function() {
                        d3.select('#coA svg > *').remove();
                        coA = nv.models.multiBarHorizontalChart()
                            .x(function(d) { return d.label })
                            .y(function(d) { return d.value })
                            .barColor(d3.scale.category20().range())
                            .duration(550)
                            .margin({left: 75, right: 50})
                            .showControls(false)
                            .showValues(true)
                            .width(width)
                            .height(height);
                        coA.yAxis.tickFormat(d3.format(',.0d'));
                        coA.xAxis.axisLabel('Arancel').axisLabelDistance(5);
                        d3.select('#coA svg')
                            .datum([{key: "Arancel / K",
                                     values: [
                                         {"label" : "Abr", "value" : (isNaN(Number(M5A)) ? 0 : Number(M5A))},
                                         {"label" : "May", "value" : (isNaN(Number(M4A)) ? 0 : Number(M4A))},
                                         {"label" : "Jun", "value" : (isNaN(Number(M3A)) ? 0 : Number(M3A))},
                                         {"label" : "Jul", "value" : (isNaN(Number(M2A)) ? 0 : Number(M2A))},
                                         {"label" : "Ago", "value" : (isNaN(Number(M1A)) ? 0 : Number(M1A))},
                                         {"label" : "Sep", "value" : (isNaN(Number(M0A)) ? 0 : Number(M0A))}
                                     ]}])
                            .call(coA)
                            .style({ 'width': width, 'height': height });
                        //coA.update;
                        nv.utils.windowResize(coA.update);
                        return coA;
                    });

                    nv.addGraph(function() {
                        d3.select('#coE svg > *').remove();
                        coE = nv.models.pieChart()
                            .x(function(d) { return d.label })
                            .y(function(d) { return d.value })
                            .showLabels(true)
                            .labelThreshold(.05)
                            .labelType("percent")
                            .donut(true)
                            .donutRatio(0.35)
                            .width(width)
                            .height(height);
                        d3.select('#coE svg')
                            .datum([{"label": "Posnet", "value" : (isNaN(Number(feature.properties.S)) ? 0 : Number(feature.properties.S))},
                                    {"label": "Lapos", "value" : (isNaN(Number(feature.properties.L)) ? 0 : Number(feature.properties.L))},
                                    {"label": "Otros Dueños", "value" : (isNaN(Number(feature.properties.O)) ? 0 : Number(feature.properties.O))},
                                    {"label": "eCommerce", "value" : (isNaN(Number(feature.properties.C)) ? 0 : Number(feature.properties.C))}
                                   ])
                            .call(coE)
                            .style({ 'width': width, 'height': height });
                        //ter.update;
                        nv.utils.windowResize(coE.update);
                        return coE;
                    });
                    
                    $("#featureModal").modal("show");
                });
            }
        }
    });

    //layer.bindPopup(popupContent);
}

var markers = L.geoJson(null, {
    onEachFeature: onEachFeature,
    pointToLayer: createClusterIcon
}).addTo(map);


function createClusterIcon(feature, latlng) {
    if (!feature.properties.cluster) return L.marker(latlng);

    var count = feature.properties.sum; //feature.properties.point_count;
    var size =
        count < 10 ? 'small' :
        count < 100 ? 'medium' :
        count < 1000 ? 'large' :
        count < 10000 ? 'xlarge' :
        count < 100000 ? 'xxlarge' : 'ultra';
        
    var abbrev = count >= 10000 ? Math.round(count / 1000) + 'k' :
                 count >= 1000 ? (Math.round(count / 100) / 10) + 'k' : count;
                 
    var icon = L.divIcon({
        //html: '<div><span>' + feature.properties.point_count_abbreviated + '</span></div>',
        html: '<div><span>' + abbrev + '</span></div>',
        className: 'marker-cluster marker-cluster-' + size,
        iconSize: L.point(40, 40)
    });
    return L.marker(latlng, {icon: icon});
};


function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("application/json");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    }
    rawFile.send(null);
}

function getJSON(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.setRequestHeader('Accept', 'application/json');
            
    xhr.onload = function () {
        //console.log(url + " " + xhr.readyState + " " + xhr.status + " " + xhr.response);
        if (xhr.readyState === 4 && xhr.status >= 200 && xhr.status < 300 && xhr.response) {
            callback(xhr.response);
        }
    };
    xhr.send();
}


function update() {
    var bounds = map.getBounds();
    markers.clearLayers();
    
    console.log(bounds);
    markers.addData(index.getClusters([bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()], map.getZoom()));
    //console.log(url + " " + xhr.readyState + " " + xhr.status + " " + xhr.response);
        
    markers.eachLayer(function (layer) {
          if (layer.feature.properties.cluster) {
                layer.on('click', function() {
                    map.setView(layer.getLatLng(), map.getZoom() + 1);
                });
          }
    });
        
    $("#loading").hide();
};


function totalesrefresh() {

    getJSON('/data/Bajas_total.json', function (geojson_raw) {

        var geojson = geojson_raw;
        
        geojson = geojson_raw.filter(function (row) {
            return ((row.RUBRO == document.getElementById("filtro_rubro").value ||
                     document.getElementById("filtro_rubro").value == 'all') &&
                    (row.PERFORMANCE == document.getElementById("filtro_performance").value ||
                     document.getElementById("filtro_performance").value == 'all') &&
                    (row.PAYMENT_WAY == document.getElementById("filtro_pago").value ||
                     document.getElementById("filtro_pago").value == 'all') &&
                    (row.GROUP_NAME == document.getElementById("filtro_canal").value ||
                     document.getElementById("filtro_canal").value == 'all'));
        });

        STORE_CAN = 0;
        QTY = 0;
        
        var i;
        
        for (i = 0; i < geojson.length; i++) {
            STORE_CAN += Number(geojson[i].CUIT);
            QTY += Number(geojson[i].QTY);
        }
        
        if (T_STORE_CAN == 0) T_STORE_CAN = STORE_CAN;
        if (T_QTY == 0) T_QTY = QTY;
    
        document.getElementById('Comercios').innerHTML = STORE_CAN;
        document.getElementById('T_Comercios').innerHTML = T_STORE_CAN;
        document.getElementById('P_Comercios').innerHTML = (STORE_CAN / T_STORE_CAN * 100).toFixed(2);
        
        document.getElementById('Reclamos').innerHTML = QTY;
        document.getElementById('T_Reclamos').innerHTML = T_QTY;
        document.getElementById('P_Reclamos').innerHTML = (QTY / T_QTY * 100).toFixed(2);

    });
}


function handlefiltros() {
    $("#loading").show();
    start_data();
    totalesrefresh();
};



function start_data() {
    var geojson0 = clone(pointData0);
    geojson0.features = geojson0.features.filter(function (row) {
        return ((row.properties.R == document.getElementById("filtro_rubro").value ||
                 document.getElementById("filtro_rubro").value == 'all') &&
                (row.properties.RE == document.getElementById("filtro_performance").value ||
                 document.getElementById("filtro_performance").value == 'all') &&
                (row.properties.P == document.getElementById("filtro_pago").value ||
                 document.getElementById("filtro_pago").value == 'all') &&
                (row.properties.G == document.getElementById("filtro_canal").value ||
                 document.getElementById("filtro_canal").value == 'all'));
    });
    
    index = supercluster({
        log: true,
        radius: 60,
        extent: 256,
        maxZoom: 16,
        initial: function () { return {count: 0, sum: 0}; },
        map: function (properties) { return {count: 1, sum: Number(properties.Q)}; },
        reduce: function (accumulated, properties) { accumulated.sum += properties.sum; accumulated.count += properties.count; }
    }).load(geojson0.features);
    
    update();
};

start_data();

totalesrefresh();

document.getElementById("filtro_rubro").addEventListener("change", handlefiltros, false);
document.getElementById("filtro_performance").addEventListener("change", handlefiltros, false);
document.getElementById("filtro_pago").addEventListener("change", handlefiltros, false);
document.getElementById("filtro_canal").addEventListener("change", handlefiltros, false);

map.on('moveend', update);




function clone(obj) {
    var copy;

    // Handle the 3 simple types, and null or undefined
    if (null == obj || "object" != typeof obj) return obj;

    // Handle Date
    if (obj instanceof Date) {
        copy = new Date();
        copy.setTime(obj.getTime());
        return copy;
    }

    // Handle Array
    if (obj instanceof Array) {
        copy = [];
        for (var i = 0, len = obj.length; i < len; i++) {
            copy[i] = clone(obj[i]);
        }
        return copy;
    }

    // Handle Object
    if (obj instanceof Object) {
        copy = {};
        for (var attr in obj) {
            if (obj.hasOwnProperty(attr)) copy[attr] = clone(obj[attr]);
        }
        return copy;
    }

    throw new Error("Unable to copy obj! Its type isn't supported.");
}
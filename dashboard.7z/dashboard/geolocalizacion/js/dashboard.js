
$(document).ready(function() {
    NProgress.start();

    init_sidebar();
    NProgress.inc();

    NProgress.done();
    
    $('body').scrollspy({ target: '#sidebar-menu' });
});


function getJSON(url, success) {
    $.ajax({
        url: url,
        dataType: "json",
        success: success
    });
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getCookie() {
    var cookie_name = "PCD";
    var return_value = null;

    var pos_start = document.cookie.indexOf(cookie_name + "=");

    if (pos_start != -1) { // Cookie already set, read it
        pos_start = pos_start + cookie_name.length + 1; // Start reading 1 character after
        var pos_end = document.cookie.indexOf(";", pos_start); // Find ";" after the start position

        if (pos_end == -1) pos_end = document.cookie.length;
        return_value = unescape( document.cookie.substring(pos_start, pos_end) );
    }

    return return_value; // null if cookie doesn't exist, string otherwise
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var value = getCookie();

if (value != null) {
    var url = "backend/user_check.php?UID="+value;
    
    getJSON(url,
            function(result) {
                if (result[0].STATUS != "SUCCESS") {
                    window.location.href = 'login.html';
                }
            });
}
else {
    window.location.href = 'login.html';
}


<?php

include_once("lib.php");

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_check_login($user, $pass) {
/*
    $query = "SELECT USER_ID, 'Sebastian Lancman' AS USER_NAME, 'SUCCESS' AS STATUS
              FROM (SELECT 1 AS USER_ID) TMP";

    $query = "SELECT USER_ID, USER_NAME, STATUS
              FROM (SELECT USER_ID, 'SUCCESS' AS STATUS FROM TB_USERS WHERE USER_NAME='".$user."' AND PASS='".$pass."' UNION
                    SELECT -1, 'FAILURE' AS STATUS) TMP
              ORDER BY USER_ID DESC
              LIMIT 1";
*/
    $query = "SELECT USER_ID, USER_NAME, STATUS
              FROM (SELECT USER_ID, USER_NAME, 'SUCCESS' AS STATUS FROM TB_USERS WHERE USER_ID=1 UNION
                    SELECT -1, '' AS USER_NAME, 'FAILURE' AS STATUS) TMP
              ORDER BY USER_ID DESC
              LIMIT 1";

    $table = table_simple($query)[0];
    $status = $table["STATUS"];
    $user_id = $table["USER_ID"];
    $user_name = $table["USER_NAME"];
    $uid = md5(uniqid($user_id, true));
/*
    if ($status == "SUCCESS") {
        $update = "UPDATE TB_USERS SET UID='".$uid."' WHERE USER_ID=".$user_id;
        table_query($update);
    }
*/
    to_json(Array("USER_ID" => $uid, "USER_NAME" => $user_name, "STATUS" => $status));
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

//$user = intval($_GET['user']);
//$pass = intval($_GET['pass']);
$user = strval($_GET['user']);
$pass = strval($_GET['pass']);

get_check_login($user, $pass);

?>

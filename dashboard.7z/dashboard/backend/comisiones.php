<?php

include_once("lib.php");
/*
// Ejemplo
function get_posts($user_id) {
	$query = "SELECT post_title, guid FROM (SELECT 'pepe1' as post_title, 1 as guid union SELECT 'pepe2' as post_title, 2 as guid union SELECT 'pepe3' as post_title, 3 as guid) tmp ORDER BY guid DESC";

    $result = dataset($query);

	$posts = array();
	if(mysql_num_rows($result)) {
		while($post = mysql_fetch_assoc($result)) {
			$posts[] = array('post'=>$post);
		}
	}

    to_json(array('posts'=>$posts));
}
*/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_Performance_Vendedor_total($user_id, $canal, $metrica) {
    if ($canal == "Canal_Directo_Norte") {
        if ($metrica == 1) {
            $query = "SELECT 'YELLOW' AS container_class, '95%' AS CUMP, '5 / 12' AS C100";
        }
        else if ($metrica == 2) {
            $query = "SELECT 'RED' AS container_class, '42%' AS CUMP, '5 / 12' AS C100";
        }
        else if ($metrica == 3) {
            $query = "SELECT 'RED' AS container_class, '87%' AS CUMP, '4 / 12' AS C100";
        }
        else if ($metrica == 4) {
            $query = "SELECT 'YELLOW' AS container_class, '95%' AS CUMP, '5 / 12' AS C100";
        }
    }
    else if ($canal == "Canal_Directo_Sur") {
        if ($metrica == 1) {
            $query = "SELECT 'RED' AS container_class, '89%' AS CUMP, '3 / 11' AS C100";
        }
        else if ($metrica == 2) {
            $query = "SELECT 'RED' AS container_class, '27%' AS CUMP, '3 / 11' AS C100";
        }
        else if ($metrica == 3) {
            $query = "SELECT 'YELLOW' AS container_class, '92%' AS CUMP, '5 / 11' AS C100";
        }
        else if ($metrica == 4) {
            $query = "SELECT 'RED' AS container_class, '88%' AS CUMP, '4 / 11' AS C100";
        }
    }
    else if ($canal == "Telemarketing") {
        if ($metrica == 1) {
            $query = "SELECT 'YELLOW' AS container_class, '91%' AS CUMP, '5 / 14' AS C100";
        }
        else if ($metrica == 2) {
            $query = "SELECT 'YELLOW' AS container_class, '92%' AS CUMP, '5 / 14' AS C100";
        }
        else if ($metrica == 3) {
            $query = "SELECT 'YELLOW' AS container_class, '98%' AS CUMP, '7 / 14' AS C100";
        }
    }
    else if ($canal == "Canal_Digital") {
        if ($metrica == 1) {
            $query = "SELECT 'GREEN' AS container_class, '169%' AS CUMP, '2 / 2' AS C100";
        }
        else if ($metrica == 2) {
            $query = "SELECT 'GREEN' AS container_class, '129%' AS CUMP, '2 / 2' AS C100";
        }
    }
    else if ($canal == "Account_GBS") {
        if ($metrica == 1) {
            $query = "SELECT 'YELLOW' AS container_class, '90%' AS CUMP, '1 / 4' AS C100";
        }
        else if ($metrica == 2) {
            $query = "SELECT 'GREEN' AS container_class, '103%' AS CUMP, '3 / 4' AS C100";
        }
        else if ($metrica == 3) {
            $query = "SELECT 'RED' AS container_class, '50%' AS CUMP, '2 / 4' AS C100";
        }
        else if ($metrica == 4) {
            $query = "SELECT 'GREEN' AS container_class, '102%' AS CUMP, '3 / 4' AS C100";
        }
    }
    else if ($canal == "Account_GFS") {
        if ($metrica == 1) {
            $query = "SELECT 'RED' AS container_class, '89%' AS CUMP, '1 / 4' AS C100";
        }
        else if ($metrica == 2) {
            $query = "SELECT 'RED' AS container_class, '50%' AS CUMP, '2 / 4' AS C100";
        }
        else if ($metrica == 3) {
            $query = "SELECT 'YELLOW' AS container_class, '94%' AS CUMP, '3 / 4' AS C100";
        }
        else if ($metrica == 4) {
            $query = "SELECT 'YELLOW' AS container_class, '99%' AS CUMP, '2 / 4' AS C100";
        }
    }

    to_json(table_simple($query));
}

function get_Performance_Vendedor_detalle($user_id, $canal) {
    if ($canal == "Canal_Directo_Norte") {
        $query = "SELECT VENDEDOR, row_class, M1_MES, M1_OBJ, M1_CUMP, M1_PASS, M2_MES, M2_OBJ, M2_CUMP, M2_PASS, M3_MES, M3_OBJ, M3_CUMP, M3_PASS, M4_MES, M4_OBJ, M4_CUMP, M4_PASS, PAGO
                  FROM (SELECT 1 AS ORD, 'DATA' AS row_class, 'CARAMELO EZEQUIEL' AS VENDEDOR, 25 AS M1_MES, 29 AS M1_OBJ, '86%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 17 AS M3_MES, 15 AS M3_OBJ, '113%' AS M3_CUMP, 'GREEN' AS M3_PASS, 33 AS M4_MES, 33 AS M4_OBJ, '100%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 2 AS ORD, 'DATA' AS row_class, 'CUELLO LUCAS JUAN' AS VENDEDOR, 29 AS M1_MES, 29 AS M1_OBJ, '100%' AS M1_CUMP, 'GREEN' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 14 AS M3_MES, 15 AS M3_OBJ, '93%' AS M3_CUMP, 'GREEN' AS M3_PASS, 33 AS M4_MES, 33 AS M4_OBJ, '100%' AS M4_CUMP, 'GREEN' AS M4_PASS, 1 AS PAGO UNION
                        SELECT 3 AS ORD, 'DATA' AS row_class, 'GARCIA SOFIA' AS VENDEDOR, 33 AS M1_MES, 29 AS M1_OBJ, '114%' AS M1_CUMP, 'GREEN' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 17 AS M3_MES, 15 AS M3_OBJ, '113%' AS M3_CUMP, 'GREEN' AS M3_PASS, 27 AS M4_MES, 33 AS M4_OBJ, '82%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 4 AS ORD, 'DATA' AS row_class, 'GOMEZ LUIS EMANUEL ' AS VENDEDOR, 32 AS M1_MES, 29 AS M1_OBJ, '110%' AS M1_CUMP, 'GREEN' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 10 AS M3_MES, 15 AS M3_OBJ, '67%' AS M3_CUMP, 'RED' AS M3_PASS, 38 AS M4_MES, 33 AS M4_OBJ, '115%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 5 AS ORD, 'DATA' AS row_class, 'HARTFIEL MARIA ELENA' AS VENDEDOR, 26 AS M1_MES, 29 AS M1_OBJ, '90%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 16 AS M3_MES, 15 AS M3_OBJ, '107%' AS M3_CUMP, 'GREEN' AS M3_PASS, 31 AS M4_MES, 33 AS M4_OBJ, '94%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 6 AS ORD, 'DATA' AS row_class, 'LAMANNA LUCAS DAMIAN' AS VENDEDOR, 22 AS M1_MES, 29 AS M1_OBJ, '76%' AS M1_CUMP, 'RED' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 11 AS M3_MES, 15 AS M3_OBJ, '73%' AS M3_CUMP, 'RED' AS M3_PASS, 36 AS M4_MES, 33 AS M4_OBJ, '109%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 7 AS ORD, 'DATA' AS row_class, 'LO CASCIO GERMAN JAVIER ' AS VENDEDOR, 25 AS M1_MES, 29 AS M1_OBJ, '86%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 12 AS M3_MES, 15 AS M3_OBJ, '80%' AS M3_CUMP, 'GREEN' AS M3_PASS, 26 AS M4_MES, 33 AS M4_OBJ, '79%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 8 AS ORD, 'DATA' AS row_class, 'MARTINEZ FERNANDO URIEL' AS VENDEDOR, 22 AS M1_MES, 29 AS M1_OBJ, '76%' AS M1_CUMP, 'RED' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 11 AS M3_MES, 15 AS M3_OBJ, '73%' AS M3_CUMP, 'RED' AS M3_PASS, 39 AS M4_MES, 33 AS M4_OBJ, '118%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 9 AS ORD, 'DATA' AS row_class, 'MORALES ANTUÑA MILAGROS' AS VENDEDOR, 27 AS M1_MES, 29 AS M1_OBJ, '93%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 11 AS M3_MES, 15 AS M3_OBJ, '73%' AS M3_CUMP, 'RED' AS M3_PASS, 32 AS M4_MES, 33 AS M4_OBJ, '97%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 10 AS ORD, 'DATA' AS row_class, 'RIQUELME MATIAS' AS VENDEDOR, 21 AS M1_MES, 29 AS M1_OBJ, '72%' AS M1_CUMP, 'RED' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 16 AS M3_MES, 15 AS M3_OBJ, '107%' AS M3_CUMP, 'GREEN' AS M3_PASS, 25 AS M4_MES, 33 AS M4_OBJ, '76%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 11 AS ORD, 'DATA' AS row_class, 'SANSBERRO NEHUEN DANIEL ' AS VENDEDOR, 34 AS M1_MES, 29 AS M1_OBJ, '117%' AS M1_CUMP, 'GREEN' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 11 AS M3_MES, 15 AS M3_OBJ, '73%' AS M3_CUMP, 'RED' AS M3_PASS, 26 AS M4_MES, 33 AS M4_OBJ, '79%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 12 AS ORD, 'DATA' AS row_class, 'TOSONIERI LEANDRO ' AS VENDEDOR, 33 AS M1_MES, 29 AS M1_OBJ, '114%' AS M1_CUMP, 'GREEN' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 10 AS M3_MES, 15 AS M3_OBJ, '67%' AS M3_CUMP, 'RED' AS M3_PASS, 31 AS M4_MES, 33 AS M4_OBJ, '94%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 13 AS ORD, 'TOTAL' AS row_class, 'TOTAL' AS VENDEDOR, 329 AS M1_MES, 348 AS M1_OBJ, '95%' AS M1_CUMP, 'RED' AS M1_PASS, 5 AS M2_MES, 12 AS M2_OBJ, '42%' AS M2_CUMP, 'RED' AS M2_PASS, 156 AS M3_MES, 180 AS M3_OBJ, '87%' AS M3_CUMP, 'RED' AS M3_PASS, 377 AS M4_MES, 396 AS M4_OBJ, '95%' AS M4_CUMP, 'RED' AS M4_PASS, 1 AS PAGO) TMP
                  ORDER BY ORD";
    }
    else if ($canal == "Canal_Directo_Sur") {
        $query = "SELECT VENDEDOR, row_class, M1_MES, M1_OBJ, M1_CUMP, M1_PASS, M2_MES, M2_OBJ, M2_CUMP, M2_PASS, M3_MES, M3_OBJ, M3_CUMP, M3_PASS, M4_MES, M4_OBJ, M4_CUMP, M4_PASS, PAGO
                  FROM (SELECT 1 AS ORD, 'DATA' AS row_class, 'BACCHINI  CARLOS ' AS VENDEDOR, 21 AS M1_MES, 29 AS M1_OBJ, '72%' AS M1_CUMP, 'RED' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 11 AS M3_MES, 15 AS M3_OBJ, '73%' AS M3_CUMP, 'RED' AS M3_PASS, 33 AS M4_MES, 33 AS M4_OBJ, '100%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 2 AS ORD, 'DATA' AS row_class, 'BASILI GABRIEL' AS VENDEDOR, 25 AS M1_MES, 29 AS M1_OBJ, '86%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 14 AS M3_MES, 15 AS M3_OBJ, '93%' AS M3_CUMP, 'GREEN' AS M3_PASS, 24 AS M4_MES, 33 AS M4_OBJ, '73%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 3 AS ORD, 'DATA' AS row_class, 'CAULA MATIAS' AS VENDEDOR, 33 AS M1_MES, 29 AS M1_OBJ, '114%' AS M1_CUMP, 'GREEN' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 10 AS M3_MES, 15 AS M3_OBJ, '67%' AS M3_CUMP, 'RED' AS M3_PASS, 25 AS M4_MES, 33 AS M4_OBJ, '76%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 4 AS ORD, 'DATA' AS row_class, 'CRESPO ERNESTO                ' AS VENDEDOR, 23 AS M1_MES, 29 AS M1_OBJ, '79%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 15 AS M3_MES, 15 AS M3_OBJ, '100%' AS M3_CUMP, 'GREEN' AS M3_PASS, 27 AS M4_MES, 33 AS M4_OBJ, '82%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 5 AS ORD, 'DATA' AS row_class, 'DOMENICONI  CLAUDIO DANTE ' AS VENDEDOR, 21 AS M1_MES, 29 AS M1_OBJ, '72%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 17 AS M3_MES, 15 AS M3_OBJ, '113%' AS M3_CUMP, 'GREEN' AS M3_PASS, 23 AS M4_MES, 33 AS M4_OBJ, '70%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 6 AS ORD, 'DATA' AS row_class, 'ETCHEGARAY HOMERO' AS VENDEDOR, 32 AS M1_MES, 29 AS M1_OBJ, '110%' AS M1_CUMP, 'GREEN' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 15 AS M3_MES, 15 AS M3_OBJ, '100%' AS M3_CUMP, 'GREEN' AS M3_PASS, 31 AS M4_MES, 33 AS M4_OBJ, '94%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 7 AS ORD, 'DATA' AS row_class, 'LUCIDO BALESTRIERE AGOSTINA' AS VENDEDOR, 25 AS M1_MES, 29 AS M1_OBJ, '86%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 15 AS M3_MES, 15 AS M3_OBJ, '100%' AS M3_CUMP, 'GREEN' AS M3_PASS, 34 AS M4_MES, 33 AS M4_OBJ, '103%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 8 AS ORD, 'DATA' AS row_class, 'LUPI CARLOS JAVIER ' AS VENDEDOR, 26 AS M1_MES, 29 AS M1_OBJ, '90%' AS M1_CUMP, 'RED' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 11 AS M3_MES, 15 AS M3_OBJ, '73%' AS M3_CUMP, 'RED' AS M3_PASS, 37 AS M4_MES, 33 AS M4_OBJ, '112%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 9 AS ORD, 'DATA' AS row_class, 'MANGIACAVALLI GESICA PAOLA' AS VENDEDOR, 33 AS M1_MES, 29 AS M1_OBJ, '114%' AS M1_CUMP, 'GREEN' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 18 AS M3_MES, 15 AS M3_OBJ, '120%' AS M3_CUMP, 'GREEN' AS M3_PASS, 34 AS M4_MES, 33 AS M4_OBJ, '103%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 10 AS ORD, 'DATA' AS row_class, 'MASTROSTEFANO NICOLAS' AS VENDEDOR, 23 AS M1_MES, 29 AS M1_OBJ, '79%' AS M1_CUMP, 'RED' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 11 AS M3_MES, 15 AS M3_OBJ, '73%' AS M3_CUMP, 'RED' AS M3_PASS, 27 AS M4_MES, 33 AS M4_OBJ, '82%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 11 AS ORD, 'DATA' AS row_class, 'OJEDA SEBASTIAN MATIAS' AS VENDEDOR, 21 AS M1_MES, 29 AS M1_OBJ, '72%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 14 AS M3_MES, 15 AS M3_OBJ, '93%' AS M3_CUMP, 'GREEN' AS M3_PASS, 24 AS M4_MES, 33 AS M4_OBJ, '73%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 12 AS ORD, 'TOTAL' AS row_class, 'TOTAL' AS VENDEDOR, 283 AS M1_MES, 319 AS M1_OBJ, '89%' AS M1_CUMP, 'RED' AS M1_PASS, 3 AS M2_MES, 11 AS M2_OBJ, '27%' AS M2_CUMP, 'RED' AS M2_PASS, 151 AS M3_MES, 165 AS M3_OBJ, '92%' AS M3_CUMP, 'RED' AS M3_PASS, 319 AS M4_MES, 363 AS M4_OBJ, '88%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO) TMP
                  ORDER BY ORD";
    }
    else if ($canal == "Telemarketing") {
        $query = "SELECT VENDEDOR, row_class, M1_MES, M1_OBJ, M1_CUMP, M1_PASS, M2_MES, M2_OBJ, M2_CUMP, M2_PASS, M3_MES, M3_OBJ, M3_CUMP, M3_PASS, PAGO
                  FROM (SELECT 1 AS ORD, 'DATA' AS row_class, 'ANALIA ELIZABETH PAGELLA' AS VENDEDOR, 83 AS M1_MES, 80 AS M1_OBJ, '104%' AS M1_CUMP, 'GREEN' AS M1_PASS, 80 AS M2_MES, 75 AS M2_OBJ, '107%' AS M2_CUMP, 'GREEN' AS M2_PASS, 27 AS M3_MES, 28 AS M3_OBJ, '96%' AS M3_CUMP, 'GREEN' AS M3_PASS, 1 AS PAGO UNION
                        SELECT 2 AS ORD, 'DATA' AS row_class, 'CAMILA ACOSTA' AS VENDEDOR, 64 AS M1_MES, 80 AS M1_OBJ, '80%' AS M1_CUMP, 'RED' AS M1_PASS, 66 AS M2_MES, 75 AS M2_OBJ, '88%' AS M2_CUMP, 'RED' AS M2_PASS, 24 AS M3_MES, 28 AS M3_OBJ, '86%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 3 AS ORD, 'DATA' AS row_class, 'CELESTE GIROLA' AS VENDEDOR, 81 AS M1_MES, 80 AS M1_OBJ, '101%' AS M1_CUMP, 'GREEN' AS M1_PASS, 68 AS M2_MES, 75 AS M2_OBJ, '91%' AS M2_CUMP, 'RED' AS M2_PASS, 29 AS M3_MES, 28 AS M3_OBJ, '104%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 4 AS ORD, 'DATA' AS row_class, 'DEBORA EVELIN SCHER' AS VENDEDOR, 86 AS M1_MES, 80 AS M1_OBJ, '108%' AS M1_CUMP, 'GREEN' AS M1_PASS, 81 AS M2_MES, 75 AS M2_OBJ, '108%' AS M2_CUMP, 'GREEN' AS M2_PASS, 26 AS M3_MES, 28 AS M3_OBJ, '93%' AS M3_CUMP, 'GREEN' AS M3_PASS, 1 AS PAGO UNION
                        SELECT 5 AS ORD, 'DATA' AS row_class, 'FRANCO MATIAS GAMBARTE' AS VENDEDOR, 68 AS M1_MES, 80 AS M1_OBJ, '85%' AS M1_CUMP, 'RED' AS M1_PASS, 81 AS M2_MES, 75 AS M2_OBJ, '108%' AS M2_CUMP, 'GREEN' AS M2_PASS, 23 AS M3_MES, 28 AS M3_OBJ, '82%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 6 AS ORD, 'DATA' AS row_class, 'JENNIFER ELIANA FRIAS' AS VENDEDOR, 90 AS M1_MES, 80 AS M1_OBJ, '113%' AS M1_CUMP, 'GREEN' AS M1_PASS, 67 AS M2_MES, 75 AS M2_OBJ, '89%' AS M2_CUMP, 'RED' AS M2_PASS, 26 AS M3_MES, 28 AS M3_OBJ, '93%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 7 AS ORD, 'DATA' AS row_class, 'MARIA LAURA DIAZ' AS VENDEDOR, 70 AS M1_MES, 80 AS M1_OBJ, '88%' AS M1_CUMP, 'RED' AS M1_PASS, 52 AS M2_MES, 75 AS M2_OBJ, '69%' AS M2_CUMP, 'RED' AS M2_PASS, 30 AS M3_MES, 28 AS M3_OBJ, '107%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 8 AS ORD, 'DATA' AS row_class, 'MARIANA BEATRIZ TEODORINI' AS VENDEDOR, 75 AS M1_MES, 80 AS M1_OBJ, '94%' AS M1_CUMP, 'RED' AS M1_PASS, 53 AS M2_MES, 75 AS M2_OBJ, '71%' AS M2_CUMP, 'RED' AS M2_PASS, 33 AS M3_MES, 28 AS M3_OBJ, '118%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 9 AS ORD, 'DATA' AS row_class, 'MELISA ESPOSITO' AS VENDEDOR, 56 AS M1_MES, 80 AS M1_OBJ, '70%' AS M1_CUMP, 'RED' AS M1_PASS, 76 AS M2_MES, 75 AS M2_OBJ, '101%' AS M2_CUMP, 'GREEN' AS M2_PASS, 21 AS M3_MES, 28 AS M3_OBJ, '75%' AS M3_CUMP, 'RED' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 10 AS ORD, 'DATA' AS row_class, 'MERCEDES LAURA URIOS' AS VENDEDOR, 58 AS M1_MES, 80 AS M1_OBJ, '73%' AS M1_CUMP, 'RED' AS M1_PASS, 73 AS M2_MES, 75 AS M2_OBJ, '97%' AS M2_CUMP, 'RED' AS M2_PASS, 31 AS M3_MES, 28 AS M3_OBJ, '111%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 11 AS ORD, 'DATA' AS row_class, 'NADIA SOLEDAD HIDALGO' AS VENDEDOR, 71 AS M1_MES, 80 AS M1_OBJ, '89%' AS M1_CUMP, 'RED' AS M1_PASS, 72 AS M2_MES, 75 AS M2_OBJ, '96%' AS M2_CUMP, 'RED' AS M2_PASS, 30 AS M3_MES, 28 AS M3_OBJ, '107%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 12 AS ORD, 'DATA' AS row_class, 'PAULA AYELEN NARDIN DAMIA' AS VENDEDOR, 93 AS M1_MES, 80 AS M1_OBJ, '116%' AS M1_CUMP, 'GREEN' AS M1_PASS, 78 AS M2_MES, 75 AS M2_OBJ, '104%' AS M2_CUMP, 'GREEN' AS M2_PASS, 31 AS M3_MES, 28 AS M3_OBJ, '111%' AS M3_CUMP, 'GREEN' AS M3_PASS, 1.25 AS PAGO UNION
                        SELECT 13 AS ORD, 'DATA' AS row_class, 'VANESA VALERIA SOTO' AS VENDEDOR, 61 AS M1_MES, 80 AS M1_OBJ, '76%' AS M1_CUMP, 'RED' AS M1_PASS, 70 AS M2_MES, 75 AS M2_OBJ, '93%' AS M2_CUMP, 'RED' AS M2_PASS, 31 AS M3_MES, 28 AS M3_OBJ, '111%' AS M3_CUMP, 'GREEN' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 14 AS ORD, 'DATA' AS row_class, 'YANINA SOLEDAD BARGAS' AS VENDEDOR, 68 AS M1_MES, 80 AS M1_OBJ, '85%' AS M1_CUMP, 'RED' AS M1_PASS, 53 AS M2_MES, 75 AS M2_OBJ, '71%' AS M2_CUMP, 'RED' AS M2_PASS, 21 AS M3_MES, 28 AS M3_OBJ, '75%' AS M3_CUMP, 'RED' AS M3_PASS, 0 AS PAGO UNION
                        SELECT 15 AS ORD, 'TOTAL' AS row_class, 'TOTAL' AS VENDEDOR, 1024 AS M1_MES, 1120 AS M1_OBJ, '91%' AS M1_CUMP, 'RED' AS M1_PASS, 970 AS M2_MES, 1050 AS M2_OBJ, '92%' AS M2_CUMP, 'RED' AS M2_PASS, 383 AS M3_MES, 392 AS M3_OBJ, '98%' AS M3_CUMP, 'RED' AS M3_PASS, 3.25 AS PAGO) TMP
                  ORDER BY ORD";
    }
    else if ($canal == "Canal_Digital") {
        $query = "SELECT VENDEDOR, row_class, M1_MES, M1_OBJ, M1_CUMP, M1_PASS, M2_MES, M2_OBJ, M2_CUMP, M2_PASS, PAGO
                  FROM (SELECT 1 AS ORD, 'DATA' AS row_class, 'ANALIA ELIZABETH PAGELLA' AS VENDEDOR, 123 AS M1_MES, 80 AS M1_OBJ, '154%' AS M1_CUMP, 'GREEN' AS M1_PASS, 35 AS M2_MES, 28 AS M2_OBJ, '125%' AS M2_CUMP, 'GREEN' AS M2_PASS, 1.25 AS PAGO UNION
                        SELECT 2 AS ORD, 'DATA' AS row_class, 'CAMILA ACOSTA' AS VENDEDOR, 148 AS M1_MES, 80 AS M1_OBJ, '185%' AS M1_CUMP, 'GREEN' AS M1_PASS, 37 AS M2_MES, 28 AS M2_OBJ, '132%' AS M2_CUMP, 'GREEN' AS M2_PASS, 1.5 AS PAGO UNION
                        SELECT 3 AS ORD, 'DATA' AS row_class, 'TOTAL' AS VENDEDOR, 271 AS M1_MES, 160 AS M1_OBJ, '169%' AS M1_CUMP, 'GREEN' AS M1_PASS, 72 AS M2_MES, 56 AS M2_OBJ, '129%' AS M2_CUMP, 'GREEN' AS M2_PASS, 2.75 AS PAGO) TMP
                  ORDER BY ORD";
    }
    else if ($canal == "Account_GBS") {
        $query = "SELECT VENDEDOR, row_class, M1_MES, M1_OBJ, M1_CUMP, M1_PASS, M2_MES, M2_OBJ, M2_CUMP, M2_PASS, M3_MES, M3_OBJ, M3_CUMP, M3_PASS, M4_MES, M4_OBJ, M4_CUMP, M4_PASS, PAGO
                  FROM (SELECT 1 AS ORD, 'DATA' AS row_class, 'AMBROJ TURCUMAN, DALMA EL' AS VENDEDOR, 2249 AS M1_MES, 2272 AS M1_OBJ, '99%' AS M1_CUMP, 'RED' AS M1_PASS, 30 AS M2_MES, 30 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 1 AS M3_MES, 1 AS M3_OBJ, '100%' AS M3_CUMP, 'GREEN' AS M3_PASS, 16 AS M4_MES, 14 AS M4_OBJ, '114%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 2 AS ORD, 'DATA' AS row_class, 'HEREDIA HEBE SUSANA' AS VENDEDOR, 2612 AS M1_MES, 2272 AS M1_OBJ, '115%' AS M1_CUMP, 'GREEN' AS M1_PASS, 36 AS M2_MES, 30 AS M2_OBJ, '120%' AS M2_CUMP, 'GREEN' AS M2_PASS, 1 AS M3_MES, 1 AS M3_OBJ, '100%' AS M3_CUMP, 'GREEN' AS M3_PASS, 15 AS M4_MES, 14 AS M4_OBJ, '107%' AS M4_CUMP, 'GREEN' AS M4_PASS, 1 AS PAGO UNION
                        SELECT 3 AS ORD, 'DATA' AS row_class, 'TBD' AS VENDEDOR, 1772 AS M1_MES, 2272 AS M1_OBJ, '78%' AS M1_CUMP, 'RED' AS M1_PASS, 30 AS M2_MES, 30 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 0 AS M3_MES, 1 AS M3_OBJ, '0%' AS M3_CUMP, 'RED' AS M3_PASS, 10 AS M4_MES, 14 AS M4_OBJ, '71%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 4 AS ORD, 'DATA' AS row_class, 'MEIGHORNER MARCELO' AS VENDEDOR, 1590 AS M1_MES, 2272 AS M1_OBJ, '70%' AS M1_CUMP, 'RED' AS M1_PASS, 28 AS M2_MES, 30 AS M2_OBJ, '93%' AS M2_CUMP, 'GREEN' AS M2_PASS, 0 AS M3_MES, 1 AS M3_OBJ, '0%' AS M3_CUMP, 'RED' AS M3_PASS, 16 AS M4_MES, 14 AS M4_OBJ, '114%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 5 AS ORD, 'DATA' AS row_class, 'TOTAL' AS VENDEDOR, 8223 AS M1_MES, 9088 AS M1_OBJ, '90%' AS M1_CUMP, 'RED' AS M1_PASS, 124 AS M2_MES, 120 AS M2_OBJ, '103%' AS M2_CUMP, 'GREEN' AS M2_PASS, 2 AS M3_MES, 4 AS M3_OBJ, '50%' AS M3_CUMP, 'RED' AS M3_PASS, 57 AS M4_MES, 56 AS M4_OBJ, '102%' AS M4_CUMP, 'GREEN' AS M4_PASS, 1 AS PAGO) TMP
                  ORDER BY ORD";
    }
    else if ($canal == "Account_GFS") {
        $query = "SELECT VENDEDOR, row_class, M1_MES, M1_OBJ, M1_CUMP, M1_PASS, M2_MES, M2_OBJ, M2_CUMP, M2_PASS, M3_MES, M3_OBJ, M3_CUMP, M3_PASS, M4_MES, M4_OBJ, M4_CUMP, M4_PASS, PAGO
                  FROM (SELECT 1 AS ORD, 'DATA' AS row_class, 'AMEZUA AGUSTINA' AS VENDEDOR, 3277 AS M1_MES, 2825 AS M1_OBJ, '116%' AS M1_CUMP, 'GREEN' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 4 AS M3_MES, 4 AS M3_OBJ, '100%' AS M3_CUMP, 'GREEN' AS M3_PASS, 76 AS M4_MES, 81 AS M4_OBJ, '94%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 2 AS ORD, 'DATA' AS row_class, 'BLANCO ALFREDO' AS VENDEDOR, 2062 AS M1_MES, 2825 AS M1_OBJ, '73%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 4 AS M3_MES, 4 AS M3_OBJ, '100%' AS M3_CUMP, 'GREEN' AS M3_PASS, 85 AS M4_MES, 81 AS M4_OBJ, '105%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 3 AS ORD, 'DATA' AS row_class, 'LOPEZ SERGIO' AS VENDEDOR, 2655 AS M1_MES, 2825 AS M1_OBJ, '94%' AS M1_CUMP, 'RED' AS M1_PASS, 1 AS M2_MES, 1 AS M2_OBJ, '100%' AS M2_CUMP, 'GREEN' AS M2_PASS, 3 AS M3_MES, 4 AS M3_OBJ, '75%' AS M3_CUMP, 'RED' AS M3_PASS, 90 AS M4_MES, 81 AS M4_OBJ, '111%' AS M4_CUMP, 'GREEN' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 4 AS ORD, 'DATA' AS row_class, 'MARTINEZ ALCIDES' AS VENDEDOR, 2062 AS M1_MES, 2825 AS M1_OBJ, '73%' AS M1_CUMP, 'RED' AS M1_PASS, 0 AS M2_MES, 1 AS M2_OBJ, '0%' AS M2_CUMP, 'RED' AS M2_PASS, 4 AS M3_MES, 4 AS M3_OBJ, '100%' AS M3_CUMP, 'GREEN' AS M3_PASS, 69 AS M4_MES, 81 AS M4_OBJ, '85%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO UNION
                        SELECT 5 AS ORD, 'DATA' AS row_class, 'TOTAL' AS VENDEDOR, 10056 AS M1_MES, 11300 AS M1_OBJ, '89%' AS M1_CUMP, 'RED' AS M1_PASS, 2 AS M2_MES, 4 AS M2_OBJ, '50%' AS M2_CUMP, 'RED' AS M2_PASS, 15 AS M3_MES, 16 AS M3_OBJ, '94%' AS M3_CUMP, 'RED' AS M3_PASS, 320 AS M4_MES, 324 AS M4_OBJ, '99%' AS M4_CUMP, 'RED' AS M4_PASS, 0 AS PAGO) TMP
                  ORDER BY ORD";
    }

    to_json(table_simple($query));
}

function get_Performance_Vendedor_grafico($user_id, $canal) {
    if ($canal == "Canal_Directo_Norte") {
        $query1 = "SELECT label, value
                   FROM (SELECT 'CARAMELO EZEQUIEL' AS label, 86 as value UNION
                         SELECT 'CUELLO LUCAS JUAN' AS label, 100 as value UNION
                         SELECT 'GARCIA SOFIA' AS label, 114 as value UNION
                         SELECT 'GOMEZ LUIS EMANUEL ' AS label, 110 as value UNION
                         SELECT 'HARTFIEL MARIA ELENA' AS label, 90 as value UNION
                         SELECT 'LAMANNA LUCAS DAMIAN' AS label, 76 as value UNION
                         SELECT 'LO CASCIO GERMAN JAVIER ' AS label, 86 as value UNION
                         SELECT 'MARTINEZ FERNANDO URIEL' AS label, 76 as value UNION
                         SELECT 'MORALES ANTUÑA MILAGROS' AS label, 93 as value UNION
                         SELECT 'RIQUELME MATIAS' AS label, 72 as value UNION
                         SELECT 'SANSBERRO NEHUEN DANIEL ' AS label, 117 as value UNION
                         SELECT 'TOSONIERI LEANDRO ' AS label, 114 as value) TMP
                   ORDER BY label";

        $query2 = "SELECT label, value
                   FROM (SELECT 'CARAMELO EZEQUIEL' AS label, 0 as value UNION
                         SELECT 'CUELLO LUCAS JUAN' AS label, 100 as value UNION
                         SELECT 'GARCIA SOFIA' AS label, 0 as value UNION
                         SELECT 'GOMEZ LUIS EMANUEL ' AS label, 100 as value UNION
                         SELECT 'HARTFIEL MARIA ELENA' AS label, 0 as value UNION
                         SELECT 'LAMANNA LUCAS DAMIAN' AS label, 100 as value UNION
                         SELECT 'LO CASCIO GERMAN JAVIER ' AS label, 0 as value UNION
                         SELECT 'MARTINEZ FERNANDO URIEL' AS label, 100 as value UNION
                         SELECT 'MORALES ANTUÑA MILAGROS' AS label, 0 as value UNION
                         SELECT 'RIQUELME MATIAS' AS label, 100 as value UNION
                         SELECT 'SANSBERRO NEHUEN DANIEL ' AS label, 0 as value UNION
                         SELECT 'TOSONIERI LEANDRO ' AS label, 0 as value) TMP
                   ORDER BY label";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 'CARAMELO EZEQUIEL' AS label, 113 as value UNION
                         SELECT 'CUELLO LUCAS JUAN' AS label, 93 as value UNION
                         SELECT 'GARCIA SOFIA' AS label, 113 as value UNION
                         SELECT 'GOMEZ LUIS EMANUEL ' AS label, 67 as value UNION
                         SELECT 'HARTFIEL MARIA ELENA' AS label, 107 as value UNION
                         SELECT 'LAMANNA LUCAS DAMIAN' AS label, 73 as value UNION
                         SELECT 'LO CASCIO GERMAN JAVIER ' AS label, 80 as value UNION
                         SELECT 'MARTINEZ FERNANDO URIEL' AS label, 73 as value UNION
                         SELECT 'MORALES ANTUÑA MILAGROS' AS label, 73 as value UNION
                         SELECT 'RIQUELME MATIAS' AS label, 107 as value UNION
                         SELECT 'SANSBERRO NEHUEN DANIEL ' AS label, 73 as value UNION
                         SELECT 'TOSONIERI LEANDRO ' AS label, 67 as value) TMP
                   ORDER BY label";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 'CARAMELO EZEQUIEL' AS label, 100 as value UNION
                         SELECT 'CUELLO LUCAS JUAN' AS label, 100 as value UNION
                         SELECT 'GARCIA SOFIA' AS label, 82 as value UNION
                         SELECT 'GOMEZ LUIS EMANUEL ' AS label, 115 as value UNION
                         SELECT 'HARTFIEL MARIA ELENA' AS label, 94 as value UNION
                         SELECT 'LAMANNA LUCAS DAMIAN' AS label, 109 as value UNION
                         SELECT 'LO CASCIO GERMAN JAVIER ' AS label, 79 as value UNION
                         SELECT 'MARTINEZ FERNANDO URIEL' AS label, 118 as value UNION
                         SELECT 'MORALES ANTUÑA MILAGROS' AS label, 97 as value UNION
                         SELECT 'RIQUELME MATIAS' AS label, 76 as value UNION
                         SELECT 'SANSBERRO NEHUEN DANIEL ' AS label, 79 as value UNION
                         SELECT 'TOSONIERI LEANDRO ' AS label, 94 as value) TMP
                   ORDER BY label";

        to_json(array(
                    array('key'=>"Terminales", 'values'=>table_simple($query1)),
                    array('key'=>"Web Posnet", 'values'=>table_simple($query2)),
                    array('key'=>"Alta de Comercios", 'values'=>table_simple($query3)),
                    array('key'=>"Medios de Pago", 'values'=>table_simple($query4))
                ));
    }
    else if ($canal == "Canal_Directo_Sur") {
        $query1 = "SELECT label, value
                   FROM (SELECT 'BACCHINI  CARLOS ' AS label, 72 as value UNION
                         SELECT 'BASILI GABRIEL' AS label, 86 as value UNION
                         SELECT 'CAULA MATIAS' AS label, 114 as value UNION
                         SELECT 'CRESPO ERNESTO                ' AS label, 79 as value UNION
                         SELECT 'DOMENICONI  CLAUDIO DANTE ' AS label, 72 as value UNION
                         SELECT 'ETCHEGARAY HOMERO' AS label, 110 as value UNION
                         SELECT 'LUCIDO BALESTRIERE AGOSTINA' AS label, 86 as value UNION
                         SELECT 'LUPI CARLOS JAVIER ' AS label, 90 as value UNION
                         SELECT 'MANGIACAVALLI GESICA PAOLA' AS label, 114 as value UNION
                         SELECT 'MASTROSTEFANO NICOLAS' AS label, 79 as value UNION
                         SELECT 'OJEDA SEBASTIAN MATIAS' AS label, 72 as value) TMP
                   ORDER BY label";

        $query2 = "SELECT label, value
                   FROM (SELECT 'BACCHINI  CARLOS ' AS label, 100 as value UNION
                         SELECT 'BASILI GABRIEL' AS label, 0 as value UNION
                         SELECT 'CAULA MATIAS' AS label, 0 as value UNION
                         SELECT 'CRESPO ERNESTO                ' AS label, 0 as value UNION
                         SELECT 'DOMENICONI  CLAUDIO DANTE ' AS label, 0 as value UNION
                         SELECT 'ETCHEGARAY HOMERO' AS label, 0 as value UNION
                         SELECT 'LUCIDO BALESTRIERE AGOSTINA' AS label, 0 as value UNION
                         SELECT 'LUPI CARLOS JAVIER ' AS label, 100 as value UNION
                         SELECT 'MANGIACAVALLI GESICA PAOLA' AS label, 0 as value UNION
                         SELECT 'MASTROSTEFANO NICOLAS' AS label, 100 as value UNION
                         SELECT 'OJEDA SEBASTIAN MATIAS' AS label, 0 as value) TMP
                   ORDER BY label";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 'BACCHINI  CARLOS ' AS label, 73 as value UNION
                         SELECT 'BASILI GABRIEL' AS label, 93 as value UNION
                         SELECT 'CAULA MATIAS' AS label, 67 as value UNION
                         SELECT 'CRESPO ERNESTO                ' AS label, 100 as value UNION
                         SELECT 'DOMENICONI  CLAUDIO DANTE ' AS label, 113 as value UNION
                         SELECT 'ETCHEGARAY HOMERO' AS label, 100 as value UNION
                         SELECT 'LUCIDO BALESTRIERE AGOSTINA' AS label, 100 as value UNION
                         SELECT 'LUPI CARLOS JAVIER ' AS label, 73 as value UNION
                         SELECT 'MANGIACAVALLI GESICA PAOLA' AS label, 120 as value UNION
                         SELECT 'MASTROSTEFANO NICOLAS' AS label, 73 as value UNION
                         SELECT 'OJEDA SEBASTIAN MATIAS' AS label, 93 as value) TMP
                   ORDER BY label";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 'BACCHINI  CARLOS ' AS label, 100 as value UNION
                         SELECT 'BASILI GABRIEL' AS label, 73 as value UNION
                         SELECT 'CAULA MATIAS' AS label, 76 as value UNION
                         SELECT 'CRESPO ERNESTO                ' AS label, 82 as value UNION
                         SELECT 'DOMENICONI  CLAUDIO DANTE ' AS label, 70 as value UNION
                         SELECT 'ETCHEGARAY HOMERO' AS label, 94 as value UNION
                         SELECT 'LUCIDO BALESTRIERE AGOSTINA' AS label, 103 as value UNION
                         SELECT 'LUPI CARLOS JAVIER ' AS label, 112 as value UNION
                         SELECT 'MANGIACAVALLI GESICA PAOLA' AS label, 103 as value UNION
                         SELECT 'MASTROSTEFANO NICOLAS' AS label, 82 as value UNION
                         SELECT 'OJEDA SEBASTIAN MATIAS' AS label, 73 as value) TMP
                   ORDER BY label";

        to_json(array(
                    array('key'=>"Terminales", 'values'=>table_simple($query1)),
                    array('key'=>"Web Posnet", 'values'=>table_simple($query2)),
                    array('key'=>"Alta de Comercios", 'values'=>table_simple($query3)),
                    array('key'=>"Medios de Pago", 'values'=>table_simple($query4))
                ));
    }
    else if ($canal == "Telemarketing") {
        $query1 = "SELECT label, value
                   FROM (SELECT 'ANALIA ELIZABETH PAGELLA' AS label, 104 as value UNION
                         SELECT 'CAMILA ACOSTA' AS label, 80 as value UNION
                         SELECT 'CELESTE GIROLA' AS label, 101 as value UNION
                         SELECT 'DEBORA EVELIN SCHER' AS label, 108 as value UNION
                         SELECT 'FRANCO MATIAS GAMBARTE' AS label, 85 as value UNION
                         SELECT 'JENNIFER ELIANA FRIAS' AS label, 113 as value UNION
                         SELECT 'MARIA LAURA DIAZ' AS label, 88 as value UNION
                         SELECT 'MARIANA BEATRIZ TEODORINI' AS label, 94 as value UNION
                         SELECT 'MELISA ESPOSITO' AS label, 70 as value UNION
                         SELECT 'MERCEDES LAURA URIOS' AS label, 73 as value UNION
                         SELECT 'NADIA SOLEDAD HIDALGO' AS label, 89 as value UNION
                         SELECT 'PAULA AYELEN NARDIN DAMIA' AS label, 116 as value UNION
                         SELECT 'VANESA VALERIA SOTO' AS label, 76 as value UNION
                         SELECT 'YANINA SOLEDAD BARGAS' AS label, 85 as value) TMP
                   ORDER BY label";

        $query2 = "SELECT label, value
                   FROM (SELECT 'ANALIA ELIZABETH PAGELLA' AS label, 107 as value UNION
                         SELECT 'CAMILA ACOSTA' AS label, 88 as value UNION
                         SELECT 'CELESTE GIROLA' AS label, 91 as value UNION
                         SELECT 'DEBORA EVELIN SCHER' AS label, 108 as value UNION
                         SELECT 'FRANCO MATIAS GAMBARTE' AS label, 108 as value UNION
                         SELECT 'JENNIFER ELIANA FRIAS' AS label, 89 as value UNION
                         SELECT 'MARIA LAURA DIAZ' AS label, 69 as value UNION
                         SELECT 'MARIANA BEATRIZ TEODORINI' AS label, 71 as value UNION
                         SELECT 'MELISA ESPOSITO' AS label, 101 as value UNION
                         SELECT 'MERCEDES LAURA URIOS' AS label, 97 as value UNION
                         SELECT 'NADIA SOLEDAD HIDALGO' AS label, 96 as value UNION
                         SELECT 'PAULA AYELEN NARDIN DAMIA' AS label, 104 as value UNION
                         SELECT 'VANESA VALERIA SOTO' AS label, 93 as value UNION
                         SELECT 'YANINA SOLEDAD BARGAS' AS label, 71 as value) TMP
                   ORDER BY label";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 'ANALIA ELIZABETH PAGELLA' AS label, 96 as value UNION
                         SELECT 'CAMILA ACOSTA' AS label, 86 as value UNION
                         SELECT 'CELESTE GIROLA' AS label, 104 as value UNION
                         SELECT 'DEBORA EVELIN SCHER' AS label, 93 as value UNION
                         SELECT 'FRANCO MATIAS GAMBARTE' AS label, 82 as value UNION
                         SELECT 'JENNIFER ELIANA FRIAS' AS label, 93 as value UNION
                         SELECT 'MARIA LAURA DIAZ' AS label, 107 as value UNION
                         SELECT 'MARIANA BEATRIZ TEODORINI' AS label, 118 as value UNION
                         SELECT 'MELISA ESPOSITO' AS label, 75 as value UNION
                         SELECT 'MERCEDES LAURA URIOS' AS label, 111 as value UNION
                         SELECT 'NADIA SOLEDAD HIDALGO' AS label, 107 as value UNION
                         SELECT 'PAULA AYELEN NARDIN DAMIA' AS label, 111 as value UNION
                         SELECT 'VANESA VALERIA SOTO' AS label, 111 as value UNION
                         SELECT 'YANINA SOLEDAD BARGAS' AS label, 75 as value) TMP
                   ORDER BY label";

        to_json(array(
                    array('key'=>"Terminales", 'values'=>table_simple($query1)),
                    array('key'=>"Activación de Comercios", 'values'=>table_simple($query2)),
                    array('key'=>"Medios de Pago", 'values'=>table_simple($query3))
                ));
    }
    else if ($canal == "Canal_Digital") {
        $query1 = "SELECT label, value
                   FROM (SELECT 'ANALIA ELIZABETH PAGELLA' AS label, 154 as value UNION
                         SELECT 'CAMILA ACOSTA' AS label, 185 as value UNION
                         SELECT 'TOTAL' AS label, 169 as value) TMP
                   ORDER BY label";

        $query2 = "SELECT label, value
                   FROM (SELECT 'ANALIA ELIZABETH PAGELLA' AS label, 125 as value UNION
                         SELECT 'CAMILA ACOSTA' AS label, 132 as value UNION
                         SELECT 'TOTAL' AS label, 129 as value) TMP
                   ORDER BY label";

        to_json(array(
                    array('key'=>"Terminales", 'values'=>table_simple($query1)),
                    array('key'=>"Medios de Pago", 'values'=>table_simple($query2))
                ));
    }
    else if ($canal == "Account_GBS") {
        $query1 = "SELECT label, value
                   FROM (SELECT 'AMBROJ TURCUMAN, DALMA EL' AS label, 99 as value UNION
                         SELECT 'HEREDIA HEBE SUSANA' AS label, 115 as value UNION
                         SELECT 'TBD' AS label, 78 as value UNION
                         SELECT 'MEIGHORNER MARCELO' AS label, 70 as value) TMP
                   ORDER BY label";

        $query2 = "SELECT label, value
                   FROM (SELECT 'AMBROJ TURCUMAN, DALMA EL' AS label, 100 as value UNION
                         SELECT 'HEREDIA HEBE SUSANA' AS label, 120 as value UNION
                         SELECT 'TBD' AS label, 100 as value UNION
                         SELECT 'MEIGHORNER MARCELO' AS label, 93 as value) TMP
                   ORDER BY label";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 'AMBROJ TURCUMAN, DALMA EL' AS label, 100 as value UNION
                         SELECT 'HEREDIA HEBE SUSANA' AS label, 100 as value UNION
                         SELECT 'TBD' AS label, 0 as value UNION
                         SELECT 'MEIGHORNER MARCELO' AS label, 0 as value) TMP
                   ORDER BY label";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 'AMBROJ TURCUMAN, DALMA EL' AS label, 114 as value UNION
                         SELECT 'HEREDIA HEBE SUSANA' AS label, 107 as value UNION
                         SELECT 'TBD' AS label, 71 as value UNION
                         SELECT 'MEIGHORNER MARCELO' AS label, 114 as value) TMP
                   ORDER BY label";

        to_json(array(
                    array('key'=>"Volumen", 'values'=>table_simple($query1)),
                    array('key'=>"Portfolio", 'values'=>table_simple($query2)),
                    array('key'=>"Devices", 'values'=>table_simple($query3)),
                    array('key'=>"Productos", 'values'=>table_simple($query4))
                ));
    }
    else if ($canal == "Account_GFS") {
        $query1 = "SELECT label, value
                   FROM (SELECT 'AMEZUA AGUSTINA' AS label, 116 as value UNION
                         SELECT 'BLANCO ALFREDO' AS label, 73 as value UNION
                         SELECT 'LOPEZ SERGIO' AS label, 94 as value UNION
                         SELECT 'MARTINEZ ALCIDES' AS label, 73 as value) TMP
                   ORDER BY label";

        $query2 = "SELECT label, value
                   FROM (SELECT 'AMEZUA AGUSTINA' AS label, 100 as value UNION
                         SELECT 'BLANCO ALFREDO' AS label, 0 as value UNION
                         SELECT 'LOPEZ SERGIO' AS label, 100 as value UNION
                         SELECT 'MARTINEZ ALCIDES' AS label, 0 as value) TMP
                   ORDER BY label";
                   
        $query3 = "SELECT label, value
                   FROM (SELECT 'AMEZUA AGUSTINA' AS label, 100 as value UNION
                         SELECT 'BLANCO ALFREDO' AS label, 100 as value UNION
                         SELECT 'LOPEZ SERGIO' AS label, 75 as value UNION
                         SELECT 'MARTINEZ ALCIDES' AS label, 100 as value) TMP
                   ORDER BY label";
                   
        $query4 = "SELECT label, value
                   FROM (SELECT 'AMEZUA AGUSTINA' AS label, 94 as value UNION
                         SELECT 'BLANCO ALFREDO' AS label, 105 as value UNION
                         SELECT 'LOPEZ SERGIO' AS label, 111 as value UNION
                         SELECT 'MARTINEZ ALCIDES' AS label, 85 as value) TMP
                   ORDER BY label";

        to_json(array(
                    array('key'=>"Volumen", 'values'=>table_simple($query1)),
                    array('key'=>"Productos", 'values'=>table_simple($query2)),
                    array('key'=>"Portfolio", 'values'=>table_simple($query3)),
                    array('key'=>"Rentabilidad", 'values'=>table_simple($query4))
                ));
    }
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$user_id = isset($_GET['user']) ? intval($_GET['user']) : 0;
$canal = isset($_GET['canal']) ? strval($_GET['canal']) : "";
$action = isset($_GET['action']) ? strval($_GET['action']) : "";
$metrica = isset($_GET['metrica']) ? intval($_GET['metrica']) : "";

if ($action == "posts") get_posts($user_id);
else if ($action == "test") test();
else if ($action == "Performance_Vendedor_total") get_Performance_Vendedor_total($user_id, $canal, $metrica);
else if ($action == "Performance_Vendedor_detalle") get_Performance_Vendedor_detalle($user_id, $canal);
else if ($action == "Performance_Vendedor_grafico") get_Performance_Vendedor_grafico($user_id, $canal);

/*
else if ($_GET['action'] == "audiencia_interes_b100_tabla") get_audiencia_interes_b100_tabla($user_id);
else if ($_GET['action'] == "audiencia_interes_b100_grafico") get_audiencia_interes_b100_grafico($user_id);
else if ($_GET['action'] == "audiencia_interes_tabla") get_audiencia_interes_tabla($user_id);
else if ($_GET['action'] == "audiencia_interes_grafico") get_audiencia_interes_grafico($user_id);
else if ($_GET['action'] == "audiencia_industria_sites") get_audiencia_industria_sites($user_id, $industria);
else if ($_GET['action'] == "audiencia_industria_competidor_tabla") get_audiencia_industria_competidor_tabla($user_id, $industria, $competidor);
else if ($_GET['action'] == "audiencia_sitios_ranking_tabla") get_audiencia_sitios_ranking_tabla($user_id);
else if ($_GET['action'] == "audiencia_industrias_line_grafico") get_audiencia_industrias_line_grafico($user_id);
else if ($_GET['action'] == "audiencia_industrias_radar_grafico") get_audiencia_industrias_radar_grafico($user_id);
*/
?>


function getJSON(url, success) {
    $.ajax({
        url: url,
        dataType: "json",
        success: success
    });
};

function setTableSemaforo(url, table) {
    getJSON(url,
            function(result) {
                var tabla = $(table).find('tbody');
                
                for (var i = 0; i < result.length; i++){
                    var obj = result[i];
                    var row = "";
                    var row_class = "row-data";
                    
                    for (var key in obj){
                        var attrName = key;
                        var attrValue = obj[key];
                        
                        if (attrName == "row_class") {
                            if (attrValue == "DATA") row_class = "row-data";
                            else if (attrValue == "TOTAL") row_class = "row-total";
                        }
                        else if (attrValue == "RED") row = row + "<td><i class=\"red\"><i class=\"fa fa-2x fa-times-circle\"></i></i></td>";
                        else if (attrValue == "GREEN") row = row + "<td><i class=\"green\"><i class=\"fa fa-2x fa-check-circle\"></i></i></td>";
                        else row = row + "<td>"+attrValue+"</td>";
                    }
                    tabla.append($("<tr class=\""+row_class+"\">").append(row));
                }                
            });
};

function set2ValueHeader(url, div, container) {
    getJSON(url,
            function(result) {
                var tabla = $(div);
                var border = $(container);
                
                for (var i = 0; i < result.length; i++){
                    var obj = result[i];
                    var row = "";
                    var row_class = "";
                    var container_class = "fd_primary1 border-fd_primary1";
                    var i = 1;
                    
                    for (var key in obj){
                        var attrName = key;
                        var attrValue = obj[key];
                        
                        if (i == 2) row_class = "pull-right";

                        if (attrName == "container_class") {
                            if (attrValue == "GREEN") container_class = "fd_green border-fd_green";
                            else if (attrValue == "YELLOW") container_class = "fd_yellow border-fd_yellow";
                            else if (attrValue == "RED") container_class = "fd_red border-fd_red";
                        }
                        else {
                            row = row + "<span class=\"" + row_class + "\">"+attrValue+"</span>";                        
                            i = i + 1;
                        }
                    }
                    
                    border.addClass(container_class);
                    tabla.append(row);
                }                
            });
};
                        
function setGrafico_d3(url, dom_grafico, grafico) {
    getJSON(url,
            function(result) {
                d3.select(dom_grafico)
                    .datum(result)
                    .call(grafico);
            });
};



function setBootstrapTable(url, table) {
    getJSON(url,
            function(result) {
                $(table).bootstrapTable({
                    data: result,
                    striped: true
                });
            });
};

function setGrafico_chart(url, dom_grafico, grafico) {
//    console.log();
    getJSON(url,
            function(result) {
                new Chart($(dom_grafico), {
                    type: grafico,
                    data: result
                });
            });
};

var user = 1;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Trafico

//// Panorama Mensual

////// Trafico total por mes

////// Grafico
function start_Performance_Vendedor_grafico(){

    nv.addGraph(function() {
        d3.select('#Performance_Vendedor_grafico svg > *').remove();
        
        Performance_Vendedor_grafico = nv.models.multiBarChart()
            .x(function(d) { return d.label })
            .rotateLabels(-45)
            .y(function(d) { return d.value })
            .yDomain([0, 150])
            .color(d3.scale.category20().range())
            .barColor(d3.scale.category10().range())
            .reduceXTicks(false)
            .duration(250)
            .margin({left: 75, right: 50, bottom: 150})
            .showControls(false)
            .useInteractiveGuideline(true);
            
        setGrafico_d3("../backend/comisiones.php?user="+user+"&action=Performance_Vendedor_grafico&canal=Account_GFS", '#Performance_Vendedor_grafico svg', Performance_Vendedor_grafico);

        Performance_Vendedor_grafico.update;
        
        return Performance_Vendedor_grafico;
    });
};

////// Semaforo
function start_Performance_Vendedor_detalle(){
    setTableSemaforo("../backend/comisiones.php?user="+user+"&action=Performance_Vendedor_detalle&canal=Account_GFS", '#Performance_Vendedor_detalle');
};

////// Header
function start_Performance_Vendedor_total(){
    set2ValueHeader("../backend/comisiones.php?user="+user+"&action=Performance_Vendedor_total&canal=Account_GFS&metrica=1", '#M1_value', '#M1_container');
    set2ValueHeader("../backend/comisiones.php?user="+user+"&action=Performance_Vendedor_total&canal=Account_GFS&metrica=2", '#M2_value', '#M2_container');
    set2ValueHeader("../backend/comisiones.php?user="+user+"&action=Performance_Vendedor_total&canal=Account_GFS&metrica=3", '#M3_value', '#M3_container');
    set2ValueHeader("../backend/comisiones.php?user="+user+"&action=Performance_Vendedor_total&canal=Account_GFS&metrica=4", '#M4_value', '#M4_container');
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var refresh_function = [];

$(document).ready(function() {
    NProgress.start();

    init_sidebar();
    NProgress.inc();
        
    start_Performance_Vendedor_grafico();
    NProgress.inc();
    start_Performance_Vendedor_detalle();
    NProgress.inc();
    start_Performance_Vendedor_total();
    NProgress.inc();
    
    NProgress.done();
    
    $('body').scrollspy({ target: '#sidebar-menu' });
    /*
    $("#link_tab_trafico_panorama_mensual_Trafico_Total").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Total_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Total_tendencia");
    });
    $("#link_tab_trafico_panorama_mensual_Tiempo_Promedio").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Tiempo_Promedio_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Tiempo_Promedio_tendencia");
    });
    $("#link_tab_trafico_panorama_mensual_Visitas").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Visitas_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Visitas_tendencia");
    });
    $("#link_tab_trafico_panorama_mensual_Abandono").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Abandono_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Abandono_tendencia");
    });
    $("#link_tab_trafico_panorama_mensual_Trafico_Neto").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Neto_acumulado");
        refresh_function.push("start_trafico_panorama_mensual_Trafico_Neto_tendencia");
    });

    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        NProgress.start();
        //alert(e.target); // newly activated tab
        //e.relatedTarget // previous active tab
        var i;
        for (i = 0; i < refresh_function.length; i++) {
            window[refresh_function[i]]();
        };
        NProgress.done();
    });
    */
});


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function login_check(){
    var email = $(document).find('#email').val();
    
    if (email != "") {
        var pass = $(document).find('#pass').val();
        var url = "service/login.php?email="+email+"&pass="+pass;
        
        getJSON(url,
                function(result) {
                    NProgress.start();
                    var status = result.STATUS;
                    var title = "";
                    var msg = result.MSG;
                    
                    if (status == "success") {
                        saveCookie(result.USER_ID);
                        window.location.href = 'audiencia/audiencia.html';
                    }
                    else {
                        title = "Error";
                    }
                    if (msg != "") new_pnotify(title, msg, status);
                    
                    NProgress.done();
                });
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function saveCookie(value) {
    var today = new Date(); // Actual date
    var expire = new Date(); // Expiration of the cookie

    var number_of_days = 3; // Number of days for the cookie to be valid (10 in this case)

    expire.setTime( today.getTime() + 60 * 60 * 1000 * 24 * number_of_days ); // Current time + (60 sec * 60 min * 1000 milisecs * 24 hours * number_of_days)

    document.cookie = COOKIE_NAME + "=" + escape(value) + "; expires=" + expire.toGMTString();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    NProgress.start();
    
    $('#email').focus();
    $('#email').keypress(function(e){
        if(e.which == 13){
            $('#pass').focus();
        }
    });
        
    $("#login").on("click", function() {
        login_check();
    });
    
    $('#pass').keypress(function(e){
        if(e.which == 13){
            $('#login').click();
        }
    });
    
    NProgress.done();
});

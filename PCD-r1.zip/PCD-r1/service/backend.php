<?php

include_once("data_lib.php");

include_once("user_lib.php");


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_users($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Nombre", "Email", "Password", "Supervisor", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "text", "action:save-all", "");
        
        $body = "SELECT USER_ID, USER_NAME, EMAIL, PASS, SUPERVISOR, 'Actualizar', 'Borrar'
                 FROM TB_USERS
                 ORDER BY USER_ID";
        $body_style = array("hidden+data-text", "data-text", "data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Nombre", "Email", "Password", "Supervisor", "", "");
        $head_style = array("hidden", "text", "text", "text", "text", "", "");
        
        $body = "SELECT 'NEW' AS USER_ID, '' AS USER_NAME, '' AS EMAIL, '' AS PASS, 'N' AS SUPERVISOR, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data", "data-text", "data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $body = "SELECT USER_ID AS ID, USER_NAME AS NAME
                 FROM TB_USERS
                 ORDER BY USER_ID";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "INSERT INTO TB_USERS (USER_NAME, EMAIL, PASS, SUPERVISOR) VALUES (".$f1.", ".$f2.", ".$f3.", ".$f4.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "UPDATE TB_USERS SET USER_NAME=".$f1.", EMAIL=".$f2.", PASS=".$f3.", SUPERVISOR=".$f4." WHERE USER_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $query = "DELETE FROM TB_USERS WHERE USER_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_channel($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Canal", "Descripción", "Grupo", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "action:save-all", "");
        
        $body = "SELECT CHANNEL_ID, CHANNEL_NAME, CHANNEL_DISPLAY, CHANNEL_GROUP, 'Actualizar', 'Borrar'
                 FROM TB_CHANNEL
                 ORDER BY CHANNEL_ID";
        $body_style = array("hidden+data-text", "data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Canal", "Descripción", "Grupo", "", "");
        $head_style = array("hidden", "text", "text", "text", "", "");
        
        $body = "SELECT 'NEW' AS CHANNEL_ID, '' AS CHANNEL_NAME, '' AS CHANNEL_DISPLAY, '' AS CHANNEL_GROUP, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $body = "SELECT CHANNEL_ID AS ID, CHANNEL_DISPLAY AS NAME
                 FROM TB_CHANNEL
                 ORDER BY CHANNEL_ID";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "INSERT INTO TB_CHANNEL (CHANNEL_NAME, CHANNEL_DISPLAY, CHANNEL_GROUP) VALUES (".$f1.", ".$f2.", ".$f3.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "UPDATE TB_CHANNEL SET CHANNEL_NAME=".$f1.", CHANNEL_DISPLAY=".$f2.", CHANNEL_GROUP=".$f3." WHERE CHANNEL_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $query = "DELETE FROM TB_CHANNEL WHERE CHANNEL_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_competidor($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Nombre", "Logo", "Color", "Web", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "text", "action:save-all", "");
        
        $body = "SELECT COMPETIDOR_ID, COMPETIDOR_NAME, LOGO, COLOR, WEB, 'Actualizar', 'Borrar'
                 FROM TB_COMPETIDOR
                 ORDER BY COMPETIDOR_ID";
        $body_style = array("hidden+data-text", "data-text", "data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Nombre", "Logo", "Color", "Web", "", "");
        $head_style = array("hidden", "text", "text", "text", "text", "", "");
        
        $body = "SELECT 'NEW' AS COMPETIDOR_ID, '' AS COMPETIDOR_NAME, '' AS LOGO, '' AS COLOR, '' AS WEB, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-text", "data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $body = "SELECT COMPETIDOR_ID AS ID, COMPETIDOR_NAME AS NAME
                 FROM TB_COMPETIDOR
                 ORDER BY COMPETIDOR_ID";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "INSERT INTO TB_COMPETIDOR (COMPETIDOR_NAME, LOGO, COLOR, WEB) VALUES (".$f1.", ".$f2.", ".$f3.", ".$f4.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "UPDATE TB_COMPETIDOR SET COMPETIDOR_NAME=".$f1.", LOGO=".$f2.", COLOR=".$f3.", WEB=".$f4." WHERE COMPETIDOR_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $query = "DELETE FROM TB_COMPETIDOR WHERE COMPETIDOR_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_industry($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Industria", "Descripción", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "action:save-all", "");
        
        $body = "SELECT INDUSTRY_ID, INDUSTRY_NAME, INDUSTRY_DISPLAY, 'Actualizar', 'Borrar'
                 FROM TB_INDUSTRY
                 ORDER BY INDUSTRY_ID";
        $body_style = array("hidden+data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Industria", "Descripción", "", "");
        $head_style = array("hidden", "text", "text", "", "");
        
        $body = "SELECT 'NEW' AS INDUSTRY_ID, '' AS INDUSTRY_NAME, '' AS INDUSTRY_DISPLAY, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $body = "SELECT INDUSTRY_ID AS ID, INDUSTRY_DISPLAY AS NAME
                 FROM TB_INDUSTRY
                 ORDER BY INDUSTRY_ID";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "INSERT INTO TB_INDUSTRY (INDUSTRY_NAME, INDUSTRY_DISPLAY) VALUES (".$f1.", ".$f2.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "UPDATE TB_INDUSTRY SET INDUSTRY_NAME=".$f1.", INDUSTRY_DISPLAY=".$f2." WHERE INDUSTRY_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $query = "DELETE FROM TB_INDUSTRY WHERE INDUSTRY_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_social($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Red Social", "Descripción", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "action:save-all", "");
        
        $body = "SELECT SOCIAL_ID, SOCIAL_NAME, SOCIAL_DISPLAY, 'Actualizar', 'Borrar'
                 FROM TB_SOCIAL
                 ORDER BY SOCIAL_ID";
        $body_style = array("hidden+data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Red Social", "Descripción", "", "");
        $head_style = array("hidden", "text", "text", "", "");
        
        $body = "SELECT 'NEW' AS SOCIAL_ID, '' AS SOCIAL_NAME, '' AS SOCIAL_DISPLAY, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $body = "SELECT SOCIAL_ID AS ID, SOCIAL_DISPLAY AS NAME
                 FROM TB_SOCIAL
                 ORDER BY SOCIAL_ID";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "INSERT INTO TB_SOCIAL (SOCIAL_NAME, SOCIAL_DISPLAY) VALUES (".$f1.", ".$f2.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "UPDATE TB_SOCIAL SET SOCIAL_NAME=".$f1.", SOCIAL_DISPLAY=".$f2." WHERE SOCIAL_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $query = "DELETE FROM TB_SOCIAL WHERE SOCIAL_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_domain_type($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Tipo", "Descripción", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "action:save-all", "");
        
        $body = "SELECT TYPE_ID, TYPE_NAME, TYPE_DISPLAY, 'Actualizar', 'Borrar'
                 FROM TB_DOMAIN_TYPE
                 ORDER BY TYPE_ID";
        $body_style = array("hidden+data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Tipo", "Descripción", "", "");
        $head_style = array("hidden", "text", "text", "", "");
        
        $body = "SELECT 'NEW' AS TYPE_ID, '' AS TYPE_NAME, '' AS TYPE_DISPLAY, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $body = "SELECT TYPE_ID AS ID, TYPE_DISPLAY AS NAME
                 FROM TB_DOMAIN_TYPE
                 ORDER BY TYPE_ID";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "INSERT INTO TB_DOMAIN_TYPE (TYPE_NAME, TYPE_DISPLAY) VALUES (".$f1.", ".$f2.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "UPDATE TB_DOMAIN_TYPE SET TYPE_NAME=".$f1.", TYPE_DISPLAY=".$f1." WHERE TYPE_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $query = "DELETE FROM TB_DOMAIN_TYPE WHERE TYPE_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_subdomain_type($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Tipo", "Descripción", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "action:save-all", "");
        
        $body = "SELECT TYPE_ID, TYPE_NAME, TYPE_DISPLAY, 'Actualizar', 'Borrar'
                 FROM TB_SUBDOMAIN_TYPE
                 ORDER BY TYPE_ID";
        $body_style = array("hidden+data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Tipo", "Descripción", "", "");
        $head_style = array("hidden", "text", "text", "", "");
        
        $body = "SELECT 'NEW' AS TYPE_ID, '' AS TYPE_NAME, '' AS TYPE_DISPLAY, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $body = "SELECT TYPE_ID AS ID, TYPE_DISPLAY AS NAME
                 FROM TB_SUBDOMAIN_TYPE
                 ORDER BY TYPE_ID";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "INSERT INTO TB_SUBDOMAIN_TYPE (TYPE_NAME, TYPE_DISPLAY) VALUES (".$f1.", ".$f2.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "UPDATE TB_SUBDOMAIN_TYPE SET TYPE_NAME=".$f1.", TYPE_DISPLAY=".$f1." WHERE TYPE_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $query = "DELETE FROM TB_SUBDOMAIN_TYPE WHERE TYPE_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_pcd_template($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;

    $MODO_query = "SELECT 1 AS ID, 'Mensual' AS NAME UNION SELECT 2 AS ID, 'Bimestral' AS NAME";
    $MODO_lookup = lookup_simple($MODO_query);
        
    if ($action == "get-all") {
        $head = array("Id", "Competidor 1", "Competidor 2", "Competidor 3", "Competidor 4", "Modo", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "text", "text", "action:save-all", "");
        
        $lookup1 = get_competidor("get-lookup", "", "");
        
        $body = "SELECT PCD_ID, COMPETIDOR_ID_1, COMPETIDOR_ID_2, COMPETIDOR_ID_3, COMPETIDOR_ID_4, MODO, 'Actualizar', 'Borrar'
                 FROM TB_PCD_TEMPLATE
                 ORDER BY PCD_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup1, "data-select:".$lookup1, "data-select:".$lookup1, "data-select:".$MODO_lookup, "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Competidor 1", "Competidor 2", "Competidor 3", "Competidor 4", "Modo", "", "");
        $head_style = array("hidden", "text", "text", "text", "text", "text", "", "");

        $lookup1 = get_competidor("get-lookup", "", "");
        
        $body = "SELECT 'NEW' AS PCD_ID, '' AS COMPETIDOR_ID_1, '' AS COMPETIDOR_ID_2, '' AS COMPETIDOR_ID_3, '' AS COMPETIDOR_ID_4, 2 AS MODO, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup1, "data-select:".$lookup1, "data-select:".$lookup1, "data-select:".$MODO_lookup, "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $body = "SELECT P.PCD_ID AS ID, CONCAT(CONCAT(CONCAT(C1.COMPETIDOR_NAME, COALESCE(CONCAT(' | ',C2.COMPETIDOR_NAME),'')), COALESCE(CONCAT(' | ',C3.COMPETIDOR_NAME),'')), COALESCE(CONCAT(' | ',C4.COMPETIDOR_NAME),'')) AS NAME
                 FROM TB_PCD_TEMPLATE P
                 LEFT OUTER JOIN TB_COMPETIDOR C1 ON C1.COMPETIDOR_ID=P.COMPETIDOR_ID_1
                 LEFT OUTER JOIN TB_COMPETIDOR C2 ON C2.COMPETIDOR_ID=P.COMPETIDOR_ID_2
                 LEFT OUTER JOIN TB_COMPETIDOR C3 ON C3.COMPETIDOR_ID=P.COMPETIDOR_ID_3
                 LEFT OUTER JOIN TB_COMPETIDOR C4 ON C4.COMPETIDOR_ID=P.COMPETIDOR_ID_4
                 ORDER BY PCD_ID";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $query = "INSERT INTO TB_PCD_TEMPLATE (COMPETIDOR_ID_1, COMPETIDOR_ID_2, COMPETIDOR_ID_3, COMPETIDOR_ID_4, MODO) VALUES (".$f1.", ".$f2.", ".$f3.", ".$f4.", ".$f5.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $query = "UPDATE TB_PCD_TEMPLATE SET COMPETIDOR_ID_1=".$f1.", COMPETIDOR_ID_2=".$f2.", COMPETIDOR_ID_3=".$f3.", COMPETIDOR_ID_4=".$f4.", MODO=".$f5." WHERE PCD_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $query = "DELETE FROM TB_PCD_TEMPLATE WHERE PCD_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_users_pcd($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Id", "Usuario", "Informe", "Actualizar Todo", "");
        $head_style = array("hidden", "hidden", "text", "text", "action:save-all", "");

        $where = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND USER_ID=".$w0;
                else $where = "WHERE USER_ID=".$w0;
            }
            $w1 = explode($SEP_TEXT, $filter)[1];
            if ($w1 != "") {
                if ($where != "") $where = $where." AND PCD_ID=".$w1;
                else $where = "WHERE PCD_ID=".$w1;
            }
        }
        
        $lookup1 = get_users("get-lookup", "", "");
        $lookup2 = get_pcd_template("get-lookup", "", "");
        
        $body = "SELECT USER_ID AS ID1, PCD_ID AS ID2, USER_ID, PCD_ID, 'Actualizar', 'Borrar'
                 FROM TB_USERS_PCD
                 ".$where."
                 ORDER BY USER_ID, PCD_ID";
        $body_style = array("hidden+data-text", "hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Usuario", "Informe", "", "");
        $head_style = array("text", "text", "", "");
        
        $w0 = "";
        $w1 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            $w1 = explode($SEP_TEXT, $filter)[1];
        }

        $lookup1 = get_users("get-lookup", "", "");
        $lookup2 = get_pcd_template("get-lookup", "", "");
        
        $body = "SELECT '".$w0."' AS USER_ID, '".$w1."' AS PCD_ID, 'Agregar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "data-select:".$lookup2, "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Usuario", "Informe", "", "");
        $head_style = array("text", "text", "", "");

        $lookup1 = get_users("get-lookup", "", "");
        $lookup2 = get_pcd_template("get-lookup", "", "");
        
        $body = "SELECT '' AS USER_ID, '' AS PCD_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "data-select:".$lookup2, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id0 = number_to_null(explode($SEP_TEXT, $line)[0]);
            $id1 = number_to_null(explode($SEP_TEXT, $line)[1]);
            $query = "INSERT INTO TB_USERS_PCD (USER_ID, PCD_ID) VALUES (".$id0.", ".$id1.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id0 = number_to_null(explode($SEP_TEXT, $line)[0]);
            $id1 = number_to_null(explode($SEP_TEXT, $line)[1]);
            $query = "UPDATE TB_USERS_PCD SET USER_ID=".$id0.", PCD_ID=".$id1." WHERE USER_ID=".$id0." AND PCD_ID=".$id1;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id0 = number_to_null(explode($SEP_TEXT, $line)[0]);
            $id1 = number_to_null(explode($SEP_TEXT, $line)[1]);
            $query = "DELETE FROM TB_USERS_PCD WHERE USER_ID=".$id0." AND PCD_ID=".$id1;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_pcd_month($action, $data, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Informe", "Año", "Mes", "");
        $head_style = array("text", "text", "text", "");
        
        $id0 = number_to_null(explode($SEP_TEXT, $filter)[0]);
        $id1 = number_to_null(explode($SEP_TEXT, $filter)[1]);
        $id2 = number_to_null(explode($SEP_TEXT, $filter)[2]);
        
        $lookup1 = get_pcd_template("get-lookup", "", "");
        
        $body = "SELECT PCD_ID, YEAR, MONTH, 'Borrar'
                 FROM TB_PCD_MONTH
                 WHERE PCD_ID=".$id0." AND YEAR=".$id1." AND MONTH=".$id2."";
        $body_style = array("data-select:".$lookup1, "data-year", "data-month", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Informe", "Año", "Mes", "");
        $head_style = array("text", "text", "text", "");
        
        $lookup1 = get_pcd_template("get-lookup", "", "");
        
        $body = "SELECT '' AS PCD_ID, EXTRACT(YEAR FROM CURRENT_DATE) AS YEAR_NUM, EXTRACT(MONTH FROM CURRENT_DATE) AS MONTH_NUM, 'Cargar'";
        $body_style = array("data-select:".$lookup1, "data-year", "data-month", "action:add-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-lookup") {
        $id0 = number_to_null(explode($SEP_TEXT, $filter)[0]);
        $id1 = number_to_null(explode($SEP_TEXT, $filter)[1]);
        $id2 = number_to_null(explode($SEP_TEXT, $filter)[2]);
        
        $body = "SELECT C1.COMPETIDOR_ID AS ID, C1.COMPETIDOR_NAME AS NAME
                 FROM TB_PCD_MONTH P
                 INNER JOIN TB_COMPETIDOR C1 ON C1.COMPETIDOR_ID=P.COMPETIDOR_ID_1
                 WHERE P.PCD_ID=".$id0." AND P.YEAR=".$id1." AND P.MONTH=".$id2."
                 UNION
                 SELECT C2.COMPETIDOR_ID AS ID, C2.COMPETIDOR_NAME AS NAME
                 FROM TB_PCD_MONTH P
                 INNER JOIN TB_COMPETIDOR C2 ON C2.COMPETIDOR_ID=P.COMPETIDOR_ID_2
                 WHERE P.PCD_ID=".$id0." AND P.YEAR=".$id1." AND P.MONTH=".$id2."
                 UNION
                 SELECT C3.COMPETIDOR_ID AS ID, C3.COMPETIDOR_NAME AS NAME
                 FROM TB_PCD_MONTH P
                 INNER JOIN TB_COMPETIDOR C3 ON C3.COMPETIDOR_ID=P.COMPETIDOR_ID_3
                 WHERE P.PCD_ID=".$id0." AND P.YEAR=".$id1." AND P.MONTH=".$id2."
                 UNION
                 SELECT C4.COMPETIDOR_ID AS ID, C4.COMPETIDOR_NAME AS NAME
                 FROM TB_PCD_MONTH P
                 INNER JOIN TB_COMPETIDOR C4 ON C4.COMPETIDOR_ID=P.COMPETIDOR_ID_4
                 WHERE P.PCD_ID=".$id0." AND P.YEAR=".$id1." AND P.MONTH=".$id2."
                 ORDER BY 1";
        return lookup_simple($body);
    }
    else if ($action == "insert") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id0 = number_to_null(explode($SEP_TEXT, $line)[0]);
            $id1 = number_to_null(explode($SEP_TEXT, $line)[1]);
            $id2 = number_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "INSERT INTO TB_PCD_MONTH (PCD_ID, YEAR, MONTH, COMPETIDOR_ID_1, COMPETIDOR_ID_2, COMPETIDOR_ID_3, COMPETIDOR_ID_4)
                      SELECT P.PCD_ID, ".$id1." AS YEAR_NUM, ".$id2." AS MONTH_NUM, P.COMPETIDOR_ID_1, P.COMPETIDOR_ID_2, P.COMPETIDOR_ID_3, P.COMPETIDOR_ID_4
                      FROM TB_PCD_TEMPLATE P
                      WHERE P.PCD_ID = ".$id0." AND
                            NOT EXISTS (SELECT 1 FROM TB_PCD_MONTH M WHERE M.PCD_ID=P.PCD_ID AND M.YEAR=".$id1." AND M.MONTH=".$id2.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id0 = number_to_null(explode($SEP_TEXT, $line)[0]);
            $id1 = number_to_null(explode($SEP_TEXT, $line)[1]);
            $id2 = number_to_null(explode($SEP_TEXT, $line)[2]);
            $query = "DELETE FROM TB_PCD_MONTH WHERE PCD_ID=".$id0." AND YEAR=".$id1." AND MONTH=".$id2;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_audiencia($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Competidor", "Industria", "Valor", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND COMPETIDOR_ID=".$w0;
                else $where = "WHERE COMPETIDOR_ID=".$w0;
            }
            $w1 = explode($SEP_TEXT, $filter)[1];
            if ($w1 != "") {
                if ($where != "") $where = $where." AND INDUSTRY_ID=".$w1;
                else $where = "WHERE INDUSTRY_ID=".$w1;
            }
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_industry("get-lookup", "", "");

        $body = "SELECT AUDIENCIA_ID, COMPETIDOR_ID, INDUSTRY_ID, VALUE, 'Actualizar', 'Borrar'
                 FROM TB_AUDIENCIA
                 ".$where."
                 ORDER BY AUDIENCIA_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Competidor", "Industria", "Valor", "", "");
        $head_style = array("hidden", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        $w1 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            $w1 = explode($SEP_TEXT, $filter)[1];
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_industry("get-lookup", "", "");
        
        $body = "SELECT 'NEW' AS AUDIENCIA_ID, '".$w0."' AS COMPETIDOR_ID, '".$w1."' AS INDUSTRY_ID, '' AS VALUE, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Competidor", "Industria", "", "");
        $head_style = array("text", "text", "", "");

        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_industry("get-lookup", "", "");
        
        $body = "SELECT '' AS COMPETIDOR_ID, '' AS INDUSTRY_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "data-select:".$lookup2, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "INSERT INTO TB_AUDIENCIA (YEAR, MONTH, COMPETIDOR_ID, INDUSTRY_ID, VALUE) VALUES (".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "UPDATE TB_AUDIENCIA SET COMPETIDOR_ID=".$f1.", INDUSTRY_ID=".$f2.", VALUE=".$f3." WHERE AUDIENCIA_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "DELETE FROM TB_AUDIENCIA WHERE AUDIENCIA_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_audiencia_indu_sites($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Industria", "Posición", "Sitio", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND INDUSTRY_ID=".$w0;
                else $where = "WHERE INDUSTRY_ID=".$w0;
            }
        }
        
        $lookup1 = get_industry("get-lookup", "", "");

        $body = "SELECT AUDIENCIA_INDU_SITE_ID, INDUSTRY_ID, POSITION, SITE, 'Actualizar', 'Borrar'
                 FROM TB_AUDIENCIA_INDU_SITES
                 ".$where."
                 ORDER BY AUDIENCIA_INDU_SITE_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Industria", "Posición", "Sitio", "", "");
        $head_style = array("hidden", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
        }
        
        $lookup1 = get_industry("get-lookup", "", "");
        
        $body = "SELECT 'NEW' AS AUDIENCIA_INDU_SITE_ID, '".$w0."' AS INDUSTRY_ID, '' AS POSITION, '' AS SITE, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Industria", "", "");
        $head_style = array("text", "", "");

        $lookup1 = get_industry("get-lookup", "", "");
        
        $body = "SELECT '' AS INDUSTRY_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "INSERT INTO TB_AUDIENCIA_INDU_SITES (YEAR, MONTH, INDUSTRY_ID, POSITION, SITE) VALUES (".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "UPDATE TB_AUDIENCIA_INDU_SITES SET INDUSTRY_ID=".$f1.", POSITION=".$f2.", SITE=".$f3." WHERE AUDIENCIA_INDU_SITE_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "DELETE FROM TB_AUDIENCIA_INDU_SITES WHERE AUDIENCIA_INDU_SITE_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_audiencia_sites($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Competidor", "Posición", "Sitio", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND COMPETIDOR_ID=".$w0;
                else $where = "WHERE COMPETIDOR_ID=".$w0;
            }
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);

        $body = "SELECT AUDIENCIA_SITE_ID, COMPETIDOR_ID, POSITION, SITE, 'Actualizar', 'Borrar'
                 FROM TB_AUDIENCIA_SITES
                 ".$where."
                 ORDER BY AUDIENCIA_SITE_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Competidor", "Posición", "Sitio", "", "");
        $head_style = array("hidden", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        
        $body = "SELECT 'NEW' AS AUDIENCIA_SITE_ID, '".$w0."' AS COMPETIDOR_ID, '' AS POSITION, '' AS SITE, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Competidor", "", "");
        $head_style = array("text", "", "");

        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        
        $body = "SELECT '' AS COMPETIDOR_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "INSERT INTO TB_AUDIENCIA_SITES (YEAR, MONTH, COMPETIDOR_ID, POSITION, SITE) VALUES (".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "UPDATE TB_AUDIENCIA_SITES SET COMPETIDOR_ID=".$f1.", POSITION=".$f2.", SITE=".$f3." WHERE AUDIENCIA_SITE_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "DELETE FROM TB_AUDIENCIA_SITES WHERE AUDIENCIA_SITE_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_audiencia_wordcloud($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Competidor", "Industria", "Palabra", "Peso", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND COMPETIDOR_ID=".$w0;
                else $where = "WHERE COMPETIDOR_ID=".$w0;
            }
            $w1 = explode($SEP_TEXT, $filter)[1];
            if ($w1 != "") {
                if ($where != "") $where = $where." AND INDUSTRY_ID=".$w1;
                else $where = "WHERE INDUSTRY_ID=".$w1;
            }
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_industry("get-lookup", "", "");

        $body = "SELECT AUDIENCIA_WORD_ID, COMPETIDOR_ID, INDUSTRY_ID, WORD, WEIGHT, 'Actualizar', 'Borrar'
                 FROM TB_AUDIENCIA_WORDCLOUD
                 ".$where."
                 ORDER BY AUDIENCIA_WORD_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Competidor", "Industria", "Palabra", "Peso", "", "");
        $head_style = array("hidden", "text", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        $w1 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            $w1 = explode($SEP_TEXT, $filter)[1];
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_industry("get-lookup", "", "");
        
        $body = "SELECT 'NEW' AS AUDIENCIA_WORD_ID, '".$w0."' AS COMPETIDOR_ID, '".$w1."' AS INDUSTRY_ID, '' AS WORD, '' AS WEIGHT, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Competidor", "Industria", "", "");
        $head_style = array("text", "text", "", "");

        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_industry("get-lookup", "", "");
        
        $body = "SELECT '' AS COMPETIDOR_ID, '' AS INDUSTRY_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "data-select:".$lookup2, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "INSERT INTO TB_AUDIENCIA_WORDCLOUD (YEAR, MONTH, COMPETIDOR_ID, INDUSTRY_ID, WORD, WEIGHT) VALUES (".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.", ".$f4.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "UPDATE TB_AUDIENCIA_WORDCLOUD SET COMPETIDOR_ID=".$f1.", INDUSTRY_ID=".$f2.", WORD=".$f3.", WEIGHT=".$f4." WHERE AUDIENCIA_WORD_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "DELETE FROM TB_AUDIENCIA_WORDCLOUD WHERE AUDIENCIA_WORD_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_panorama($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Competidor", "Canal", "Tráfico", "Duración", "Páginas", "Abandono", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND COMPETIDOR_ID=".$w0;
                else $where = "WHERE COMPETIDOR_ID=".$w0;
            }
            $w1 = explode($SEP_TEXT, $filter)[1];
            if ($w1 != "") {
                if ($where != "") $where = $where." AND CHANNEL_ID=".$w1;
                else $where = "WHERE CHANNEL_ID=".$w1;
            }
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_channel("get-lookup", "", "");

        $body = "SELECT PANORAMA_ID, COMPETIDOR_ID, CHANNEL_ID, TRAFFIC, DURATION, PAGES, BOUNCE, 'Actualizar', 'Borrar'
                 FROM TB_PANORAMA
                 ".$where."
                 ORDER BY PANORAMA_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Competidor", "Canal", "Tráfico", "Duración", "Páginas", "Abandono", "", "");
        $head_style = array("hidden", "text", "text", "text", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        $w1 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            $w1 = explode($SEP_TEXT, $filter)[1];
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_channel("get-lookup", "", "");
        
        $body = "SELECT 'NEW' AS PANORAMA_ID, '".$w0."' AS COMPETIDOR_ID, '".$w1."' AS CHANNEL_ID, '' AS TRAFFIC, '' AS DURATION, '' AS PAGES, '' AS BOUNCE, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Competidor", "Canal", "", "");
        $head_style = array("text", "text", "", "");

        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_channel("get-lookup", "", "");
        
        $body = "SELECT '' AS COMPETIDOR_ID, '' AS CHANNEL_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "data-select:".$lookup2, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $f6 = string_to_null(explode($SEP_TEXT, $line)[6]);
            $query = "INSERT INTO TB_PANORAMA (YEAR, MONTH, COMPETIDOR_ID, CHANNEL_ID, TRAFFIC, DURATION, PAGES, BOUNCE) VALUES (".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.", ".$f4.", ".$f5.", ".$f6.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $f6 = string_to_null(explode($SEP_TEXT, $line)[6]);
            $query = "UPDATE TB_PANORAMA SET COMPETIDOR_ID=".$f1.", CHANNEL_ID=".$f2.", TRAFFIC=".$f3.", DURATION=".$f4.", PAGES=".$f5.", BOUNCE=".$f6." WHERE PANORAMA_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $f6 = string_to_null(explode($SEP_TEXT, $line)[6]);
            $query = "DELETE FROM TB_PANORAMA WHERE PANORAMA_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_panorama_social($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Competidor", "Red Social", "Share", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND COMPETIDOR_ID=".$w0;
                else $where = "WHERE COMPETIDOR_ID=".$w0;
            }
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_social("get-lookup", "", "");

        $body = "SELECT PSOCIAL_ID, COMPETIDOR_ID, SOCIAL_ID, SHARE, 'Actualizar', 'Borrar'
                 FROM TB_PANORAMA_SOCIAL
                 ".$where."
                 ORDER BY PSOCIAL_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Competidor", "Red Social", "Share", "", "");
        $head_style = array("hidden", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        $w1 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            $w1 = explode($SEP_TEXT, $filter)[1];
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_social("get-lookup", "", "");
        
        $body = "SELECT 'NEW' AS PSOCIAL_ID, '".$w0."' AS COMPETIDOR_ID, '".$w1."' AS SOCIAL_ID, '' AS SHARE, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Competidor", "Red Social", "", "");
        $head_style = array("text", "text", "", "");

        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_social("get-lookup", "", "");
        
        $body = "SELECT '' AS COMPETIDOR_ID, '' AS SOCIAL_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "data-select:".$lookup2, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "INSERT INTO TB_PANORAMA_SOCIAL (YEAR, MONTH, COMPETIDOR_ID, SOCIAL_ID, SHARE) VALUES (".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "UPDATE TB_PANORAMA_SOCIAL SET COMPETIDOR_ID=".$f1.", SOCIAL_ID=".$f2.", SHARE=".$f3." WHERE PSOCIAL_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $query = "DELETE FROM TB_PANORAMA_SOCIAL WHERE PSOCIAL_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_panorama_domain($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Tipo", "Posición", "Sitio", "Total", "Share Competidor 1", "Share Competidor 2", "Share Competidor 3", "Share Competidor 4", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "text", "text", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE PCD_ID=".$id0." AND YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND TYPE_ID=".$w0;
                else $where = "WHERE TYPE_ID=".$w0;
            }
        }
        
        $lookup1 = get_domain_type("get-lookup", "", "");

        $body = "SELECT DOMAIN_ID, TYPE_ID, POSITION, SITE, TOTAL, COMPETIDOR_SHARE_1, COMPETIDOR_SHARE_2, COMPETIDOR_SHARE_3, COMPETIDOR_SHARE_4, 'Actualizar', 'Borrar'
                 FROM TB_PANORAMA_DOMAIN
                 ".$where."
                 ORDER BY DOMAIN_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-text", "data-text", "data-text", "data-text", "data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Tipo", "Posición", "Sitio", "Total", "Share Competidor 1", "Share Competidor 2", "Share Competidor 3", "Share Competidor 4", "", "");
        $head_style = array("hidden", "text", "text", "text", "text", "text", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
        }
        
        $lookup1 = get_domain_type("get-lookup", "", "");
        
        $body = "SELECT 'NEW' AS DOMAIN_ID, '".$w0."' AS TYPE_ID, '' AS POSITION, '' AS SITE, '' AS TOTAL, '' AS COMPETIDOR_SHARE_1, '' AS COMPETIDOR_SHARE_2, '' AS COMPETIDOR_SHARE_3, '' AS COMPETIDOR_SHARE_4, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-text", "data-text", "data-text", "data-text", "data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Tipo", "", "");
        $head_style = array("text", "", "");

        $lookup1 = get_domain_type("get-lookup", "", "");
        
        $body = "SELECT '' AS TYPE_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $f6 = string_to_null(explode($SEP_TEXT, $line)[6]);
            $f7 = string_to_null(explode($SEP_TEXT, $line)[7]);
            $f8 = string_to_null(explode($SEP_TEXT, $line)[8]);
            $query = "INSERT INTO TB_PANORAMA_DOMAIN (PCD_ID, YEAR, MONTH, TYPE_ID, POSITION, SITE, TOTAL, COMPETIDOR_SHARE_1, COMPETIDOR_SHARE_2, COMPETIDOR_SHARE_3, COMPETIDOR_SHARE_4) VALUES (".$id0.", ".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.", ".$f4.", ".$f5.", ".$f6.", ".$f7.", ".$f8.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $f6 = string_to_null(explode($SEP_TEXT, $line)[6]);
            $f7 = string_to_null(explode($SEP_TEXT, $line)[7]);
            $f8 = string_to_null(explode($SEP_TEXT, $line)[8]);
            $query = "UPDATE TB_PANORAMA_DOMAIN SET TYPE_ID=".$f1.", POSITION=".$f2.", SITE=".$f3.", TOTAL=".$f4.", COMPETIDOR_SHARE_1=".$f5.", COMPETIDOR_SHARE_2=".$f6.", COMPETIDOR_SHARE_3=".$f6.", COMPETIDOR_SHARE_4=".$f6." WHERE DOMAIN_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $f6 = string_to_null(explode($SEP_TEXT, $line)[6]);
            $f7 = string_to_null(explode($SEP_TEXT, $line)[7]);
            $f8 = string_to_null(explode($SEP_TEXT, $line)[8]);
            $query = "DELETE FROM TB_PANORAMA_DOMAIN WHERE DOMAIN_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_panorama_outlink($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Competidor", "Posición", "Sitio", "Share", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND COMPETIDOR_ID=".$w0;
                else $where = "WHERE COMPETIDOR_ID=".$w0;
            }
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_subdomain_type("get-lookup", "", "");

        $body = "SELECT OUTLINKS_ID, COMPETIDOR_ID, POSITION, SITE, SHARE, 'Actualizar', 'Borrar'
                 FROM TB_PANORAMA_OUTLINK
                 ".$where."
                 ORDER BY OUTLINKS_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Competidor", "Posición", "Sitio", "Share", "", "");
        $head_style = array("hidden", "text", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        
        $body = "SELECT 'NEW' AS OUTLINKS_ID, '".$w0."' AS COMPETIDOR_ID, '' AS POSITION, '' AS SITE, '' AS SHARE, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Competidor", "", "");
        $head_style = array("text", "", "");

        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        
        $body = "SELECT '' AS COMPETIDOR_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "INSERT INTO TB_PANORAMA_OUTLINK (YEAR, MONTH, COMPETIDOR_ID, POSITION, SITE, SHARE) VALUES (".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.", ".$f4.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "UPDATE TB_PANORAMA_OUTLINK SET COMPETIDOR_ID=".$f1.", POSITION=".$f2.", SITE=".$f3.", SHARE=".$f4." WHERE OUTLINKS_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $query = "DELETE FROM TB_PANORAMA_OUTLINK WHERE OUTLINKS_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}

function get_panorama_subdomain($action, $data, $fcontext, $filter) {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    if ($action == "get-all") {
        $head = array("Id", "Competidor", "Tipo", "Posición", "Sitio", "Share", "Actualizar Todo", "");
        $head_style = array("hidden", "text", "text", "text", "text", "text", "action:save-all", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $where = "WHERE YEAR=".$id1." AND MONTH=".$id2;
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            if ($w0 != "") {
                if ($where != "") $where = $where." AND COMPETIDOR_ID=".$w0;
                else $where = "WHERE COMPETIDOR_ID=".$w0;
            }
            $w1 = explode($SEP_TEXT, $filter)[1];
            if ($w1 != "") {
                if ($where != "") $where = $where." AND TYPE_ID=".$w1;
                else $where = "WHERE TYPE_ID=".$w1;
            }
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_subdomain_type("get-lookup", "", "");

        $body = "SELECT SUBDOMAIN_ID, COMPETIDOR_ID, TYPE_ID, POSITION, SITE, SHARE, 'Actualizar', 'Borrar'
                 FROM TB_PANORAMA_SUBDOMAIN
                 ".$where."
                 ORDER BY SUBDOMAIN_ID";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "data-text", "data-text", "action:save", "action:delete");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-new") {
        $head = array("Id", "Competidor", "Tipo", "Posición", "Sitio", "Share", "", "");
        $head_style = array("hidden", "text", "text", "text", "text", "text", "", "");
        
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        
        $w0 = "";
        $w1 = "";
        if ($filter != "") {
            $w0 = explode($SEP_TEXT, $filter)[0];
            $w1 = explode($SEP_TEXT, $filter)[1];
        }
        
        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_subdomain_type("get-lookup", "", "");
        
        $body = "SELECT 'NEW' AS SUBDOMAIN_ID, '".$w0."' AS COMPETIDOR_ID, '".$w1."' AS TYPE_ID, '' AS POSITION, '' AS SITE, '' AS SHARE, 'Agregar', 'Limpiar'";
        $body_style = array("hidden+data-text", "data-select:".$lookup1, "data-select:".$lookup2, "data-text", "data-text", "data-text", "action:add-row", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "get-filter") {
        $head = array("Competidor", "Tipo", "", "");
        $head_style = array("text", "text", "", "");

        $lookup1 = get_pcd_month("get-lookup", "", $fcontext);
        $lookup2 = get_subdomain_type("get-lookup", "", "");
        
        $body = "SELECT '' AS COMPETIDOR_ID, '' AS TYPE_ID, 'Filtrar', 'Limpiar'";
        $body_style = array("data-select:".$lookup1, "data-select:".$lookup2, "action:filter", "action:clear-row");
        
        to_json(array(
                    array("type"=>"head", "data"=>$head, "style"=>$head_style),
                    array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
                ));
    }
    else if ($action == "insert") {
        $response = [];
        $id0 = explode($SEP_TEXT, $fcontext)[0];
        $id1 = explode($SEP_TEXT, $fcontext)[1];
        $id2 = explode($SEP_TEXT, $fcontext)[2];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $query = "INSERT INTO TB_PANORAMA_SUBDOMAIN (YEAR, MONTH, COMPETIDOR_ID, TYPE_ID, POSITION, SITE, SHARE) VALUES (".$id1.", ".$id2.", ".$f1.", ".$f2.", ".$f3.", ".$f4.", ".$f5.")";
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "update") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $query = "UPDATE TB_PANORAMA_SUBDOMAIN SET COMPETIDOR_ID=".$f1.", TYPE_ID=".$f2.", POSITION=".$f3.", SITE=".$f4.", SHARE=".$f5." WHERE SUBDOMAIN_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
    else if ($action == "delete") {
        $response = [];
        foreach (explode($EOL_TEXT, $data) as $line) {
            $id = number_to_null(explode($SEP_TEXT, $line)[0]);
            $f1 = string_to_null(explode($SEP_TEXT, $line)[1]);
            $f2 = string_to_null(explode($SEP_TEXT, $line)[2]);
            $f3 = string_to_null(explode($SEP_TEXT, $line)[3]);
            $f4 = string_to_null(explode($SEP_TEXT, $line)[4]);
            $f5 = string_to_null(explode($SEP_TEXT, $line)[5]);
            $query = "DELETE FROM TB_PANORAMA_SUBDOMAIN WHERE SUBDOMAIN_ID=".$id;
            Array_push($response, table_query($query));
        }
        to_json($response);
    }
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$UID = isset($_GET['UID']) ? strval($_GET['UID']) : "";
set_user($UID);
if (!is_supervisor()) die();

$table = isset($_GET['table']) ? strval($_GET['table']) : "";
$action = isset($_GET['action']) ? strval($_GET['action']) : "";
$data = isset($_GET['data']) ? strval($_GET['data']) : "";
$filter = isset($_GET['filter']) ? strval($_GET['filter']) : "";
$fcontext = isset($_GET['filter_context']) ? strval($_GET['filter_context']) : "";

if ($table == "users") get_users($action, $data, $filter);
else if ($table == "channel") get_channel($action, $data, $filter);
else if ($table == "competidor") get_competidor($action, $data, $filter);
else if ($table == "industry") get_industry($action, $data, $filter);
else if ($table == "social") get_social($action, $data, $filter);
else if ($table == "domain_type") get_domain_type($action, $data, $filter);
else if ($table == "subdomain_type") get_subdomain_type($action, $data, $filter);
else if ($table == "pcd_template") get_pcd_template($action, $data, $filter);
else if ($table == "users_pcd") get_users_pcd($action, $data, $filter);
else if ($table == "pcd_month") get_pcd_month($action, $data, $filter);
else if ($table == "audiencia") get_audiencia($action, $data, $fcontext, $filter);
else if ($table == "audiencia_indu_sites") get_audiencia_indu_sites($action, $data, $fcontext, $filter);
else if ($table == "audiencia_sites") get_audiencia_sites($action, $data, $fcontext, $filter);
else if ($table == "audiencia_wordcloud") get_audiencia_wordcloud($action, $data, $fcontext, $filter);
else if ($table == "panorama") get_panorama($action, $data, $fcontext, $filter);
else if ($table == "panorama_social") get_panorama_social($action, $data, $fcontext, $filter);
else if ($table == "panorama_domain") get_panorama_domain($action, $data, $fcontext, $filter);
else if ($table == "panorama_outlink") get_panorama_outlink($action, $data, $fcontext, $filter);
else if ($table == "panorama_subdomain") get_panorama_subdomain($action, $data, $fcontext, $filter);

?>

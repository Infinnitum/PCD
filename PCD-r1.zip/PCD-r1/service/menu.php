<?php

include_once("data_lib.php");

include_once("user_lib.php");


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Servicios

function get_menu() {
    global $USER;
    
    $menu = [];
    
    $audiencia_data = [];
    Array_push($audiencia_data, array("name"=>"Inicio", "link"=>"../audiencia/audiencia.html"));
    Array_push($audiencia_data, array("name"=>"Intereses de la Audiencia", "link"=>"../audiencia/audiencia.html#Intereses_de_la_Audiencia"));
    Array_push($audiencia_data, array("name"=>"Intereses de la Audiencia por Industria", "link"=>"../audiencia/audiencia.html#Intereses_de_la_Audiencia_por_Industria"));
    Array_push($audiencia_data, array("name"=>"Audiencia Sitios", "link"=>"../audiencia/audiencia.html#Audiencia_Sitios"));
    Array_push($audiencia_data, array("name"=>"Audiencia por Industria", "link"=>"../audiencia/audiencia.html#Audiencia_por_Industria"));
    Array_push($menu, array("name"=>"Audiencia", "data"=>$audiencia_data, "style"=>"fa fa-users"));
    
    $trafico_data = [];
    Array_push($trafico_data, array("name"=>"Inicio", "link"=>"../trafico/trafico.html"));
    Array_push($trafico_data, array("name"=>"Panorama Mensual", "link"=>"../trafico/trafico.html#Panorama_Mensual"));
    Array_push($trafico_data, array("name"=>"Tráfico Acumulado", "link"=>"../trafico/trafico.html#Trafico_Acumulado"));
    Array_push($trafico_data, array("name"=>"Tráfico Último Mes", "link"=>"../trafico/trafico.html#Trafico_Mes"));
    Array_push($trafico_data, array("name"=>"Tráfico por Tipo", "link"=>"../trafico/trafico.html#Trafico_Tipo"));
    Array_push($trafico_data, array("name"=>"Share de Tráfico por Tipo", "link"=>"../trafico/trafico.html#Share_Trafico_Tipo"));
    Array_push($trafico_data, array("name"=>"Share sobre Tráfico por Tipo", "link"=>"../trafico/trafico.html#Share_sobre_Trafico_Tipo"));
    Array_push($trafico_data, array("name"=>"Redes Sociales", "link"=>"../trafico/trafico.html#Redes_Sociales"));
    Array_push($trafico_data, array("name"=>"Dominios", "link"=>"../trafico/trafico.html#Dominios"));
    Array_push($trafico_data, array("name"=>"Outlinks", "link"=>"../trafico/trafico.html#Outlinks"));
    Array_push($trafico_data, array("name"=>"Subdominios", "link"=>"../trafico/trafico.html#Subdominios"));
    Array_push($menu, array("name"=>"Tráfico", "data"=>$trafico_data, "style"=>"fa fa-wifi"));
    
    if (is_supervisor()) {
        $backend_data = [];
        Array_push($backend_data, array("name"=>"Informe PCD - Audiencia", "link"=>"../backend/audiencia.html"));
        Array_push($backend_data, array("name"=>"Informe PCD - Tráfico", "link"=>"../backend/trafico.html"));
        Array_push($backend_data, array("name"=>"Usuarios", "link"=>"../backend/users.html"));
        Array_push($backend_data, array("name"=>"Usuarios - PCD", "link"=>"../backend/users_pcd.html"));
        Array_push($backend_data, array("name"=>"Competidor", "link"=>"../backend/competidor.html"));
        Array_push($backend_data, array("name"=>"PCD Template", "link"=>"../backend/pcd_template.html"));
        Array_push($backend_data, array("name"=>"Audiencia - Industria", "link"=>"../backend/industry.html"));
        Array_push($backend_data, array("name"=>"Tráfico - Canal", "link"=>"../backend/channel.html"));
        Array_push($backend_data, array("name"=>"Tráfico - Redes Sociales", "link"=>"../backend/social.html"));
        Array_push($backend_data, array("name"=>"Dominio - Tipo", "link"=>"../backend/domain_type.html"));
        Array_push($backend_data, array("name"=>"Subdominio - Tipo", "link"=>"../backend/subdomain_type.html"));
        Array_push($menu, array("name"=>"Backend", "data"=>$backend_data, "style"=>"fa fa-table"));
    }
    
    to_json($menu);
}


function get_filter() {
    global $USER;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
    
    $user_id = $USER["USER_ID"];
    
    $lookup_body = "SELECT P.PCD_ID AS ID, CONCAT(CONCAT(CONCAT(C1.COMPETIDOR_NAME, COALESCE(CONCAT(' | ',C2.COMPETIDOR_NAME),'')), COALESCE(CONCAT(' | ',C3.COMPETIDOR_NAME),'')), COALESCE(CONCAT(' | ',C4.COMPETIDOR_NAME),'')) AS NAME
                    FROM TB_PCD_TEMPLATE P
                    LEFT OUTER JOIN TB_COMPETIDOR C1 ON C1.COMPETIDOR_ID=P.COMPETIDOR_ID_1
                    LEFT OUTER JOIN TB_COMPETIDOR C2 ON C2.COMPETIDOR_ID=P.COMPETIDOR_ID_2
                    LEFT OUTER JOIN TB_COMPETIDOR C3 ON C3.COMPETIDOR_ID=P.COMPETIDOR_ID_3
                    LEFT OUTER JOIN TB_COMPETIDOR C4 ON C4.COMPETIDOR_ID=P.COMPETIDOR_ID_4
                    WHERE EXISTS (SELECT 1 FROM TB_USERS_PCD U WHERE U.PCD_ID=P.PCD_ID AND U.USER_ID=".$user_id.")
                    ORDER BY PCD_ID";
    $lookup = lookup_simple($lookup_body);
    
    $head = array("Informe", "Año", "Mes", "");
    $head_style = array("text", "text", "text", "");
    
    $body = "SELECT P.PCD_ID, P.YEAR, P.MONTH, 'Filtrar'
             FROM TB_PCD_MONTH P
             WHERE EXISTS (SELECT 1 FROM TB_USERS_PCD U WHERE U.PCD_ID=P.PCD_ID AND U.USER_ID=".$user_id.")
             ORDER BY P.YEAR DESC, P.MONTH DESC
             LIMIT 1";
    $body_style = array("data-select:".$lookup, "data-year", "data-month", "action:filter");

    to_json(array(
                array("type"=>"head", "data"=>$head, "style"=>$head_style),
                array("type"=>"body", "data"=>table_simple($body), "style"=>$body_style)
            ));
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Routing

$UID = isset($_GET['UID']) ? strval($_GET['UID']) : "";
set_user($UID);

$action = isset($_GET['action']) ? strval($_GET['action']) : "";

if ($action == "menu") get_menu();
else if ($action == "filter") get_filter();

?>

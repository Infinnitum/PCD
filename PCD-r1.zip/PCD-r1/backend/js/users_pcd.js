
var UID = getCookie();

var filtro = "";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_users_pcd_all() {
    setTable("../service/backend.php?UID="+UID+"&table=users_pcd&action=get-all&filter="+filtro, "#users_pcd_all");
};
function start_users_pcd_new() {
    setTable("../service/backend.php?UID="+UID+"&table=users_pcd&action=get-new&filter="+filtro, "#users_pcd_new");
};
function start_users_pcd_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=users_pcd&action=get-filter", "#users_pcd_filter");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "users_pcd_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=users_pcd&action=delete&data="+table_read(table, filter)+"&filter="+filtro, function(){start_users_pcd_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "users_pcd_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=users_pcd&action=update&data="+table_read(table, filter)+"&filter="+filtro, function(){start_users_pcd_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "users_pcd_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=users_pcd&action=insert&data="+table_read(table, filter)+"&filter="+filtro, function(){start_users_pcd_new(); start_users_pcd_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "users_pcd_new") {
        start_users_pcd_new();
    }
    else if (table == "users_pcd_filter") {
        filtro = "";
        start_users_pcd_filter();
        start_users_pcd_all();
        start_users_pcd_new();
    }
};
function table_filter(table, filter) {
    if (table == "users_pcd_filter") {
        filtro = table_read(table, filter);
        start_users_pcd_all();
        start_users_pcd_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_users_pcd_new();
    NProgress.inc();
    start_users_pcd_all();
    NProgress.inc();
    start_users_pcd_filter();
    NProgress.inc();
    
    NProgress.done();
    
});

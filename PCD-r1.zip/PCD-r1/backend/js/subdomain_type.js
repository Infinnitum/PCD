
var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_subdomain_type_all() {
    setTable("../service/backend.php?UID="+UID+"&table=subdomain_type&action=get-all", "#subdomain_type_all");
};
function start_subdomain_type_new() {
    setTable("../service/backend.php?UID="+UID+"&table=subdomain_type&action=get-new", "#subdomain_type_new");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "subdomain_type_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=subdomain_type&action=delete&data="+table_read(table, filter), function(){start_subdomain_type_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "subdomain_type_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=subdomain_type&action=update&data="+table_read(table, filter), function(){start_subdomain_type_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "subdomain_type_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=subdomain_type&action=insert&data="+table_read(table, filter), function(){start_subdomain_type_new(); start_subdomain_type_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "subdomain_type_new") {
        start_subdomain_type_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_subdomain_type_new();
    NProgress.inc();
    start_subdomain_type_all();
    NProgress.inc();
    
    NProgress.done();
    
});

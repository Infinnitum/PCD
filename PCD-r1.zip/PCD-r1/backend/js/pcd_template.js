
var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_pcd_template_all() {
    setTable("../service/backend.php?UID="+UID+"&table=pcd_template&action=get-all", "#pcd_template_all");
};
function start_pcd_template_new() {
    setTable("../service/backend.php?UID="+UID+"&table=pcd_template&action=get-new", "#pcd_template_new");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "pcd_template_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=pcd_template&action=delete&data="+table_read(table, filter), function(){start_pcd_template_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "pcd_template_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=pcd_template&action=update&data="+table_read(table, filter), function(){start_pcd_template_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "pcd_template_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=pcd_template&action=insert&data="+table_read(table, filter), function(){start_pcd_template_new(); start_pcd_template_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "pcd_template_new") {
        start_pcd_template_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_pcd_template_new();
    NProgress.inc();
    start_pcd_template_all();
    NProgress.inc();
    
    NProgress.done();
    
});

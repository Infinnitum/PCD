
var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_users_all() {
    setTable("../service/backend.php?UID="+UID+"&table=users&action=get-all", "#users_all");
};
function start_users_new() {
    setTable("../service/backend.php?UID="+UID+"&table=users&action=get-new", "#users_new");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "users_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=users&action=delete&data="+table_read(table, filter), function(){start_users_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "users_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=users&action=update&data="+table_read(table, filter), function(){start_users_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "users_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=users&action=insert&data="+table_read(table, filter), function(){start_users_new(); start_users_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "users_new") {
        start_users_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_users_new();
    NProgress.inc();
    start_users_all();
    NProgress.inc();
    
    NProgress.done();
    
});

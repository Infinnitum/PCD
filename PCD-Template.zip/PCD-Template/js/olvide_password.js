
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function enviar_mail(){
    var email = $(document).find('#email').val();
    
    if (email != "") {
        var pass = $(document).find('#pass').val();
        var url = "service/password.php?action=olvide_password&mail="+email;
        
        getJSON(url,
                function(result) {
                    NProgress.start();
                    var status = result.STATUS;
                    var title = "";
                    var msg = result.MSG;
                    
                    if (msg != "") new_pnotify(title, msg, status);
                    new_pnotify(title, "Redireccionando...", "success");
                    setTimeout(function() {window.location.href = 'login.html'}, 5000);
                    NProgress.done();
                });
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    NProgress.start();
    
    $('#enviar_mail').focus();
    
    $("#enviar_mail").on("click", function() {
        enviar_mail();
    });
    
    $('#enviar_mail').keypress(function(e){
        if(e.which == 13){
            $('#enviar_mail').click();
        }
    });
    
    NProgress.done();
});


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PNotity - Wrappers

// New Notification - Constructor
function new_pnotify(title, text, type) {
    if (title != "") new PNotify({title: title, text: text, type: type, styling: 'bootstrap3'});
    else new PNotify({text: text, type: type, styling: 'bootstrap3'});
};

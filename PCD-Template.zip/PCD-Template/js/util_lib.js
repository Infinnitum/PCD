
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Util - Data Conection & Manipulation

// JSON Handle Prototype
function getJSON(url, success) {
    $.ajax({
        url: url,
        dataType: "json",
        success: success,
        error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect. Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Error 404. Requested page not found.';
            } else if (jqXHR.status == 500) {
                msg = 'Error 500. Internal Server.';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            
            new_pnotify("", msg, "error");
        }
    });
};


// Max value from JSON - Main
function getMax(json, prop) {
    var arr = [];
    deepKeySearchFloat(json, prop, arr);
    
    var max = 0;
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] > max) max = arr[i];
    }
    return max;
}
// Max value from JSON - Search
function deepKeySearchFloat(obj, key, arr) {
    for (iKey in obj) {
        if (obj.hasOwnProperty(iKey)) {
            if (iKey === key) {
                arr.push(parseFloat(obj[iKey]));
            } else if (typeof obj[iKey] === 'object' && obj[iKey] !== null) {
                var search = deepKeySearchFloat(obj[iKey], key, arr);
                if (search !== undefined) {
                    arr.push(parseFloat(search));
                }
            }
        }
    }
}


// Max length from JSON - Main
function getMaxLength(json, prop) {
    var arr = [];
    deepKeySearchText(json, prop, arr);
    
    var max = 0;
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].length > max) max = arr[i].length;
    }
    return max;
}
// Max length from JSON - Search
function deepKeySearchText(obj, key, arr) {
    for (iKey in obj) {
        if (obj.hasOwnProperty(iKey)) {
            if (iKey === key) {
                arr.push(obj[iKey]);
            } else if (typeof obj[iKey] === 'object' && obj[iKey] !== null) {
                var search = deepKeySearchText(obj[iKey], key, arr);
                if (search !== undefined) {
                    arr.push(search);
                }
            }
        }
    }
}


// Different values from JSON - Main
function getLabels(json, prop) {
    var has = {};
    var arr = [];
    deepKeySearchDistinct(json, prop, has, arr);

    return arr;
}
// Different values from JSON - Search
function deepKeySearchDistinct(obj, key, has, arr) {
    for (iKey in obj) {
        if (obj.hasOwnProperty(iKey)) {
            if (iKey === key) {
                if (!has[obj[iKey]]) {
                    has[obj[iKey]] = true;
                    arr.push(obj[iKey]);
                }
            } else if (typeof obj[iKey] === 'object' && obj[iKey] !== null) {
                var search = deepKeySearchDistinct(obj[iKey], key, has, arr);
                if (search !== undefined) {
                    if (!has[obj[iKey]]) {
                        has[obj[iKey]] = true;
                        arr.push(search);
                    }
                }
            }
        }
    }
}


// Different dates from JSON - Main
function getDates(json, prop) {
    var has = {};
    var arr = [];
    deepKeySearchDistinct(json, prop, has, arr);

    var dates = [];
    for (var i = 0; i < arr.length; i++) {
        dates.push(new Date(arr[i].split("-")[0], (arr[i].split("-")[1]-1), arr[i].split("-")[2]));
    }
    
    return dates;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PNotity - Wrappers

// New Notification - Constructor
function new_pnotify(title, text, type) {
    if (title != "") new PNotify({title: title, text: text, type: type, styling: 'bootstrap3'});
    else new PNotify({text: text, type: type, styling: 'bootstrap3'});
};

function getNotification(url, on_success) {
    getJSON(url,
            function(results) {
                for (var i = 0; i < results.length; i++) {
                    var result = results[i];
                    var title = "";
                    var status = result.STATUS;
                    //console.log(status);
                    var msg = result.MSG;
                    //console.log(msg);
                    
                    if (status == "success") {
                        title = "Éxito";
                        on_success();
                    }
                    else {
                        title = "Error";
                    }
                    if (msg != "") new_pnotify(title, msg, status);
                }
            });
};



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Util - Generic funtions

// Human-readable number format
function numberWithCommas(number, decimals, lang = "es") {
    miles = ",";
    coma = ".";
    if (lang == "es") {
        miles = ".";
        coma = ",";
    }
    
    var parts = Number(Math.round(number+'e'+decimals)+'e-'+decimals).toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, miles);
    return parts.join(coma);
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Data - Static Data

function MESES_JSON() {
    return [{"ID":1, "NAME":"Enero"}, {"ID":2, "NAME":"Febrero"}, {"ID":3, "NAME":"Marzo"}, {"ID":4, "NAME":"Abril"}, {"ID":5, "NAME":"Mayo"}, {"ID":6, "NAME":"Junio"}, {"ID":7, "NAME":"Julio"}, {"ID":8, "NAME":"Agosto"}, {"ID":9, "NAME":"Septiembre"}, {"ID":10, "NAME":"Octubre"}, {"ID":11, "NAME":"Noviembre"}, {"ID":12, "NAME":"Diciembre"}];
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Cookies - Get cookie

var COOKIE_NAME = "adinnovation.com.ar-PCD";

function getCookie() {
    var return_value = null;

    var pos_start = document.cookie.indexOf(COOKIE_NAME + "=");

    if (pos_start != -1) { // Cookie already set, read it
        pos_start = pos_start + COOKIE_NAME.length + 1; // Start reading 1 character after
        var pos_end = document.cookie.indexOf(";", pos_start); // Find ";" after the start position

        if (pos_end == -1) pos_end = document.cookie.length;
        return_value = unescape( document.cookie.substring(pos_start, pos_end) );
    }

    return return_value; // null if cookie doesn't exist, string otherwise
}



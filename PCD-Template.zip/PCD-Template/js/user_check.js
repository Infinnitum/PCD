
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var value = getCookie();

if (value != null) {
    var url = "../service/user_check.php?UID="+value;
    
    getJSON(url,
            function(result) {
                if (result[0].STATUS != "success") {
                    window.location.href = '../login.html';
                }
            });
}
else {
    window.location.href = '../login.html';
}


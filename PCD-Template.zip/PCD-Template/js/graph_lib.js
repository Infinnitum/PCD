
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// chart.js - Wrapper

// Set chart.js Chart from JSON - Main
function setGrafico_chart(url, dom_grafico, grafico) {
    getJSON(url,
            function(result) {
                console.log(result);
                new Chart($(dom_grafico), {
                    type: grafico,
                    data: result
                });
            });
};



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// d3.js - Wrapper

// Set d3.js pieChart from JSON - Main
function addPieChart(url, dom_grafico, numberType, labelType) {        
    getJSON(url,
            function(result) {
                var factor = 1;
                if (numberType == "percent") factor = 100;
                
                nv.addGraph(function() {
                    d3.select(dom_grafico+' > *').remove();
                    var graph = nv.models.pieChart()
                        .x(function(d) { return d.label })
                        .y(function(d) { return d.value * factor })
                        .showLabels(true)
                        .labelThreshold(.05)  //Configure the minimum slice size for labels to show up
                        .labelType(labelType) //Configure what type of data to show in the label. Can be "key", "value" or "percent"
                        .donut(true)          //Turn on Donut mode. Makes pie chart look tasty!
                        .donutRatio(0.35)     //Configure how big you want the donut hole size to be.
                        .color(d3.scale.category10().range())
                        ;

                    d3.select(dom_grafico)
                        .datum(result)
                        .call(graph);

                    graph.update;
                    nv.utils.windowResize(function(){ graph.update(); });
                    return graph;
                });
            });
}

// Set d3.js lineChart with Dates from JSON - Main
function addLineChartDates(url, dom_grafico, numberType) {
    getJSON(url,
            function(result) {
                var margin_left = 75;
                var margin_right = 50;
                var margin_bottom = 100;
                
                var tickvalues = getDates(result, "label");
                var factor = 1;
                if (numberType == "percent") factor = 100;
                var max = getMax(result, "value") * factor * 1.15;
                
                nv.addGraph(function() {
                    d3.select(dom_grafico+' > *').remove();
                    var graph = nv.models.lineChart()
                        .x(function(d) { return new Date(d.label.split("-")[0], (d.label.split("-")[1]-1), d.label.split("-")[2]) })
                        .xScale(d3.time.scale())
                        .y(function(d) { return d.value * factor })
                        .yTickFormat(d3.format(',.1f'))
                        .yDomain([0, max])
                        .duration(250)
                        .margin({left: margin_left, right: margin_right, bottom: margin_bottom})
                        .color(d3.scale.category10().range())
                        .useInteractiveGuideline(true)
                        ;
                    
                    graph.xAxis
                        .tickValues(tickvalues)
                        .tickFormat(function(d) { return d3.time.format("%b %Y")(d) })
                        ;
                        
                    d3.select(dom_grafico)
                        .datum(result)
                        .call(graph);

                    graph.update;
                    nv.utils.windowResize(function(){ graph.update(); });
                    return graph;
                });
            });
}

// Set d3.js multiBarChart from JSON - Main
function addMultiBarChart(url, dom_grafico, numberType) {
    getJSON(url,
            function(result) {
                var margin_left = 75;
                var margin_right = 50;
                var maxLabel = getMaxLength(result, "label");
                var rotateLabels = 0;
                if (maxLabel < 14) maxLabel = 14;
                else rotateLabels = -45;
                var margin_bottom = maxLabel * 7;
                
                var factor = 1;
                if (numberType == "percent") factor = 100;
                var max = getMax(result, "value") * factor * 1.15;
                
                nv.addGraph(function() {
                    d3.select(dom_grafico+' > *').remove();        
                    var graph = nv.models.multiBarChart()
                        .x(function(d) { return d.label })
                        .rotateLabels(rotateLabels)
                        .y(function(d) { return d.value * factor })
                        .yDomain([0, max])
                        .color(d3.scale.category10().range())
                        .barColor(d3.scale.category10().range())
                        .reduceXTicks(false)
                        .duration(250)
                        .margin({left: margin_left, right: margin_right, bottom: margin_bottom})
                        .showControls(false)
                        .useInteractiveGuideline(true);
                        
                    d3.select(dom_grafico)
                        .datum(result)
                        .call(graph);
                    
                    graph.update;
                    nv.utils.windowResize(function(){ graph.update(); });
                    return graph;
                });
            });
};



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// WordCloud.js - Wrapper
function addWordCloud(url, dom_grafico) {
    getJSON(url,
            function(result) {
                    WordCloud(dom_grafico,
                              {list: result,
                               rotateRatio: 0,
                               minRotation: 0,
                               maxRotation: 0});
            });
};



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tables - Data Presentation

// Set Table from JSON - Main
function setTable(url, table) {
    getJSON(url,
            function(result) {
                var head_data;
                var head_style;
                var body_data;
                var body_style;
                var foot_data;
                var foot_style;
                
                for (var i = 0; i < result.length; i++){
                    var obj = result[i];
                    var type;
                    var style;
                    var data;
                    
                    for (var key in obj){
                        var attrName = key;
                        var attrValue = obj[key];
                        
                        if (attrName == "type") {
                            type = attrValue;
                        }
                        else if (attrName == "style") {
                            style = attrValue;
                        }
                        else if (attrName == "data") {
                            data = attrValue;
                        }
                    }
                    
                    if (type == "head") {
                        head_style = style;
                        head_data = data;
                    }
                    else if (type == "body") {
                        body_style = style;
                        body_data = data;
                    }
                    else if (type == "foot") {
                        foot_style = style;
                        foot_data = data;
                    }
                }
                
                $(table).empty();
                
                addToTable(table, "thead", head_data, head_style);
                addToTable(table, "tbody", body_data, body_style);
                addToTable(table, "tfoot", foot_data, foot_style);
            });
};


// Add Pagination to Table
function addPagination(table) {
    $(table).DataTable({
        //dom: "<Bfr>t<ip>",
        dom: "t<ip>",
        ordering: false,
        pageLength: 2
        /*buttons: [
            {extend: "copy", className: "btn-sm"},
            {extend: "csv", className: "btn-sm"},
            {extend: "excel", className: "btn-sm"},
            {extend: "pdfHtml5", className: "btn-sm"},
            {extend: "print", className: "btn-sm"}]
        ]
        responsive: true
        */
    });
}


// Set Table from JSON - Add to table section
function addToTable(table, section, data, style) {
    var tabla = $(table);
    var rows = [];
    var row = "";
    var single = true;
    var x = 1;
    var y = 1;
    
    if (data) {
        var estilo = style;
        var estilo_multi = false;
        if (style != null && Object.prototype.toString.call(style[0]) != "[object String]") estilo_multi = true;
            
        for (var i = 0; i < data.length; i++) {
            var obj = data[i];
            var s = "";
            if (style != null && estilo_multi) estilo = style[i];
            
            if (Object.prototype.toString.call(obj) != "[object String]") {
                single = false;

                var j = 0;
                for (var key in obj) {
                    var attrName = key;
                    var attrValue = obj[key];
                    
                    if (style != null) {
                        s = (estilo+"").split(",")[j];
                    }
                    
                    row = row + applyStyle(attrValue, s, section, tabla.attr('id'), x, y);
                    j++;
                    y++;
                }
                rows.push(row);
                row = "";
            }
            else {
                s = (estilo+"").split(",")[i];
                row = row + applyStyle(obj, s, section, tabla.attr('id'), x, y);
            }
            x++;
            y = 1;
        }
        if (single) rows.push(row);
    }
    row = "";
    for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        row = row + "<tr>"+r+"</tr>";
    }
    
    tabla.append($("<"+section+">").append(row));
}


// Set Table from JSON - Create td from value and style
function applyStyle(value, style, section, table, x, y) {
    var val = value;
    var icon = "";
    var row = "";
    var type = "td";
    var clase = "";
    var extra = "";
    var show = true;
    var id = "";
    
    if (section == "thead" || section == "tfoot") {
        type = "th";
    }
    
    var styles = style.split("+");
    
    for (var i = 0; i < styles.length; i++) {
        var s = styles[i].concat(":").split(":")[0];
        var t = styles[i].substr(s.length+1);
        
        if (s == "none") {
            show = false;
        }
        else if (s == "id") {
            extra = extra + " id=\""+table+"-"+x+"-"+y+"\"";
        }
        else if (s == "data-text") {
            val = "<input id=\""+table+"-"+x+"-"+y+"\" class=\"form-control data "+table+"-"+x+"\" type=\"text\" value=\""+value+"\" />";
        }
        else if (s == "data-select") {
            val = "<select id=\""+table+"-"+x+"-"+y+"\" class=\"form-control data "+table+"-"+x+"\">"+setSelectOptions(t.split(LST_TEXT).join(","), value)+"</select>";
        }
        else if (s == "data-year") {
            val = "<input id=\""+table+"-"+x+"-"+y+"\" class=\"form-control data "+table+"-"+x+"\" type=\"number\" data-validate-minmax=\"1900,2199\" value=\""+value+"\" />";
        }
        else if (s == "data-month") {
            val = "<select id=\""+table+"-"+x+"-"+y+"\" class=\"form-control data "+table+"-"+x+"\">"+setSelectOptions(MESES_JSON(), value)+"</select>";
        }
        else if (s == "hidden") {
            clase = clase + " hidden";
        }
        else if (s == "readonly") {
            clase = clase + " readonly";
        }
        else if (s == "comma") {
            if (t == "") t = 0;
            if (val == 0.0) val = "-";
            else val = numberWithCommas(parseFloat(value), t);
        }
        else if (s == "percent") {
            if (t == "") t = 0;
            if (val == 0.0) val = "-";
            else val = numberWithCommas(parseFloat(value)*100, t)+"%";
        }
        else if (s == "money") {
            if (t == "") t = 0;
            if (val == 0.0) val = "-";
            else val = "$ "+numberWithCommas(parseFloat(value), t);
        }
        else if (s == "bold") {
            clase = clase + " bold";
        }
        else if (s == "size") {
            if (t == "") t = 12;
            clase = clase + " font-"+t;
        }
        else if (s == "center") {
            clase = clase + " center";
        }
        else if (s == "col") {
            extra = extra + " colspan="+t;
        }
        else if (s == "row") {
            extra = extra + " rowspan="+t;
        }
        else if (s == "icon") {
            if (t == "only") val = "";
            clase = clase + " center";
            if (value == "RED") icon = "<i class=\"red\"><i class=\"fa fa-2x fa-times-circle\"></i></i>";
            else if (value == "GREEN") icon = "<i class=\"green\"><i class=\"fa fa-2x fa-check-circle\"></i></i>";
        }
        else if (s == "action") {
            clase = clase + " center";
            if (t == "save") val = "<button type=\"button\" class=\"btn btn-primary btn-sm\" onclick=\"table_update('"+table+"', 'data "+table+"-"+x+"')\">"+value+"</button>";
            else if (t == "delete") val = "<button type=\"button\" class=\"btn btn-danger btn-sm\" onclick=\"table_delete('"+table+"', 'data "+table+"-"+x+"')\">"+value+"</button>";
            else if (t == "save-all") val = "<button type=\"button\" class=\"btn btn-primary btn-sm\" onclick=\"table_update('"+table+"', 'data')\">"+value+"</button>";
            else if (t == "add-row") val = "<button type=\"button\" class=\"btn btn-info btn-sm\" onclick=\"table_insert('"+table+"', 'data')\">"+value+"</button>";
            else if (t == "clear-row") val = "<button type=\"button\" class=\"btn btn-warning btn-sm\" onclick=\"table_reload('"+table+"', 'data')\">"+value+"</button>";
            else if (t == "filter") val = "<button type=\"button\" class=\"btn btn-dark btn-sm\" onclick=\"table_filter('"+table+"', 'data "+table+"-"+x+"')\">"+value+"</button>";
        }
        else if (s == "progress-bar") {
            if (t == "") t = 0;
            var num0 = numberWithCommas(parseFloat(value)*100, 0);            
            var numt = numberWithCommas(parseFloat(value)*100, t);            
            val = "<div class=\"progress-custom\"><div class=\"progress-value\">"+numt+"%</div><div class=\"progress\"><div class=\"progress-bar\" role=\"progressbar\" aria-valuenow="+num0+" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: "+num0+"%;\"></div></div></div>";
        }
    }
    if (clase !="") clase = " class=\""+clase+"\"";
    
    if (show) row = "<"+type+extra+clase+">" + val + " " + icon +"</"+type+">";
    else {
        row = "";
        icon = "";
        show = true;
    }
    
    return row;
}


// Set Table from JSON - Default Funtions
function table_delete(table, filter) {};
function table_update(table, filter) {};
function table_insert(table, filter) {};
function table_reload(table, filter) {};
function table_filter(table, filter) {};


// Read Table - Constants
var LST_TEXT = "|%|";
var EOL_TEXT = "(T-T)";
var SEP_TEXT = "(^~^)";


// Read Table - Main Function
function table_read(table, filter) {
    var data = "";
    var row = "";
    var row_first = true;
    $("#"+table+" tbody tr").each(function() {
        var columns = $(this).find('td');
        columns.each(function() {
            var d = $(this);
            var input = d.find("input");
            var select = d.find("select");
            
            if (input.hasClass(filter)) {
                if (row_first) row = input.val();
                else row = row + SEP_TEXT + input.val();
                row_first = false;
            }
            else if (select.hasClass(filter)) {
                if (row_first) row = select.val();
                else row = row + SEP_TEXT + select.val();
                row_first = false;
            }
            
            //console.log(data.attr('id'));
            //console.log(data.val());
        });
        if (row != "") {
            if (data != "") data = data + EOL_TEXT + row;
            else data = row;
        }
        row = "";
        row_first = true;
    });
    //console.log(data);
    //data = data.replace("&", "\\&");
    return encodeURIComponent(data);
};


// Set Table from JSON - Create select from JSON
function setSelectOptions(list_text, def_value) {
    var options = "";
    //console.log(Object.prototype.toString.call(list_text));
    //console.log(list_text);
    var list;
    if (Object.prototype.toString.call(list_text) == "[object String]") list = JSON.parse(list_text);
    else list = list_text;
    //console.log(list);
    var single = false;
    
    options = "<option value=\"\">Seleccione una opción</option>";    
    if (list.length == 1) single = true;
    
    for (var i = 0; i < list.length; i++) {
        var l = list[i];
        //console.log(l);
        var id = l.ID;
        var name = l.NAME;
        
        var def = "";
        if (id == def_value || single) def = "selected=\"selected\"";
        
        options = options + "<option value=\""+id+"\" "+def+">"+name+"</option>";
    }
    
    return options;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Top_Tiles - Data Presentation

// Set Top_Tile from JSON - Fill top_tiles from value and style
function setTableContainer(url, table, container) {
    getJSON(url,
            function(result) {
                var head_data;
                var head_style;
                var body_data;
                var body_style;
                var foot_data;
                var foot_style;
                var container_data;
                var container_style;
                
                for (var i = 0; i < result.length; i++) {
                    var obj = result[i];
                    //if (log) console.log(obj);
                    var type;
                    var style;
                    var data;
                    
                    for (var key in obj){
                        var attrName = key;
                        var attrValue = obj[key];
                        
                        if (attrName == "type") {
                            type = attrValue;
                        }
                        else if (attrName == "style") {
                            style = attrValue;
                        }
                        else if (attrName == "data") {
                            data = attrValue;
                        }
                    }
                    
                    if (type == "head") {
                        head_style = style;
                        head_data = data;
                    }
                    else if (type == "body") {
                        body_style = style;
                        body_data = data;
                    }
                    else if (type == "foot") {
                        foot_style = style;
                        foot_data = data;
                    }
                    else if (type == "container") {
                        container_style = style;
                        container_data = data;
                    }
                }
                
                if (head_data) addToTable(table, "thead", head_data, head_style);
                if (body_data) addToTable(table, "tbody", body_data, body_style);
                if (foot_data) addToTable(table, "tfoot", foot_data, foot_style);
                if (container_data) setContainer(container, container_data);
            });
};

// Set Top_Tile from JSON - Set cointainer style
function setContainer(container, data) {
    var border = $(container);
    var container_class = "fd_primary1 border-fd_primary1";
    
    for (var key in data){
        var attrName = key;
        var attrValue = data[key]["value"];

        if (attrValue == "GREEN") container_class = "fd_green border-fd_green";
        else if (attrValue == "YELLOW") container_class = "fd_yellow border-fd_yellow";
        else if (attrValue == "RED") container_class = "fd_red border-fd_red";
    }
    
    border.addClass(container_class);
};



var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function update_password(){
    var old = $(document).find('#pass_old').val();
    var new1 = $(document).find('#pass_new1').val();
    var new2 = $(document).find('#pass_new2').val();
    
    if (old != "" && new1 != "" && new2 != "") {
        var url = "../service/password.php?action=cambiar_password&UID="+UID+"&pass_old="+old+"&pass_new1="+new1+"&pass_new2="+new2;
        
        getJSON(url,
                function(result) {
                    NProgress.start();
                    var status = result.STATUS;
                    var title = "";
                    var msg = result.MSG;
                    
                    if (status == "success") {
                        $(document).find('#pass_old').value = "";
                        $(document).find('#pass_new1').value = "";
                        $(document).find('#pass_new2').value = "";
                    }
                    else {
                        title = "Error";
                    }
                    if (msg != "") new_pnotify(title, msg, status);
                    
                    NProgress.done();
                });
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var refresh_function = [];

$(document).ready(function() {
    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();

    $("#cambiar_password").on("click", function() {
        update_password();
    });
    
    NProgress.done();
});

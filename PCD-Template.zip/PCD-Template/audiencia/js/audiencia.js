
var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Audiencia

//// Intereses de la Audiencia b=100

////// Cuadro
function start_audiencia_interes_b100_tabla() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_interes_b100_tabla", "#audiencia_interes_b100_tabla");
};
////// Grafico
function start_audiencia_interes_b100_grafico() {
    addMultiBarChart("../service/audiencia.php?UID="+UID+"&action=audiencia_interes_b100_grafico", "#audiencia_interes_b100_grafico svg", "percent");
};


//// Intereses de la Audiencia

////// Cuadro
function start_audiencia_interes_tabla() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_interes_tabla", "#audiencia_interes_tabla");
};
////// Grafico
function start_audiencia_interes_grafico() {
    addMultiBarChart("../service/audiencia.php?UID="+UID+"&action=audiencia_interes_grafico", "#audiencia_interes_grafico svg", "percent");
};


//// Intereses de la Audiencia por Industria

//// Arte_Entretenimiento

////// Sitios
function start_audiencia_Arte_Entretenimiento_sites() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_sites&industria=Arte_Entretenimiento", "#audiencia_Arte_Entretenimiento_sites");
};
////// Tablas
function start_audiencia_Arte_Entretenimiento_tablas() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=1", "#audiencia_Arte_Entretenimiento_1_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=2", "#audiencia_Arte_Entretenimiento_2_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=3", "#audiencia_Arte_Entretenimiento_3_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Arte_Entretenimiento&competidor=4", "#audiencia_Arte_Entretenimiento_4_tabla");
};
////// Graficos
function start_audiencia_Arte_Entretenimiento_wordcloud() {
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Arte_Entretenimiento&competidor=1", "audiencia_Arte_Entretenimiento_1_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Arte_Entretenimiento&competidor=2", "audiencia_Arte_Entretenimiento_2_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Arte_Entretenimiento&competidor=3", "audiencia_Arte_Entretenimiento_3_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Arte_Entretenimiento&competidor=4", "audiencia_Arte_Entretenimiento_4_wordcloud");
};

//// Internet_Telcos

////// Sitios
function start_audiencia_Internet_Telcos_sites() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_sites&industria=Internet_Telcos", "#audiencia_Internet_Telcos_sites");
};
////// Tablas
function start_audiencia_Internet_Telcos_tablas() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=1", "#audiencia_Internet_Telcos_1_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=2", "#audiencia_Internet_Telcos_2_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=3", "#audiencia_Internet_Telcos_3_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Internet_Telcos&competidor=4", "#audiencia_Internet_Telcos_4_tabla");
};
////// Graficos
function start_audiencia_Internet_Telcos_wordcloud() {
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Internet_Telcos&competidor=1", "audiencia_Internet_Telcos_1_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Internet_Telcos&competidor=2", "audiencia_Internet_Telcos_2_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Internet_Telcos&competidor=3", "audiencia_Internet_Telcos_3_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Internet_Telcos&competidor=4", "audiencia_Internet_Telcos_4_wordcloud");
};

//// Shoppings

////// Sitios
function start_audiencia_Shoppings_sites() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_sites&industria=Shoppings", "#audiencia_Shoppings_sites");
};
////// Tablas
function start_audiencia_Shoppings_tablas() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=1", "#audiencia_Shoppings_1_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=2", "#audiencia_Shoppings_2_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=3", "#audiencia_Shoppings_3_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Shoppings&competidor=4", "#audiencia_Shoppings_4_tabla");
};
////// Graficos
function start_audiencia_Shoppings_wordcloud() {
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Shoppings&competidor=1", "audiencia_Shoppings_1_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Shoppings&competidor=2", "audiencia_Shoppings_2_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Shoppings&competidor=3", "audiencia_Shoppings_3_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Shoppings&competidor=4", "audiencia_Shoppings_4_wordcloud");
};

//// Noticias_Medios

////// Sitios
function start_audiencia_Noticias_Medios_sites() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_sites&industria=Noticias_Medios", "#audiencia_Noticias_Medios_sites");
};
////// Tablas
function start_audiencia_Noticias_Medios_tablas() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=1", "#audiencia_Noticias_Medios_1_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=2", "#audiencia_Noticias_Medios_2_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=3", "#audiencia_Noticias_Medios_3_tabla");
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_competidor_tabla&industria=Noticias_Medios&competidor=4", "#audiencia_Noticias_Medios_4_tabla");
};
////// Grafico
function start_audiencia_Noticias_Medios_wordcloud() {
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Noticias_Medios&competidor=1", "audiencia_Noticias_Medios_1_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Noticias_Medios&competidor=2", "audiencia_Noticias_Medios_2_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Noticias_Medios&competidor=3", "audiencia_Noticias_Medios_3_wordcloud");
    addWordCloud("../service/audiencia.php?UID="+UID+"&action=audiencia_industria_wordcloud&industria=Noticias_Medios&competidor=4", "audiencia_Noticias_Medios_4_wordcloud");
};

//// Audiencia Sitios

////// Cuadro
function start_audiencia_sitios_ranking_tabla() {
    setTable("../service/audiencia.php?UID="+UID+"&action=audiencia_sitios_ranking_tabla", "#audiencia_sitios_ranking_tabla");
};
////// Grafico Línea
function start_audiencia_industrias_line_grafico() {
    addLineChartDates("../service/audiencia.php?UID="+UID+"&action=audiencia_industrias_line_grafico", "#audiencia_industrias_line_grafico svg", "percent");
};
////// Grafico radar
function start_audiencia_industrias_radar_grafico() {
    setGrafico_chart("../service/audiencia.php?UID="+UID+"&action=audiencia_industrias_radar_grafico", "#audiencia_industrias_radar_grafico", "radar");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var refresh_function = [];

$(document).ready(function() {
    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    
    
    start_audiencia_interes_tabla();
    start_audiencia_interes_grafico();
    $("#link_tab_audiencia_interes").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_interes_grafico");
    });
    NProgress.inc();
    
    start_audiencia_interes_b100_tabla();
    $("#link_tab_audiencia_interes_b100").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_interes_b100_grafico");
    });
    NProgress.inc();
    
    
    
    start_audiencia_Arte_Entretenimiento_sites();
    start_audiencia_Arte_Entretenimiento_tablas();
    start_audiencia_Arte_Entretenimiento_wordcloud();
    $("#link_tab_audiencia_Arte_Entretenimiento").on("click", function() {
        refresh_function = [];
    });
    NProgress.inc();
    
    start_audiencia_Internet_Telcos_sites();
    start_audiencia_Internet_Telcos_tablas();
    start_audiencia_Internet_Telcos_wordcloud();
    $("#link_tab_audiencia_Internet_Telcos").on("click", function() {
        refresh_function = [];
    });
    NProgress.inc();
    
    start_audiencia_Shoppings_sites();
    start_audiencia_Shoppings_tablas();
    start_audiencia_Shoppings_wordcloud();
    $("#link_tab_audiencia_Shoppings").on("click", function() {
        refresh_function = [];
    });
    NProgress.inc();
    
    start_audiencia_Noticias_Medios_sites();
    start_audiencia_Noticias_Medios_tablas();
    start_audiencia_Noticias_Medios_wordcloud();
    $("#link_tab_audiencia_Noticias_Medios").on("click", function() {
        refresh_function = [];
    });
    NProgress.inc();
    
    
    
    start_audiencia_sitios_ranking_tabla();
    NProgress.inc();
    
    
    
    start_audiencia_industrias_line_grafico();
    $("#link_tab_audiencia_industrias_line_grafico").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_industrias_line_grafico");
    });
    NProgress.inc();

    $("#link_tab_audiencia_industrias_radar_grafico").on("click", function() {
        refresh_function = [];
        refresh_function.push("start_audiencia_industrias_radar_grafico");
    });
    NProgress.inc();
    
    //window.addEventListener("resize", Chart.render);    
    
    $("a[data-toggle='tab']").on("shown.bs.tab", function (e) {
        NProgress.start();
        //alert(e.target); // newly activated tab
        //e.relatedTarget // previous active tab
        var i;
        for (i = 0; i < refresh_function.length; i++) {
            window[refresh_function[i]]();
        };
        refresh_function = [];
        NProgress.done();
    });
    
    NProgress.done();
});

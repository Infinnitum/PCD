
var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
/*
    init_wysiwyg();
    init_InputMask();
    init_JQVmap();
    init_cropper();
    init_knob();
    init_IonRangeSlider();
    init_ColorPicker();
    init_TagsInput();
    init_parsley();
    init_daterangepicker();
    init_daterangepicker_right();
    init_daterangepicker_single_call();
    init_daterangepicker_reservation();
    init_SmartWizard();
    init_skycons();
    init_select2();
    init_validator();
    init_gauge();
    init_PNotify();
    init_starrr();
    init_compose();
    init_CustomNotification();
    init_autosize();
    init_autocomplete();
    */
});

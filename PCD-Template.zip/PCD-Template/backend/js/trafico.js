
var UID = getCookie();

var filtro = "";
var filtro_panorama = "";
var filtro_panorama_social = "";
var filtro_panorama_domain = "";
var filtro_panorama_outlink = "";
var filtro_panorama_subdomain = "";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_pcd_month_new() {
    setTable("../service/backend.php?UID="+UID+"&table=pcd_month&action=get-new&filter="+filtro, "#pcd_month_new");
};
function start_pcd_month_all() {
    //console.log("../service/backend.php?UID="+UID+"&table=pcd_month&action=get-all&filter="+filtro);
    setTable("../service/backend.php?UID="+UID+"&table=pcd_month&action=get-all&filter="+filtro, "#pcd_month_all");
};
function start_panorama_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama&action=get-filter&filter_context="+filtro, "#panorama_filter");
};
function start_panorama_new() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama&action=get-new&filter_context="+filtro+"&filter="+filtro_panorama, "#panorama_new");
};
function start_panorama_all() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama&action=get-all&filter_context="+filtro+"&filter="+filtro_panorama, "#panorama_all");
};
function start_panorama_social_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_social&action=get-filter&filter_context="+filtro, "#panorama_social_filter");
};
function start_panorama_social_new() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_social&action=get-new&filter_context="+filtro+"&filter="+filtro_panorama_social, "#panorama_social_new");
};
function start_panorama_social_all() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_social&action=get-all&filter_context="+filtro+"&filter="+filtro_panorama_social, "#panorama_social_all");
};
function start_panorama_domain_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_domain&action=get-filter&filter_context="+filtro, "#panorama_domain_filter");
};
function start_panorama_domain_new() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_domain&action=get-new&filter_context="+filtro+"&filter="+filtro_panorama_domain, "#panorama_domain_new");
};
function start_panorama_domain_all() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_domain&action=get-all&filter_context="+filtro+"&filter="+filtro_panorama_domain, "#panorama_domain_all");
};
function start_panorama_outlink_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_outlink&action=get-filter&filter_context="+filtro, "#panorama_outlink_filter");
};
function start_panorama_outlink_new() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_outlink&action=get-new&filter_context="+filtro+"&filter="+filtro_panorama_outlink, "#panorama_outlink_new");
};
function start_panorama_outlink_all() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_outlink&action=get-all&filter_context="+filtro+"&filter="+filtro_panorama_outlink, "#panorama_outlink_all");
};
function start_panorama_subdomain_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_subdomain&action=get-filter&filter_context="+filtro, "#panorama_subdomain_filter");
};
function start_panorama_subdomain_new() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_subdomain&action=get-new&filter_context="+filtro+"&filter="+filtro_panorama_subdomain, "#panorama_subdomain_new");
};
function start_panorama_subdomain_all() {
    setTable("../service/backend.php?UID="+UID+"&table=panorama_subdomain&action=get-all&filter_context="+filtro+"&filter="+filtro_panorama_subdomain, "#panorama_subdomain_all");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "pcd_month_all") {
        NProgress.start();
        filtro = "";
        getNotification("../service/backend.php?UID="+UID+"&table=pcd_month&action=delete&data="+table_read(table, filter)+"&filter="+filtro,
                        function(){
                            $("#pcd_month_all").empty();
                            $("#panorama_filter").empty();
                            $("#panorama_new").empty();
                            $("#panorama_all").empty();
                            $("#panorama_social_filter").empty();
                            $("#panorama_social_new").empty();
                            $("#panorama_social_all").empty();
                            $("#panorama_domain_filter").empty();
                            $("#panorama_domain_new").empty();
                            $("#panorama_domain_all").empty();
                            $("#panorama_outlink_filter").empty();
                            $("#panorama_outlink_new").empty();
                            $("#panorama_outlink_all").empty();
                            $("#panorama_subdomain_filter").empty();
                            $("#panorama_subdomain_new").empty();
                            $("#panorama_subdomain_all").empty();
        });
        NProgress.done();
    }
    else if (table == "panorama_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama, function(){start_panorama_all();});
        NProgress.done();
    }
    else if (table == "panorama_social_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_social&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_social, function(){start_panorama_social_all();});
        NProgress.done();
    }
    else if (table == "panorama_domain_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_domain&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_domain, function(){start_panorama_domain_all();});
        NProgress.done();
    }
    else if (table == "panorama_outlink_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_outlink&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_outlink, function(){start_panorama_outlink_all();});
        NProgress.done();
    }
    else if (table == "panorama_subdomain_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_subdomain&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_subdomain, function(){start_panorama_subdomain_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "panorama_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama, function(){start_panorama_all();});
        NProgress.done();
    }
    else if (table == "panorama_social_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_social&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_social, function(){start_panorama_social_all();});
        NProgress.done();
    }
    else if (table == "panorama_domain_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_domain&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_domain, function(){start_panorama_domain_all();});
        NProgress.done();
    }
    else if (table == "panorama_outlink_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_outlink&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_outlink, function(){start_panorama_outlink_all();});
        NProgress.done();
    }
    else if (table == "panorama_subdomain_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_subdomain&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_subdomain, function(){start_panorama_subdomain_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "pcd_month_new") {
        NProgress.start();
        filtro = table_read(table, filter);
        getNotification("../service/backend.php?UID="+UID+"&table=pcd_month&action=insert&data="+table_read(table, filter)+"&filter="+filtro,
                        function(){
                            filtro_panorama = "";
                            filtro_panorama_social = "";
                            filtro_panorama_domain = "";
                            filtro_panorama_outlink = "";
                            filtro_panorama_subdomain = "";
                            start_pcd_month_new();
                            start_pcd_month_all();
                            start_panorama_filter();
                            start_panorama_new();
                            start_panorama_all();
                            start_panorama_social_filter();
                            start_panorama_social_new();
                            start_panorama_social_all();
                            start_panorama_domain_filter();
                            start_panorama_domain_new();
                            start_panorama_domain_all();
                            start_panorama_outlink_filter();
                            start_panorama_outlink_new();
                            start_panorama_outlink_all();
                            start_panorama_subdomain_filter();
                            start_panorama_subdomain_new();
                            start_panorama_subdomain_all();
        });
        NProgress.done();
    }
    else if (table == "panorama_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama, function(){start_panorama_new(); start_panorama_all();});
        NProgress.done();
    }
    else if (table == "panorama_social_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_social&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_social, function(){start_panorama_social_new(); start_panorama_social_all();});
        NProgress.done();
    }
    else if (table == "panorama_domain_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_domain&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_domain, function(){start_panorama_domain_new(); start_panorama_domain_all();});
        NProgress.done();
    }
    else if (table == "panorama_outlink_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_outlink&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_outlink, function(){start_panorama_outlink_new(); start_panorama_outlink_all();});
        NProgress.done();
    }
    else if (table == "panorama_subdomain_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=panorama_subdomain&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_panorama_subdomain, function(){start_panorama_subdomain_new(); start_panorama_subdomain_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "panorama_new") {
        start_panorama_new();
    }
    else if (table == "panorama_filter") {
        filtro_panorama = "";
        start_panorama_filter();
        start_panorama_all();
        start_panorama_new();
    }
    else if (table == "panorama_social_new") {
        start_panorama_social_new();
    }
    else if (table == "panorama_social_filter") {
        filtro_panorama_social = "";
        start_panorama_social_filter();
        start_panorama_social_all();
        start_panorama_social_new();
    }
    else if (table == "panorama_domain_new") {
        start_panorama_domain_new();
    }
    else if (table == "panorama_domain_filter") {
        filtro_panorama_domain = "";
        start_panorama_domain_filter();
        start_panorama_domain_all();
        start_panorama_domain_new();
    }
    else if (table == "panorama_outlink_new") {
        start_panorama_outlink_new();
    }
    else if (table == "panorama_outlink_filter") {
        filtro_panorama_outlink = "";
        start_panorama_outlink_filter();
        start_panorama_outlink_all();
        start_panorama_outlink_new();
    }
    else if (table == "panorama_subdomain_new") {
        start_panorama_subdomain_new();
    }
    else if (table == "panorama_subdomain_filter") {
        filtro_panorama_subdomain = "";
        start_panorama_subdomain_filter();
        start_panorama_subdomain_all();
        start_panorama_subdomain_new();
    }
};
function table_filter(table, filter) {
    if (table == "panorama_filter") {
        filtro_panorama = table_read(table, filter);
        start_panorama_all();
        start_panorama_new();
    }
    else if (table == "panorama_social_filter") {
        filtro_panorama_social = table_read(table, filter);
        start_panorama_social_all();
        start_panorama_social_new();
    }
    else if (table == "panorama_domain_filter") {
        filtro_panorama_domain = table_read(table, filter);
        start_panorama_domain_all();
        start_panorama_domain_new();
    }
    else if (table == "panorama_outlink_filter") {
        filtro_panorama_outlink = table_read(table, filter);
        start_panorama_outlink_all();
        start_panorama_outlink_new();
    }
    else if (table == "panorama_subdomain_filter") {
        filtro_panorama_subdomain = table_read(table, filter);
        start_panorama_subdomain_all();
        start_panorama_subdomain_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_pcd_month_new();
    NProgress.inc();
    
    NProgress.done();
    
});

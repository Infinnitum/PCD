
var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_social_all() {
    setTable("../service/backend.php?UID="+UID+"&table=social&action=get-all", "#social_all");
};
function start_social_new() {
    setTable("../service/backend.php?UID="+UID+"&table=social&action=get-new", "#social_new");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "social_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=social&action=delete&data="+table_read(table, filter), function(){start_social_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "social_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=social&action=update&data="+table_read(table, filter), function(){start_social_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "social_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=social&action=insert&data="+table_read(table, filter), function(){start_social_new(); start_social_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "social_new") {
        start_social_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_social_new();
    NProgress.inc();
    start_social_all();
    NProgress.inc();
    
    NProgress.done();
    
});

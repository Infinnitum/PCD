
var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_industry_all() {
    setTable("../service/backend.php?UID="+UID+"&table=industry&action=get-all", "#industry_all");
};
function start_industry_new() {
    setTable("../service/backend.php?UID="+UID+"&table=industry&action=get-new", "#industry_new");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "industry_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=industry&action=delete&data="+table_read(table, filter), function(){start_industry_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "industry_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=industry&action=update&data="+table_read(table, filter), function(){start_industry_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "industry_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=industry&action=insert&data="+table_read(table, filter), function(){start_industry_new(); start_industry_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "industry_new") {
        start_industry_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_industry_new();
    NProgress.inc();
    start_industry_all();
    NProgress.inc();
    
    NProgress.done();
    
});

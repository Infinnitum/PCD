
var UID = getCookie();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_channel_all() {
    setTable("../service/backend.php?UID="+UID+"&table=channel&action=get-all", "#channel_all");
};
function start_channel_new() {
    setTable("../service/backend.php?UID="+UID+"&table=channel&action=get-new", "#channel_new");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "channel_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=channel&action=delete&data="+table_read(table, filter), function(){start_channel_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "channel_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=channel&action=update&data="+table_read(table, filter), function(){start_channel_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "channel_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=channel&action=insert&data="+table_read(table, filter), function(){start_channel_new(); start_channel_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "channel_new") {
        start_channel_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_channel_new();
    NProgress.inc();
    start_channel_all();
    NProgress.inc();
    
    NProgress.done();
    
});


var UID = getCookie();

var filtro = "";
var filtro_audiencia = "";
var filtro_audiencia_indu_sites = "";
var filtro_audiencia_sites = "";
var filtro_audiencia_wordcloud = "";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////// Tabla
function start_pcd_month_new() {
    setTable("../service/backend.php?UID="+UID+"&table=pcd_month&action=get-new&filter="+filtro, "#pcd_month_new");
};
function start_pcd_month_all() {
    //console.log("../service/backend.php?UID="+UID+"&table=pcd_month&action=get-all&filter="+filtro);
    setTable("../service/backend.php?UID="+UID+"&table=pcd_month&action=get-all&filter="+filtro, "#pcd_month_all");
};
function start_audiencia_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia&action=get-filter&filter_context="+filtro, "#audiencia_filter");
};
function start_audiencia_new() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia&action=get-new&filter_context="+filtro+"&filter="+filtro_audiencia, "#audiencia_new");
};
function start_audiencia_all() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia&action=get-all&filter_context="+filtro+"&filter="+filtro_audiencia, "#audiencia_all");
};
function start_audiencia_indu_sites_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_indu_sites&action=get-filter&filter_context="+filtro, "#audiencia_indu_sites_filter");
};
function start_audiencia_indu_sites_new() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_indu_sites&action=get-new&filter_context="+filtro+"&filter="+filtro_audiencia_indu_sites, "#audiencia_indu_sites_new");
};
function start_audiencia_indu_sites_all() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_indu_sites&action=get-all&filter_context="+filtro+"&filter="+filtro_audiencia_indu_sites, "#audiencia_indu_sites_all");
};
function start_audiencia_sites_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_sites&action=get-filter&filter_context="+filtro, "#audiencia_sites_filter");
};
function start_audiencia_sites_new() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_sites&action=get-new&filter_context="+filtro+"&filter="+filtro_audiencia_sites, "#audiencia_sites_new");
};
function start_audiencia_sites_all() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_sites&action=get-all&filter_context="+filtro+"&filter="+filtro_audiencia_sites, "#audiencia_sites_all");
};
function start_audiencia_wordcloud_filter() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_wordcloud&action=get-filter&filter_context="+filtro, "#audiencia_wordcloud_filter");
};
function start_audiencia_wordcloud_new() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_wordcloud&action=get-new&filter_context="+filtro+"&filter="+filtro_audiencia_wordcloud, "#audiencia_wordcloud_new");
};
function start_audiencia_wordcloud_all() {
    setTable("../service/backend.php?UID="+UID+"&table=audiencia_wordcloud&action=get-all&filter_context="+filtro+"&filter="+filtro_audiencia_wordcloud, "#audiencia_wordcloud_all");
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function table_delete(table, filter) {
    if (table == "pcd_month_all") {
        NProgress.start();
        filtro = "";
        getNotification("../service/backend.php?UID="+UID+"&table=pcd_month&action=delete&data="+table_read(table, filter)+"&filter="+filtro,
                        function(){
                            $("#pcd_month_all").empty();
                            $("#audiencia_filter").empty();
                            $("#audiencia_new").empty();
                            $("#audiencia_all").empty();
                            $("#audiencia_indu_sites_filter").empty();
                            $("#audiencia_indu_sites_new").empty();
                            $("#audiencia_indu_sites_all").empty();
                            $("#audiencia_sites_filter").empty();
                            $("#audiencia_sites_new").empty();
                            $("#audiencia_sites_all").empty();
                            $("#audiencia_wordcloud_filter").empty();
                            $("#audiencia_wordcloud_new").empty();
                            $("#audiencia_wordcloud_all").empty();
        });
        NProgress.done();
    }
    else if (table == "audiencia_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia, function(){start_audiencia_all();});
        NProgress.done();
    }
    else if (table == "audiencia_indu_sites_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_indu_sites&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_indu_sites, function(){start_audiencia_indu_sites_all();});
        NProgress.done();
    }
    else if (table == "audiencia_sites_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_sites&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_sites, function(){start_audiencia_sites_all();});
        NProgress.done();
    }
    else if (table == "audiencia_wordcloud_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_wordcloud&action=delete&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_wordcloud, function(){start_audiencia_wordcloud_all();});
        NProgress.done();
    }
};

function table_update(table, filter) {
    if (table == "audiencia_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia, function(){start_audiencia_all();});
        NProgress.done();
    }
    else if (table == "audiencia_indu_sites_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_indu_sites&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_indu_sites, function(){start_audiencia_indu_sites_all();});
        NProgress.done();
    }
    else if (table == "audiencia_sites_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_sites&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_sites, function(){start_audiencia_sites_all();});
        NProgress.done();
    }
    else if (table == "audiencia_wordcloud_all") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_wordcloud&action=update&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_wordcloud, function(){start_audiencia_wordcloud_all();});
        NProgress.done();
    }
};
function table_insert(table, filter) {
    if (table == "pcd_month_new") {
        NProgress.start();
        filtro = table_read(table, filter);
        getNotification("../service/backend.php?UID="+UID+"&table=pcd_month&action=insert&data="+table_read(table, filter)+"&filter="+filtro,
                        function(){
                            filtro_audiencia = "";
                            filtro_audiencia_indu_sites = "";
                            filtro_audiencia_sites = "";
                            filtro_audiencia_wordcloud = "";
                            start_pcd_month_new();
                            start_pcd_month_all();
                            start_audiencia_filter();
                            start_audiencia_new();
                            start_audiencia_all();
                            start_audiencia_indu_sites_filter();
                            start_audiencia_indu_sites_new();
                            start_audiencia_indu_sites_all();
                            start_audiencia_sites_filter();
                            start_audiencia_sites_new();
                            start_audiencia_sites_all();
                            start_audiencia_wordcloud_filter();
                            start_audiencia_wordcloud_new();
                            start_audiencia_wordcloud_all();
        });
        NProgress.done();
    }
    else if (table == "audiencia_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia, function(){start_audiencia_new(); start_audiencia_all();});
        NProgress.done();
    }
    else if (table == "audiencia_indu_sites_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_indu_sites&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_indu_sites, function(){start_audiencia_indu_sites_new(); start_audiencia_indu_sites_all();});
        NProgress.done();
    }
    else if (table == "audiencia_sites_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_sites&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_sites, function(){start_audiencia_sites_new(); start_audiencia_sites_all();});
        NProgress.done();
    }
    else if (table == "audiencia_wordcloud_new") {
        NProgress.start();
        getNotification("../service/backend.php?UID="+UID+"&table=audiencia_wordcloud&action=insert&data="+table_read(table, filter)+"&filter_context="+filtro+"&filter="+filtro_audiencia_wordcloud, function(){start_audiencia_wordcloud_new(); start_audiencia_wordcloud_all();});
        NProgress.done();
    }
};
function table_reload(table, filter) {
    if (table == "audiencia_new") {
        start_audiencia_new();
    }
    else if (table == "audiencia_filter") {
        filtro_audiencia = "";
        start_audiencia_filter();
        start_audiencia_all();
        start_audiencia_new();
    }
    else if (table == "audiencia_indu_sites_new") {
        start_audiencia_indu_sites_new();
    }
    else if (table == "audiencia_indu_sites_filter") {
        filtro_audiencia_indu_sites = "";
        start_audiencia_indu_sites_filter();
        start_audiencia_indu_sites_all();
        start_audiencia_indu_sites_new();
    }
    else if (table == "audiencia_sites_new") {
        start_audiencia_sites_new();
    }
    else if (table == "audiencia_sites_filter") {
        filtro_audiencia_sites = "";
        start_audiencia_sites_filter();
        start_audiencia_sites_all();
        start_audiencia_sites_new();
    }
    else if (table == "audiencia_wordcloud_new") {
        start_audiencia_wordcloud_new();
    }
    else if (table == "audiencia_wordcloud_filter") {
        filtro_audiencia_wordcloud = "";
        start_audiencia_wordcloud_filter();
        start_audiencia_wordcloud_all();
        start_audiencia_wordcloud_new();
    }
};
function table_filter(table, filter) {
    if (table == "audiencia_filter") {
        filtro_audiencia = table_read(table, filter);
        start_audiencia_all();
        start_audiencia_new();
    }
    else if (table == "audiencia_indu_sites_filter") {
        filtro_audiencia_indu_sites = table_read(table, filter);
        start_audiencia_indu_sites_all();
        start_audiencia_indu_sites_new();
    }
    else if (table == "audiencia_sites_filter") {
        filtro_audiencia_sites = table_read(table, filter);
        start_audiencia_sites_all();
        start_audiencia_sites_new();
    }
    else if (table == "audiencia_wordcloud_filter") {
        filtro_audiencia_wordcloud = table_read(table, filter);
        start_audiencia_wordcloud_all();
        start_audiencia_wordcloud_new();
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

    NProgress.start();
    
    init_sidebar_options("../service/menu.php?UID="+UID+"&action=menu");
    NProgress.inc();
    
    start_pcd_month_new();
    NProgress.inc();
    
    NProgress.done();
    
});

<?php

include_once("data_lib.php");

include_once("user_lib.php");


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_check_login($email, $pass) {
/*    $query = "SELECT USER_ID, 'SUCCESS' AS STATUS
              FROM (SELECT 1 AS USER_ID) TMP";
              
    $query = "SELECT USER_ID, STATUS
              FROM (SELECT USER_ID, 'success' AS STATUS FROM TB_USERS WHERE USER_NAME='".$user."' AND PASS='".$pass."' UNION
                    SELECT -1, 'error' AS STATUS) TMP
              ORDER BY USER_ID DESC
              LIMIT 1";
*/

    $query = "SELECT USER_ID, PASS
              FROM (SELECT USER_ID, PASS FROM TB_USERS WHERE EMAIL=".string_to_null($email)." UNION SELECT -1, NULL) TMP
              ORDER BY USER_ID DESC
              LIMIT 1";

    $table = table_simple($query)[0];
    $user_id = $table["USER_ID"];
    $hash = $table["PASS"];
    
    $status = "success";
    if ($user_id == -1 || !($pass == $hash || password_verify($pass, $hash))) {
        $status = "error";
    }
    
    $uid = "";
    $msg = "";
    if ($status == "success") {
        $uid = md5(uniqid($user_id, true));
        $update = "UPDATE TB_USERS SET UID='".$uid."', OLVIDE_MAIL=NULL, OLVIDE_FECHA=NULL WHERE USER_ID=".$user_id;
        table_query($update);
    }
    else {
        $msg = "Usuario o contraseña incorrectas";
    }

    to_json(Array("USER_ID" => $uid, "STATUS" => $status, "MSG" => $msg));
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$email = strval($_GET['email']);
$pass = strval($_GET['pass']);

get_check_login($email, $pass);

?>

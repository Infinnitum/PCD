<?php

include_once("data_lib.php");

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_check_login($UID) {
    $query = "SELECT STATUS
              FROM (SELECT 0 AS ORD, 'success' AS STATUS FROM TB_USERS WHERE UID='".$UID."' UNION
                    SELECT 1 AS ORD, 'error' AS STATUS) TMP
              ORDER BY ORD
              LIMIT 1";
             
    to_json(table_simple($query));
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$UID = isset($_GET['UID']) ? strval($_GET['UID']) : "";

get_check_login($UID);

?>

<?php

include_once("data_lib.php");

include_once("user_lib.php");

include_once("mail_lib.php");


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Servicios

function get_check_login($email, $pass) {
    $query = "SELECT USER_ID, PASS
              FROM (SELECT USER_ID, PASS FROM TB_USERS WHERE EMAIL=".string_to_null($email)." UNION SELECT -1, NULL) TMP
              ORDER BY USER_ID DESC
              LIMIT 1";

    $table = table_simple($query)[0];
    $user_id = $table["USER_ID"];
    $hash = $table["PASS"];
    
    $status = "success";
    if ($user_id == -1 ||
        $pass != $hash ||
        password_verify($pass, $hash)) {
        $status = "error";
    }
    
    $uid = "";
    $msg = "";
    if ($status == "success") {
        $uid = md5(uniqid($user_id, true));
        $update = "UPDATE TB_USERS SET UID='".$uid."' WHERE USER_ID=".$user_id;
        table_query($update);
    }
    else {
        $msg = "Usuario o contraseña incorrectas";
    }

    to_json(Array("USER_ID" => $uid, "STATUS" => $status, "MSG" => $msg));
}


function get_cambiar_password($pass_old, $pass_new1, $pass_new2) {
    global $USER;
    
    $status = "";
    $msg = "";
    
    $query = "SELECT USER_ID, PASS
              FROM (SELECT USER_ID, PASS FROM TB_USERS WHERE USER_ID=".$USER["USER_ID"]." UNION SELECT -1, NULL) TMP
              ORDER BY USER_ID DESC
              LIMIT 1";

    $table = table_simple($query)[0];
    $user_id = $table["USER_ID"];
    $hash = $table["PASS"];
    
    if ($pass_new1 == "" || $pass_new2 == "") {
        $status = "error";
        $msg = "La nueva contraseña no puede estar vacia";
    }
    else if ($pass_new1 != $pass_new2) {
        $status = "error";
        $msg = "Las contraseñas nuevas no coinciden";
    }
    else if ($user_id == -1 || !($pass_old == $hash || password_verify($pass_old, $hash))) {
        $status = "error";
        $msg = "Contraseña actual incorrecta";
    }
    else {
        //$uid = md5(uniqid($user_id, true));
        
        $update = "UPDATE TB_USERS SET PASS='".password_hash($pass_new1, PASSWORD_DEFAULT)."' WHERE USER_ID=".$user_id;
        table_query($update);
        
        $status = "success";
        $msg = "Contraseña cambiada exitosamente";
    }

    to_json(Array("STATUS" => $status, "MSG" => $msg));
}


function get_olvide_password($email) {
    global $MAIL_HEADERS;
        
    $status = "success";
    $msg = "Email enviado correctamente";
    
    $query = "SELECT USER_ID, OLVIDE_FECHA, EMAIL
              FROM (SELECT USER_ID, OLVIDE_FECHA, EMAIL FROM TB_USERS WHERE EMAIL=".string_to_null($email)." UNION SELECT -1, -1, NULL) TMP
              ORDER BY USER_ID DESC
              LIMIT 1";

    $table = table_simple($query)[0];
    $user_id = $table["USER_ID"];
    $mail = $table["EMAIL"];
    $olvide_fecha = $table["OLVIDE_FECHA"];
    $fecha = date("Ymd");
        
    if ($user_id != -1 && $olvide_fecha != $fecha) {
        $uid = md5(uniqid($user_id, true));
        $olvide_mail = md5(uniqid($olvide_fecha, true));
        $pass = substr(md5(uniqid(microtime(), true)), 0, 6);
        
        $update = "UPDATE TB_USERS SET UID='".$uid."', PASS='".$pass."', OLVIDE_MAIL='".$olvide_mail."', OLVIDE_FECHA=".$fecha." WHERE USER_ID=".$user_id;
        table_query($update);
        
        $to = $mail;
        $subject = "PCD - Reseteo de clave";
        $message = "<html><head><title>PCD - Reseteo de clave</title></head>
                        <body>
                            <hr />
                            <p>Su nueva clave es: ".$pass."</p>
                            <p>La misma es válida por 24 horas.</p>
                            <hr />
                        </body>
                    </html>";
        mail($to, $subject, $message, implode("\r\n", $MAIL_HEADERS));
    }
    
    to_json(Array("STATUS" => $status, "MSG" => $msg));
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Routing

$UID = isset($_GET['UID']) ? strval($_GET['UID']) : "";
if (isset($_GET['UID'])) set_user($UID);

$action = isset($_GET['action']) ? strval($_GET['action']) : "";
$pass_old = isset($_GET['pass_old']) ? strval($_GET['pass_old']) : "";
$pass_new1 = isset($_GET['pass_new1']) ? strval($_GET['pass_new1']) : "";
$pass_new2 = isset($_GET['pass_new2']) ? strval($_GET['pass_new2']) : "";

$mail = isset($_GET['mail']) ? strval($_GET['mail']) : "";

$control = isset($_GET['control']) ? strval($_GET['control']) : "";

if ($action == "cambiar_password") get_cambiar_password($pass_old, $pass_new1, $pass_new2);
else if ($action == "olvide_password") get_olvide_password($mail);

?>

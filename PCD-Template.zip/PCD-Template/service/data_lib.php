<?php

//phpinfo();

/*
function postgres_dataset($query) {
	$user_id = intval($_GET['user']); //no default

	// connect to the db
	$link = pg_connect('host=localhost;dbname=pcd;user=pcd;password=pcd') or die('Cannot connect to the DB');
	
	$result = pg_query($query, $link) or die('Errant query:  '.$query);

	// disconnect from the db
	pg_close($link);

    return $result;
}
*/

function dataset($query, $err_msg) {
	//$user_id = intval($_GET['user']); //no default

	// connect to the db
	$link = mysql_connect('localhost','root','root') or die(to_json(Array(Array("STATUS" => "error", "MSG" => "Cannot connect to the DB"))));
	mysql_select_db('pcd', $link) or die(to_json(Array(Array("STATUS" => "error", "MSG" => "Cannot select the DB"))));
    
	$result = mysql_query($query, $link) or die(to_json(Array(Array("STATUS" => "error", "MSG" => $err_msg))));

	// disconnect from the db
	@mysql_close($link);

    return $result;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Prototipo de datos

function table_simple($query) {
    $result = dataset($query, "Error al seleccionar los datos");

	$rows = array();
	if(mysql_num_rows($result)) {
		while($row = mysql_fetch_assoc($result)) {
			$rows[] = $row;
		}
	}

    return $rows;
}

function lookup_simple($query) {
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;

    return str_replace(",", $LST_TEXT, json_encode(table_simple($query)));
}

function array_simple($query, $claves) {
    $table = table_simple($query);
    $a = array();
    
    foreach ($table as $row) {
        $r = array();
        foreach ($row as $key => $value) {
            foreach ($claves as $clave) {
                if ($key == $clave) {
                    array_push($r, $value);
                }
            }
        }
        array_push($a, $r);
    }
    
    return $a;
}

function list_simple($query, $clave) {
    $table = table_simple($query);
    $a = array();
    
    foreach ($table as $row) {
        foreach ($row as $key => $value) {
            if ($key == $clave) {
                array_push($a, $value);
            }
        }
    }
    
    return $a;
}

function table_query($query) {
    dataset($query, "Error al actualizar los datos");
    
    $status = "success";
    $msg = "Actualización exitosa";
    return Array("STATUS" => $status, "MSG" => $msg);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function to_json($array) {
    header('Content-type: application/json');
    echo json_encode($array);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$LST_TEXT="|%|";
$EOL_TEXT="(T-T)";
$SEP_TEXT="(^~^)";

function string_to_null($text) {
    $s = $text;
    if ($s == "") {
        $s = "NULL";
    }
    else {
        $s = "'".$s."'";
    }
    return $s;
}

function number_to_null($text) {
    $s = $text;
    if ($s == "") {
        $s = "NULL";
    }
    return $s;
}

?>

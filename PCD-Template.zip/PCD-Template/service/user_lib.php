<?php

// include_once("lib.php");

$USER = Array("USER_ID" => -1, "SUPERVISOR" => "N");


function set_user($input_UID) {
    global $USER;
    
    $query = "SELECT USER_ID, SUPERVISOR, STATUS
              FROM (SELECT USER_ID, SUPERVISOR, 'success' AS STATUS FROM TB_USERS WHERE UID='".$input_UID."' UNION
                    SELECT -1, 'N', 'error' AS STATUS) TMP
              ORDER BY USER_ID DESC
              LIMIT 1";

    $table = table_simple($query)[0];
    $USER["USER_ID"] = $table["USER_ID"];
    $USER["SUPERVISOR"] = $table["SUPERVISOR"];
    
    if ($USER["USER_ID"] == -1) die();
}


function is_supervisor() {
    global $USER;
    
    return $USER["SUPERVISOR"] == "Y";
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$FILTRO = Array("PCD_ID" => -1, "MODO" => -1,
                "YEAR" => -1, "MONTH" => -1, "MESES" => "",
                "COMPETIDOR_ID_1" => -1, "COMPETIDOR_NAME_1" => "", "COMPETIDOR_COLOR_1" => "",
                "COMPETIDOR_ID_2" => -1, "COMPETIDOR_NAME_2" => "", "COMPETIDOR_COLOR_2" => "",
                "COMPETIDOR_ID_3" => -1, "COMPETIDOR_NAME_3" => "", "COMPETIDOR_COLOR_3" => "",
                "COMPETIDOR_ID_4" => -1, "COMPETIDOR_NAME_4" => "", "COMPETIDOR_COLOR_4" => "");


function set_filtro($filter) {
    global $USER;
    global $FILTRO;
    global $LST_TEXT;
    global $EOL_TEXT;
    global $SEP_TEXT;
        
    $where = "";
    if ($filter != "") {
        $w0 = explode($SEP_TEXT, $filter)[0];
        $w1 = explode($SEP_TEXT, $filter)[1];
        $w2 = explode($SEP_TEXT, $filter)[2];
        
        $where = "AND P.PCD_ID=".$w0." AND P.YEAR=".$w1." AND P.MONTH=".$w2."";
    }
    
    $user_id = $USER["USER_ID"];
    
    $query = "SELECT P.PCD_ID, T.MODO, P.YEAR, P.MONTH,
                     P.COMPETIDOR_ID_1, C1.COMPETIDOR_NAME AS COMPETIDOR_NAME_1, C1.COLOR AS COMPETIDOR_COLOR_1,
                     P.COMPETIDOR_ID_2, COALESCE(C2.COMPETIDOR_NAME,'') AS COMPETIDOR_NAME_2, COALESCE(C2.COLOR,'') AS COMPETIDOR_COLOR_2,
                     P.COMPETIDOR_ID_3, COALESCE(C3.COMPETIDOR_NAME,'') AS COMPETIDOR_NAME_3, COALESCE(C3.COLOR,'') AS COMPETIDOR_COLOR_3,
                     P.COMPETIDOR_ID_4, COALESCE(C4.COMPETIDOR_NAME,'') AS COMPETIDOR_NAME_4, COALESCE(C4.COLOR,'') AS COMPETIDOR_COLOR_4
              FROM TB_PCD_MONTH P
              LEFT OUTER JOIN TB_PCD_TEMPLATE T ON T.PCD_ID=P.PCD_ID
              LEFT OUTER JOIN TB_COMPETIDOR C1 ON C1.COMPETIDOR_ID=P.COMPETIDOR_ID_1
              LEFT OUTER JOIN TB_COMPETIDOR C2 ON C2.COMPETIDOR_ID=P.COMPETIDOR_ID_2
              LEFT OUTER JOIN TB_COMPETIDOR C3 ON C3.COMPETIDOR_ID=P.COMPETIDOR_ID_3
              LEFT OUTER JOIN TB_COMPETIDOR C4 ON C4.COMPETIDOR_ID=P.COMPETIDOR_ID_4
              WHERE EXISTS (SELECT 1 FROM TB_USERS_PCD U WHERE U.PCD_ID=P.PCD_ID AND U.USER_ID=".$user_id.") ".$where."
              ORDER BY P.YEAR DESC, P.MONTH DESC
              LIMIT 1";

    $table = table_simple($query)[0];
    
    if ($table == NULL) die();
    
    $FILTRO["PCD_ID"] = $table["PCD_ID"];
    $FILTRO["MODO"] = $table["MODO"];
    $FILTRO["YEAR"] = $table["YEAR"];
    $FILTRO["MONTH"] = $table["MONTH"];
    $FILTRO["COMPETIDOR_ID_1"] = $table["COMPETIDOR_ID_1"];
    $FILTRO["COMPETIDOR_NAME_1"] = $table["COMPETIDOR_NAME_1"];
    $FILTRO["COMPETIDOR_COLOR_1"] = $table["COMPETIDOR_COLOR_1"];
    $FILTRO["COMPETIDOR_ID_2"] = $table["COMPETIDOR_ID_2"];
    $FILTRO["COMPETIDOR_NAME_2"] = $table["COMPETIDOR_NAME_2"];
    $FILTRO["COMPETIDOR_COLOR_2"] = $table["COMPETIDOR_COLOR_2"];
    $FILTRO["COMPETIDOR_ID_3"] = $table["COMPETIDOR_ID_3"];
    $FILTRO["COMPETIDOR_NAME_3"] = $table["COMPETIDOR_NAME_3"];
    $FILTRO["COMPETIDOR_COLOR_3"] = $table["COMPETIDOR_COLOR_3"];
    $FILTRO["COMPETIDOR_ID_4"] = $table["COMPETIDOR_ID_4"];
    $FILTRO["COMPETIDOR_NAME_4"] = $table["COMPETIDOR_NAME_4"];
    $FILTRO["COMPETIDOR_COLOR_4"] = $table["COMPETIDOR_COLOR_4"];
    
    $year = $table["YEAR"]+0;
    $month = $table["MONTH"]+0;
    $meses = Array(Array("YEAR" => $year, "MONTH" => $month, "TEXT" => date_to_text($year, $month)));
    for ($i = 1; $i <= 12; $i++) {
        $month = $month - 1;
        if ($month == 0) {
            $month = 12;
            $year = $year - 1;
        }
        Array_push($meses, Array("YEAR" => $year, "MONTH" => $month, "TEXT" => date_to_text($year, $month)));
    }
    
    $FILTRO["MESES"] = $meses;
}

function date_to_text($year, $month) {
    $mes = "";
    
    if ($month == 1) $mes = "Ene-".substr($year, 2);
    else if ($month == 2) $mes = "Feb-".substr($year, 2);
    else if ($month == 3) $mes = "Mar-".substr($year, 2);
    else if ($month == 4) $mes = "Abr-".substr($year, 2);
    else if ($month == 5) $mes = "May-".substr($year, 2);
    else if ($month == 6) $mes = "Jun-".substr($year, 2);
    else if ($month == 7) $mes = "Jul-".substr($year, 2);
    else if ($month == 8) $mes = "Ago-".substr($year, 2);
    else if ($month == 9) $mes = "Sep-".substr($year, 2);
    else if ($month == 10) $mes = "Oct-".substr($year, 2);
    else if ($month == 11) $mes = "Nov-".substr($year, 2);
    else if ($month == 12) $mes = "Dic-".substr($year, 2);
    
    return $mes;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>

<?php

$MAIL_HEADERS = Array("MIME-Version: 1.0", "Content-type: text/html; charset=iso-8859-1");

?>
